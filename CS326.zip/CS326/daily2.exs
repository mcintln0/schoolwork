defmodule Daily2 do
  def average(a,b) do
    (a + b)/2
  end

  def discrim(a,b,c) do
    b*b - 4*a*c
  end

  def quad_roots(a,b,c) do  
    x = ( (-b + :math.sqrt( discrim(a,b,c) ) ) / (2*a) )
    y = ( (-b - :math.sqrt( discrim(a,b,c) ) ) / (2*a) )
    {x,y}
  end
   
end

  
