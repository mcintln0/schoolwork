defmodule Hw1 do
    def occurences(item, [], sum ) do
      cond do
        sum == 0 -> IO.puts " #{item} does not occur"
        true -> IO.puts " #{item} occurs #{sum} times"
      end
      sum
    end

    def occurences(head, [head|tail],sum) do
      occurences(head, tail,sum+1)
    end    

    def occurences(item, [head | tail], sum) do
      occurences(item, tail, sum)
    end

    def special(item, list ) do
     results = occurences(item, list,0)

      cond do
        results>0 -> IO.puts "nil"
        true -> list ++ item
      end
    end

    def special(item,[]) do
        IO.inspects "[#{item}]"
    end


    def raise(x,n) do
      case n do
	0 -> 1
	1 -> x
	n>0 -> x*raise(x,(n-1))
        n<0 -> 1/ ( x*raise(x,(n-1)) )
       end
    end

    def raise(x) do
       x
    end

     def raise do
	0
     end

end 
  
