defmodule HW3 do

  def onepad(a) do
    case a do
      0 -> []
      _ -> [:rand.uniform(1000)] <> onepad(a-1)
    end
  end