# LaToya McIntyre
# Homework 2 1-7
# Computer Science 326

defmodule HW2 do

@moduledoc """
Homework number 2
"""

@doc """
Tells the length of the length tail-recursively
"""

#@spec len(list)::number

def len(list) do  #Number 1
  len(list,0)
end

#@spec len(list,number)::number
def len([],acc) do
  acc
end

def len([head|tail],acc) do
  len(tail,acc+1)
end

@doc """
Finds the average of all prices in the list
"""

#@spec average_price(list(number))::(number)

  def average_price([]) do       #Number 2
   0
  end

  def average_price(list) do
    Enum.reduce(list, fn(x,acc) -> x+acc end ) / length(list)
  end

@doc """
Finds the average of all prices in the list recursively
"""

#@spec average_price(list(number))::(number)

  def average_priceR(list) do     #Number 2 (recursive)
    average(list)/length(list)
  end

  #Created separate functions to be able to sum up the prices
  # while still being able to have the correct length when dividing

  defp average([head|tail]) do     #recursive
    (head + average(tail))
  end

  defp average([]) do     #recursive
    0
  end

@doc """
Removes the price of expensive textbooks recursively
"""

#@spec eliminate_expR(number,list(number),list(number))::(list(number))
  def eliminate_expR(max, [], list) do    #Number 3(recursive)
    list
  end

  def eliminate_expR(max, [head|tail], list) do    #Number 3(recursive)
    cond do
      head >= max -> eliminate_expR(max,tail,list)
      true -> eliminate_expR(max,tail, ([head] ++ list))
    end
  end

#@spec eliminate_expR(number,list(number))::(list(number))
  def eliminate_expR(max, [head|tail]) do    #Number 3 (recursive)
    cond do
      head > max -> eliminate_expR(max,tail,[])
      true -> eliminate_expR(max,tail,[head])
    end
  end

@doc """
Removes the price of expensive textbooks
"""

#@spec eliminate_exp(number,list(number))::(list(number))

  def eliminate_exp(max, []) do    #Number 3
    IO.puts "None"
  end

  def eliminate_exp(max, list) do  #Number 3
    Enum.filter(list,fn(x) -> x<max end)
  end

@doc """
Finds the number of days since the beginning of the year
"""

#@spec julian(number,number,number)::(number)

  def julian(month,day,year)  do #Number 4
    # A way to add the days in a month by calling the function 
    # until you get to the first month

    case month do
     1 -> day
     2 -> (31 + julian(month - 1,day,year))
     3 -> 
       if(rem(year,4) == 0) do
        29 + julian(month-1,day,year)
       else 
        28 + julian(month-1,day,year)
       end
     4 -> 31 + julian(month-1,day,year)
     5 -> 30 + julian(month-1,day,year)
     6 -> 31 + julian(month-1,day,year)
     7 -> 30 + julian(month-1,day,year)
     8 -> 31 + julian(month-1,day,year)
     9 -> 31 + julian(month-1,day,year)
     10 -> 30 + julian(month-1,day,year)
     11 -> 31 + julian(month-1,day,year)
     12 -> 30 + julian(month-1,day,year)    
     _->  0
    end
  end

@doc """
Tells the number of days from the first day of the given year
"""

#@spec julianH(number,number,number)::number

def julianH(0,day,year) do    #Number 5
  day
end

def julianH(month,day, year) do
  time = [0,31,28,31,30,31,30,31,31,30,31,30]
  timeL = [0,31,29,31,30,31,30,31,31,30,31,30]
   if rem(year,4)==0 do
     Enum.at(timeL,month-1,1) + julianH(month-1,day,year)
   else
     Enum.at(time,month-1,1) + julianH(month-1,day,year)
   end
end

@doc """
Removes the given key(s) from the map 
"""

#@spec remove_key(map,list):: map

  def remove_key( map, list) do			 # Number 6
    Map.drop( map, list)
  end

@doc """
Creates a list of random integers of the indicated length
"""

#@spec random_ints(number):: map

  def random_ints(length) do			#Number 7
     case length do
      0 -> []
      _ -> [:rand.uniform(1000)] ++ random_ints(length-1)
     end
  end

  def tester do
    IO.inspect( average_price([120,50.75,66,70]) )  	# -> 76.6875
    IO.inspect( average_priceR([120,50.75,66,70]) ) 	# -> 76.6875
    IO.inspect( average_price([])  )                	# -> 0
    IO.inspect( eliminate_expR(100,[123.06,20,5.0,100]) )	# -> [5.0,20]
    IO.inspect( eliminate_exp(100,[123.06,20,50.0,100]) )	# -> [20,50.0]
    IO.inspect( julian(3,23,2016) )				# -> 83
    IO.inspect( julian(11, 25,2016) )  				# -> 330
    IO.inspect( remove_key(%{atom: 1,a: 2,b: "d",c: "five"},[:atom,:b , :c])) # -> %{a: 2}
    IO.inspect( remove_key(%{atom: 1,a: 2,b: "d",d: "five"},[:atom,:b , :c])) # -> %{a:2, d:"five"}
    Enum.take( random_ints(0),10 ) 	# produces nothing
    Enum.take( random_ints(1),10 )      # produces a list of one integer
    Enum.take( random_ints(10),10 ) 	# produces a list of ten integers
    Enum.take( random_ints(100),20 ) 	# produces a list of ten integers
  end


end


