mcintln0@cook:~/CS326$ iex
Interactive Elixir (1.5.2) - press Ctrl+C to exit (type h() ENTER for help)
iex(1)> Daily2.average(10,10)
10.0
iex(2)> Daily2.average(5,7)
6.0
iex(3)> Daily2.average(5,8)
** (SyntaxError) iex:3: unexpected token: )

iex(3)> Daily2.average(5,8)
6.5
iex(4)> Daily2.average(5.0,8.0)
6.5
iex(5)> Daily2.average(12.4,13.7)
13.05
iex(6)> Daily2.average(12,15)
13.5
iex(7)> Daily2.average(36,9)
22.5
iex(8)> Daily2.discrim(2,7,5)
9
iex(9)> Daily2.discrim(1,3,2)
1
iex(10)> Daily2.discrim(3,8,6)
-8
iex(11)> Daily2.quad_roots(2,7,5)
{-1.0, -2.5}
iex(12)> Daily2.quad_roots(1,3,2)
{-1.0, -2.0}
iex(13)> Daily2.quad_roots(2,8,6)
{-1.0, -3.0}yes
** (CompileError) iex:14: undefined function yes/0

iex(14)> yes
** (CompileError) iex:14: undefined function yes/0

iex(14)> quit
** (CompileError) iex:14: undefined function quit/0

iex(14)> 