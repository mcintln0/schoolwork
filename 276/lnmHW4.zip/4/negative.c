// LaToya McIntyre
// CS270 HW 4
// Fall 2019

#include <stdio.h>

// Determines if the int is positive or negative
// by comparing the sign value (the most significant)
// to 0. This is done by shifting the value all the way
// to the left (b/c int is 32-bit)

int isNegative(int value){
return	((value >>31) == 0) ? 1 : 0;
}


int main(){
	int p;
	printf("Enter an integer:");
	scanf("%d",&p);
        ( isNegative(p) == 1) ? printf("\npositive\n") : printf("\nnegative\n");
        
	return 0;
}


