// LaToya McIntyre
// CS270 HW 4
// Fall 2019


#include <stdio.h>

// Divide and multiply numbers using bitwise operations
// Display numbers in hexadecimal format
int main(){
   while(0<5){
           int f;
	   printf("\nEnter an integer: ");
	   scanf( "%d", &f);
	   printf("\nHexadecimal Format: %x\n",f); 
	   printf(" Divided by Two: %d\n", f>>1); 
	   printf(" Multiplied by Two: %d", f<<1);


  }


}
