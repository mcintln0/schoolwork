/* LaToya McIntyre
   CS286 Google Maps
   Spring 2020

   If I got stuck and couldn't figure out the answer then I either referenced stack overflow 
   or the google documentation for help 
*/

// This file holds all the map functions required for the website.

// Creates a map
function initMap(){
return new google.maps.Map(document.getElementById("map_canvas"),{
        center: {lat: 35.205154, lng: -85.917483 },
        zoom:18,
        mapTypeId: google.maps.MapTypeId.Map,
        mapTypeControl:true,
        streetViewControl: false,
        rotateControl: false,
        zoomControlOptions: {position: google.maps.ControlPosition.LEFT_BOTTOM},
        fullscreenControlOptions: {position: google.maps.ControlPosition.LEFT_TOP},
        mapTypeControlOptions: {
        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
        }
      }); 
}


/* -----------------------------------------------------------*/
//Light Functions 

//Creates the Markers
function createMarkers(){
    for (i=0; i<lights.length; i++){
      if(lights[i].Working == 'No'){
       var marker = new google.maps.Marker({
       position: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) ,
       title:  lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
       label: 'X', 
       animation: google.maps.Animation.BOUNCE
          });
      }else  if(lights[i].Exists == 'No'){
       var marker = new google.maps.Marker({
       position: new google.maps.LatLng(lights[i].Location.Latitude,
                                        lights[i].Location.Longitude) ,
       title: lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
       icon: { url: "http://labs.google.com/ridefinder/images/mm_20_blue.png" },
       animation: google.maps.Animation.BOUNCE
             });

      }else if(lights[i].Type == 'Black Lamp'){
       var marker = new google.maps.Marker({
       position: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) ,
       title:  lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
       icon: { url: "blackLamp.png", scaledSize: new google.maps.Size(30,30)},
             });

      }else if(lights[i].Type == 'Street Light'){
        var marker = new google.maps.Marker({
        position: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude),
        title:  lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
        icon: { url: "streetLamp.png",  scaledSize: new google.maps.Size(30, 30) },
             });
      }else if(lights[i].Type == 'Double Light'){
        var marker = new google.maps.Marker({
        position: new google.maps.LatLng(lights[i].Location.Latitude,
                                         lights[i].Location.Longitude),
        title:  lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")",
        icon: { url: "double.png",     scaledSize: new google.maps.Size(30, 30) }
             });
      }else if(lights[i].Type == 'Parking Lot'){
        var marker = new google.maps.Marker({
        position: new google.maps.LatLng(lights[i].Location.Latitude,
                                         lights[i].Location.Longitude),
        title: lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
        icon: { url: "parking.png",     scaledSize: new google.maps.Size(30, 30) }});
      }else if(lights[i].Type == 'Tree Light'){
        var marker = new google.maps.Marker({
        position: new google.maps.LatLng(lights[i].Location.Latitude,
                                         lights[i].Location.Longitude),
        title: lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
        icon: { url: "nature.png",     scaledSize: new google.maps.Size(30, 30) }});
       }else{
       var marker = new google.maps.Marker({
       position: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) ,
       title:  lights[i].Name
               + "<br>Type of Light: " 
               + lights[i].Type
               + "<br>Working: "
               + lights[i].Working 
               + "<br>(" + lights[i].Location.Latitude 
               + " , " + lights[i].Location.Longitude +")", 
        icon: { url: "light-bulb.png",     scaledSize: new google.maps.Size(30, 30) }});
      }
   google.maps.event.addListener(marker, 'click', function() {showInfoWindow(this)});
   markers.push(marker);
     }
   return markers;
   }

var currentWindow;
function showInfoWindow(m) {
  var info = new google.maps.InfoWindow({
      content: '<div style="width: 300px; height: auto; border:2px solid; padding: 2px;">'
              +'<span style="font-size:12pt;">' 
              + m.title 
              + '</span></div>'
  }); 
  if (currentWindow != null) {currentWindow.close();}
  info.open(map, m);
  currentWindow=info;
}


// Creates the lights as ball represention
function createLC() {
  lightBalls = [];
for(var i = 0; i<markers.length; i++)
  lightBalls[i] = new google.maps.Marker({
                    position: markers[i].position,
                    icon: { path: google.maps.SymbolPath.CIRCLE,
                            scale: 5,
                            fillColor: "yellow", 
                            fillOpacity: 0.95,
                            strokeColor: "black", 
                            strokeWeight: 0.5 },
                    });   
}

// Creates the heat map of Sewanee lights
function createLMap(){
   lightMap = new google.maps.visualization.HeatmapLayer({
   data: data,
   gradient: [
              'rgba(  0,   0,   0,    0.95)'  // black
             ,'rgba(255, 255, 0,    0.95)'  // yellow
             ]});

   for (i=0; i<lights.length;i++){
    if(lights[i].Exists == 'No'){
   } else if(lights[i].Works == 'No'){
   } else if(lights[i].Type == 'Black Lamp'){
       data.push({location: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) , weight: 2});
   } else if(lights[i].Type == 'Street Light')
       data.push({location: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) , weight: 4});
    else if(lights[i].Type == 'Tree Lamp')
       data.push({location: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) ,weight: 3});
    else if(lights[i].Type == 'Double Lamp')
       data.push({location: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) , weight: 4});
    else if(lights[i].Type == 'Parking Lot')
       data.push({location: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) , weight: 5});
    else 
       data.push({location: new google.maps.LatLng(lights[i].Location.Latitude,lights[i].Location.Longitude) , weight: 1});
   }
}

//Show the markers
function showLights(){ 
 if ( document.getElementById("sL").innerHTML == "Lights"){ 
    for (var i; i< markers.length;i++)
        markers[i].setMap(map);
      markerCluster.addMarkers(markers);
    document.getElementById("sL").innerHTML ='Remove'; 
  }else{
    for (var i; i< markers.length;i++)
        markers[i].setMap(null);
      markerCluster.clearMarkers();
  document.getElementById('sL').innerHTML ='Lights';
  }
}

// Shows Sewanee lights at night aka the heat map
function showLMap(){
  if ( this.innerHTML !='ON'){
     lightMap.setMap(map);

         map.setOptions({ styles: [
              {elementType: 'geometry',
                stylers: [{color: '#000000'}]
              },
              {featureType: 'road',
               elementType: 'geometry',
               stylers: [{color: '#FFFFFF'}]
              },
              {elementType: 'labels',
               stylers: [ {visibility: 'off'}]
              }

               ] });
   this.innerHTML = 'ON';
   }else{
   defaultMap();
   lightMap.setMap(null);
   this.innerHTML = 'OFF';
    }

}


// Shows lights as small circles
function showLC(){
 if ( this.innerHTML !='ON'){
    for (i=0; i<lightBalls.length; i++)
     lightBalls[i].setMap(map);

         map.setOptions({ styles: [
              {elementType: 'geometry', 
                stylers: [{color: '#000000'}]
              }, 
              {featureType: 'road',
               elementType: 'geometry',
               stylers: [{color: '#FFFFFF'}]
              },
              {elementType: 'labels',
               stylers: [ {visibility: 'off'}]
              }
                 
               ] });
   this.innerHTML = 'ON';
}else{
   defaultMap();
   for (i=0; i<lightBalls.length; i++)
     lightBalls[i].setMap(null);
   this.innerHTML = 'OFF';
    }
}

// Sets map coloring back to the default
function defaultMap(){
         map.setOptions({ styles: [
           {
             elementType: 'geometry', 
             stylers: [{color: 'revert'}]
           },
           {
             featureType: 'road',
             elementType: 'geometry',
             stylers: [{color: 'revert'}]
           }
                                   ] 
            });
}



/* -----------------------------------------------------*/
// Position Functions 

//Sets map center of campus
function center(){
          map.setCenter( new google.maps.LatLng(35.202756, -85.921209 ));
          map.setZoom(18); 
}

//Sets map center to cross road
function cross(){
          map.setCenter( new google.maps.LatLng( 35.195250, -85.93));
          map.setZoom(16); 
}

//Sets map center to Gorgas and SoT
function gst(){
          map.setCenter( new google.maps.LatLng(35.196821, -85.925173 ));
          map.setZoom(18); 
}

//Sets map center near gym
function gym(){
          map.setCenter( new google.maps.LatLng(35.208402, -85.919964 ));
          map.setZoom(17); 
}

//Sets map center near Tuckaway, Hunter, and Cleaveland
function thc(){
          map.setCenter( new google.maps.LatLng(35.201646, -85.921616 ));
          map.setZoom(18); 
}

//Sets map center near MCC, Ayres, and Barnswell Apartments
function mab(){
          map.setCenter( new google.maps.LatLng( 35.201506, -85.918720));
          map.setZoom(18); 
}

//Sets map center near Courts and Trez 
function cot(){
          map.setCenter( new google.maps.LatLng( 35.206310, -85.912849));
          map.setZoom(18); 
}

//Sets map center near Benedict, DKE, and Wick
function bdw(){
          map.setCenter( new google.maps.LatLng( 35.206218, -85.917109));
          map.setZoom(18); 
}

//Sets map center near Humphrey's, Sterlings, and art building
function ash(){
          map.setCenter( new google.maps.LatLng( 35.197665, -85.927799));
          map.setZoom(4); 
}

//Sets map center on Bishop Commons
function bc(){
          map.setCenter( new google.maps.LatLng( 35.197665, -85.927799));
          map.setZoom(4); 
}

//Sets map center near the Football Field
function fot(){
          map.setCenter( new google.maps.LatLng(35.201646, -85.921616 ));
          map.setZoom(18); 
}

//Sets map center near Farm and Faculty Housing 
function faf(){
          map.setCenter( new google.maps.LatLng(35.201646, -85.921616 ));
          map.setZoom(18); 
}

//Sets map view campus wide
function all(){
          map.setCenter( new google.maps.LatLng(35.202756, -85.921209 ));
          map.setZoom(15); 
}

//Sets map view to academic buildings 
function aca(){
          map.setCenter( new google.maps.LatLng(35.2036, -85.9172 ));
          map.setZoom(17); 
}

//Sets map view near Phillips and Hodgeson
function phh(){
          map.setCenter( new google.maps.LatLng(35.201646, -85.921616 ));
          map.setZoom(18); 
}

/* ----------------------------------------------------------------------*/
// Path Variables and Functions

function createVisitorPaths(){
  //Using tour array
  for( var i = 0; i< tourCoordsArray.length; i++)
    tourPaths[i] =  new google.maps.Polyline({
                    path: tourCoordsArray[i], 
                    strokeColor: "purple", 
                    icon: { path: google.maps.SymbolPath.CIRCLE,
                            scale: 5,
                            fillColor: "yellow", 
                            fillOpacity: 0.95,
                            strokeColor: "black", 
                            strokeWeight: 0.5 }
                             });
  }

function createCommonPaths(){
  //Rendering the paths to central from dorms with a directions renderer
 for(var i =0; i< farDormArray.length; i++){
      var request = {
      origin: farDormArray[i],
      destination: academicArray[0],
      travelMode: google.maps.TravelMode.WALKING
      };
      directionsService1.route(request, function(result, status) {
        if (status == google.maps.DirectionsStatus.OK ) {
          var line= new google.maps.Polyline({
            path: result.routes[0].overview_path,
            strokeColor: "red",
            strokeOpacity: .75
          });
          studentRoute.push(line);
        }
      });
    } 
  }

function createPartyPaths(){
  //Rendering the paths to central from dorms with a directions renderer
 for(var i =1; i< fratSArray.length; i++){
      var request = {
      origin: fratSArray[i-1],
      destination: fratSArray[i],
      travelMode: google.maps.TravelMode.WALKING
      };
      directionsService.route(request, function(result, status) {
        if (status == google.maps.DirectionsStatus.OK ) {
          var line= new google.maps.Polyline({
            path: result.routes[0].overview_path,
            strokeColor: "blue",
            strokeOpacity: .75 //,
     /*       icons: [{
              icon: people,
              offset: '100%'
              }]
*/
          });
          partyRoutes.push(line);
        }
      });
    } 
          var line= new google.maps.Polyline({
            path: [fratSArray[0], fratSArray[3]],
            strokeColor: "blue",
            strokeOpacity: .75,
            icons: [{
              icon: people,
              offset: '100%'
              }]

          });

          partyRoutes.push(line);

  }

function createOtherPaths(){
  //Rendering the paths from central to hotspots with a directions renderer
  for(var i = 0; i< specialityLocations.length; i++){
      var request = {
      origin: academicArray[0],
      destination: specialityLocations[i],
      travelMode: google.maps.TravelMode.WALKING
      };
      directionsService2.route(request, function(result, status) {
        if (status == google.maps.DirectionsStatus.OK ) {
          var line= new google.maps.Polyline({
            path: result.routes[0].overview_path,
            strokeColor: "green",
            strokeOpacity: .75
          });
          specialPaths.push(line);
        }
      });
  }
}


//CommonPaths
function showCommonPaths(){
if ( document.getElementById("sR").innerHTML == "Student Routes"){
  for( var i =0; i<studentRoute.length; i++)
    studentRoute[i].setMap(map);
    document.getElementById("sR").innerHTML ='Remove Routes';
  }else{
  for( var i =0; i<studentRoute.length; i++)
    studentRoute[i].setMap(null);
    document.getElementById("sR").innerHTML ='Student Routes';
  }
}

function showVisitorPaths(){
if ( document.getElementById("vR").innerHTML == "Visitor Routes"){
 for( var i =0; i<tourPaths.length; i++)
    tourPaths[i].setMap(map);
    document.getElementById("vR").innerHTML = 'Remove Routes';
  }else{
 for( var i =0; i<tourPaths.length; i++)
    tourPaths[i].setMap(null);
    document.getElementById("vR").innerHTML = 'Visitor Routes';
  }
}

// Special Paths
function showSpecialPaths(){
if ( document.getElementById("oR").innerHTML == "Other Routes"){
 for( var i =0; i<specialPaths.length; i++)
    specialPaths[i].setMap(map);
    document.getElementById("oR").innerHTML ='Remove Routes';
  }else{
 for( var i =0; i<specialPaths.length; i++)
    specialPaths[i].setMap(null);
    document.getElementById("oR").innerHTML ='Other Routes';
  }
}

function showPartyPaths(){
if ( document.getElementById("pR").innerHTML == "Party Routes"){
  for( var i =0; i<partyRoutes.length; i++)
    partyRoutes[i].setMap(map);
    document.getElementById("pR").innerHTML ='Remove Routes';
  }else{
  for( var i =0; i<partyRoutes.length; i++)
    partyRoutes[i].setMap(null);
    document.getElementById("pR").innerHTML ='Party Routes';
  }
}


// Animation Symbol
var people = {
             imagePath: 'people.png',
             scale: 8,
             };

//Overloads the website and causes it to freeze 
function animatePaths(){
          var count = 0;
          window.setInterval(function() {
            count = (count + 1) % 200;

            var icons = partyRoute[0].get('icons');
            icons[0].offset = (count / 2) + '%';
            partyRoute[0].set('icons', icons);
        }, 2000);
    


        }




/* ----------------------------------------------------------------------*/
// Building Polygon Information


var dorms, academicBuildings, fratHouses, otherPlaces;
//Res Life
function addDorms(){
  for(var i =0; i < dormsArray.length; i++)
    new google.maps.Polygon({
      map: map,
      strokeWeight: 2,
      strokeColor: 'black',
      fillColor: 'red',
      path: dormsArray[i]
      });
}

//Academic buildings
function addAcademics(){
  for(var i =0; i < acadCoordArray.length; i++)
  new google.maps.Polygon({
      map: map,
      strokeWeight: 2,
      strokeColor: 'black',
      fillColor: 'blue',
      path: acadCoordArray[i]
  });
}

//AddFratHouses
function addFrats(){
  for(var i =0; i < fratArray.length; i++)
  new google.maps.Polygon({
      map: map,
      strokeWeight: 2,
      strokeColor: 'black',
      fillColor: 'grey',
      path: fratArray[i]
  });
}

//Other University Buildings
function addUniv(){
  for(var i =0; i < univArray.length; i++)
  new google.maps.Polygon({
      map: map,
      strokeWeight: 2,
      strokeColor: 'black',
      fillColor: 'yellow',
      path: univArray[i]
  });
}





























/* Decided not to use b/c I found a work around to adding a button to the map through the other add option
kept because it is still pretty cool and might use later.

function CrossControl(positionControlDiv, map){

  //The box itself
  var controlUI = document.createElement('div');
  controlUI.style.backgroundColor = '#000';
  controlUI.style.border = '2px solid #fff';
  controlUI.style.borderRadius = '3px';
  controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
  controlUI.style.cursor = 'pointer';
  controlUI.style.marginBottom = '22px';
  controlUI.style.textAlign = 'center';
      controlUI.title = 'Click to view route to the cross';
      lightControlDiv.appendChild(controlUI);


  //Inside the box
  var controlText = document.createElement('div');
  controlText.style.color = 'rgb(255,255,255)';
  controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
  controlText.style.fontSize = '16px';
  controlText.style.lineHeight = '38px';
  controlText.style.paddingLeft = '5px';
  controlText.style.paddingRight = '5px'; 
  controlText.innerHTML = 'Default';
      controlUI.appendChild(controlText);

  controlUI.addEventListener('click', function() {
          map.setCenter( new google.maps.LatLng( 35.197665, -85.927799));
          map.setZoom(4); 
    });

} 

function LightControl(lightControlDiv, map){

  var controlUI = document.createElement('div');
  controlUI.style.backgroundColor = '#fff';
  controlUI.style.border = '2px solid #fff';
  controlUI.style.borderRadius = '3px';
  controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
  controlUI.style.cursor = 'pointer';
  controlUI.style.marginBottom = '22px';
  controlUI.style.textAlign = 'center';
      controlUI.title = 'Click to show the lights';
      lightControlDiv.appendChild(controlUI);

  var controlText = document.createElement('div');
  controlText.style.color = 'rgb(25,25,25)';
  controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
  controlText.style.fontSize = '16px';
  controlText.style.lineHeight = '38px';
  controlText.style.paddingLeft = '5px';
  controlText.style.paddingRight = '5px'; 
  controlText.innerHTML = 'Night Lights';
      controlUI.appendChild(controlText);

  controlUI.addEventListener('click', function() {
          map.setOptions({ styles: [
  {elementType: 'geometry', stylers: [{color: '#000000'}]},   {
              featureType: 'road',
              elementType: 'geometry',
              stylers: [{color: '#FFFFFF'}]
            }
                                   ] }); 

    });

}
*/

/* Needed to show the buttons on the map Must be included in the init function
    var positionControlDiv = document.createElement('div');
    var defControlDiv = document.createElement('div');
    var positionControl = new PositionControl(positionControlDiv,map);
    var lightControl = new LightControl(lightControlDiv,map);

lightControlDiv.index = 2;

map.controls[google.maps.ControlPosition.LEFT_CENTER].push(defControlDiv);
map.controls[google.maps.ControlPosition.LEFT_CENTER].push(lightControlDiv);
*/


