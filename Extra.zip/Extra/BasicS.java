  // LaToya McIntyre
  // November 16, 2017
  // Create a recursive drawing

import objectdraw.*;
import java.awt.*;

public class BasicS extends ActiveObject{
   
  protected RandomIntGenerator bob = new RandomIntGenerator(0,255);
  protected AngLine topL, topM, topR, botL, botM, botR, slaTL, slaBL;
  protected Line midL, midR, slaTR, slaBR;
  protected DrawableInterface [] part = new DrawableInterface [12]; 
  protected double width;
  protected double height;

  public BasicS(double x, double y, double w, double h, DrawingCanvas canvas){
  // new FramedRect(x,y,w,h,canvas);
    width = w;
    height = h;
  
    topL  = new AngLine(x       ,y + h/4   , h/6, -Math.PI/2, canvas);
    topM  = new AngLine(x + w/2 ,y + h/4   , h/6, -Math.PI/2, canvas);
    topR  = new AngLine(x + w   ,y + h/4   , h/6, -Math.PI/2, canvas);
    
    botL  = new AngLine(x       ,y + 7*h/12, h/6, -Math.PI/2, canvas);
    botM  = new AngLine(x + w/2 ,y + 7*h/12, h/6, -Math.PI/2, canvas);
    botR  = new AngLine(x + w   ,y + 7*h/12, h/6, -Math.PI/2, canvas);

  // Using tan to find the angle needed to center the lines of the S
  // Using pythagorem theorem to find the length of the AngLine
    slaTL = new AngLine(topL.getStart(),
                        Math.sqrt(Math.pow(w/2,2) + Math.pow(h/4,2)), 
                        Math.atan((h/4)/(w/2)), canvas);
    slaBL = new AngLine(botL.getEnd(),
                        Math.sqrt(Math.pow(w/2,2) + Math.pow(h/4,2)),
                        - Math.atan((h/4)/(w/2)), canvas);
    
    midL  = new Line(topL.getEnd(), botM.getStart(), canvas);
    midR  = new Line(topM.getEnd(), botR.getStart(), canvas);
    slaTR = new Line(slaTL.getEnd(), topR.getStart(), canvas);
    slaBR = new Line(slaBL.getEnd(), botR.getEnd(), canvas);
   

  // Must set all parts into array separately if not the array loop will not work
    int i=0;
    part[i++] = topL;
    part[i++] = topM;
    part[i++] = topR;
    part[i++] = botL;
    part[i++] = botM;
    part[i++] = botR;
    part[i++] = slaTL;
    part[i++] = slaBL;
    part[i++] = midL;
    part[i++] = midR;
    part[i++] = slaTR;
    part[i++] = slaBR;

    start();
  }

  public void move(double dx, double dy){
    for(int i = 0; i < part.length; i++)
      part[i].move(dx,dy);
  }

  public void setColor(Color c){
    for(DrawableInterface p: part)
      p.setColor(c);
  }

  public boolean contains(Location p){
  // if the mouse is within the "box" of S then it will return true
    if(p.getX() > topL.getStart().getX() && p.getX() < botR.getEnd().getX()
       && p.getY() > slaTL.getEnd().getY() && p.getY() < slaBL.getEnd().getY()){
      return true;
    }else{
      return false;
    }
  }

  public double getWidth(){
    return width;
  }
  
  public double getHeight(){
    return height;
  }

  public Location getLocation(){
    return new Location(topL.getStart().getX(), topL.getStart().getY()-height/4);
  }

 // figure out a way to make the 
  public void change(){ }

  public void grow( double scale){
    new BasicS(topL.getStart().getX(),
           topL.getStart().getY() + height/4,
           width*scale, 
           height*scale ,topL.getCanvas());
  }



  public void run(){ }
  
}
