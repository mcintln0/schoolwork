import objectdraw.*;
import java.awt.*;

public class FlyingClient extends WindowController{

 public static void main (String[] args) {
        new FlyingClient().startController(800,800); 
  }
Superman bob;

public void begin(){
    bob = new Superman(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
  }


public void onMouseClick(Location p){
  bob.grow(.75);
}
}
