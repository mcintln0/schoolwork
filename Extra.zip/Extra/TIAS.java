import objectdraw.*;
import java.awt.*;

public class TIAS extends WindowController {

  public static void main(String[] args){
    new TIAS().startController(800,800);
  }
  
  private MultiShape bob,bae;
  private Hexagon brit;
  private Location lastP;

  public void begin(){
    new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
  }

  public void onMousePress(Location p){
    lastP=p;

    bob = new FunMultiShape(p, (int) (100*Math.random() + 3) ,75,canvas);
    bae = new FunMultiShape(p.getX()+100,p.getY()+100, (int) (100*Math.random() + 3),75,canvas);
    bae.setColor(
        new Color( (int)(Math.random()*100+100),(int)(Math.random()*100+100),
                  (int)(Math.random()*100+100),(int)(Math.random()*100+100)));
  
    brit = new Hexagon(p.getX(),p.getY(), (200*Math.random() + 3) ,(200*Math.random() + 3),canvas);


  }

  public void onMouseDrag(Location p){
       bob.move(lastP.getX()-p.getX(), lastP.getY()-p.getY());

       bae.move(p.getX()-lastP.getX(), p.getY()-lastP.getY());
    lastP=p;
  }

}  
