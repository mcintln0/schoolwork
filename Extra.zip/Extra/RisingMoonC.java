    // LaToya McIntyre
    // Septmeber 14,2017
    // Homework 2
    // 3.11.4
 
    // A program that produces an animation of the moon rising.
    // The animation is driven by clicking the mouse button.
    // The faster the mouse is clicked, the faster the moon will rise.


import objectdraw.*;
import java.awt.*;

  public class RisingMoonC extends WindowController{

  public static void main(String[] args) {
    new RisingMoonC().startController(800,800);
    }
    
    private FilledOval moond,
                       moon;  
   
    private Text instructions;

    // Place the moon and some brief instructions on the screen
    public void begin() {
      new FilledRect(0,0,canvas.getWidth()*2,canvas.getHeight()*2,canvas);

      moon = new FilledOval(canvas.getWidth()/4,3*canvas.getHeight()/4,
                           canvas.getWidth()/2,canvas.getWidth()/2,
                           canvas);
      moon.setColor(new Color(172,213,227));

      moond = new FilledOval(moon.getLocation(),
                            canvas.getWidth()/2,canvas.getWidth()/2,canvas);
      moond.move(moon.getWidth()/4,-moon.getHeight()/8);

      instructions = new Text( "Please click the mouse repeatedly", 20, 20, canvas);
      instructions.setColor(Color.WHITE);
    }

    // Move the moon up a bit each time the mouse is clicked
    public void onMouseClick(Location point) {
       moon.move(0, -10);
       moond.move(0,-10);
       instructions.hide();
    }    

    public void clear(){
      canvas.clear();
   } 
    
}
