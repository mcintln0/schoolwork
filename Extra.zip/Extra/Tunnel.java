// Editing Amanda's accidental tunnel creation code

import objectdraw.*;
import java.awt.*;

public class Tunnel extends WindowController{

  public static void main (String[] args) {
   new Tunnel().startController(800,800); 
  }

  public void begin() {

    for (int i = 0; i < canvas.getWidth()-10; i++){
      FramedOval bob= new FramedOval(400,-100,i+10,i+10,canvas);
    // Allows the "tunnel" to be centered, rather than diagonal!
      bob.move(-bob.getWidth()/2,bob.getHeight()/2);
      bob.setColor(BLUE);
    }   
  }

}
