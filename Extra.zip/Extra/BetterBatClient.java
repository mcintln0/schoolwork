import objectdraw.*;
import java.awt.*;

public class BetterBatClient extends WindowController{   

  public static void main (String[] args) {
    new BetterBatClient().startController(800,800);
  }

  public void begin(){
     Text t=new Text( "Clicking makes things happen!", 10,10,canvas);
     t.setColor(Color.RED);
     t.setFontSize(30);
  }

  private RandomIntGenerator wh= new RandomIntGenerator(20,250);

  public void onMousePress(Location p){
     int w = wh.nextValue();
     int h = wh.nextValue();
     new BetterBat(p, w,h, canvas);
  }

}
