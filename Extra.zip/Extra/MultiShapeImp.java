import objectdraw.*;
import java.awt.*;

public class MultiShapeImp{
   
  private Line [] side;
  private double width;
  private double height;
  private int count = 0;

  public MultiShapeImp(Location p, int sideNum, double length,
                    DrawingCanvas canvas){

    side = new Line[sideNum];

    side[0] = new AngLine(p,  length, 
                -(Math.PI/180)*(360/sideNum),canvas);

    for(int i = 1;i<side.length-1; i++){

        side[i] = new AngLine(side[i-1].getEnd(), length, 
                Math.pow(-1,i)*(2*Math.PI)/sideNum,canvas);

     }

    side[side.length-1] = new Line(side[0].getStart(),side[side.length-2].getEnd(),canvas );

         for(int i = 0;i<side.length; i++)
      side[i].setColor( new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255) ));

  }

}
