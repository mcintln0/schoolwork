import objectdraw.*;
import java.awt.*;

public class Fangs{
   
  private Line [] side;
  private double width;
  private double height;
  private int count = 0;

  public Fangs(Location p, int sideNum, double length,
                    DrawingCanvas canvas){

    side = new Line[sideNum];

    side[0] = new AngLine(p,  length, 
                -(Math.PI/180)*(360/sideNum),canvas);

    for(int i = 1;i<side.length; i++){

      if(i %5 == 0)
        side[i] = new AngLine(side[i-1].getEnd(), length, 
                -(Math.PI/180)*(360/sideNum),canvas);

      if(i %5 == 1)
        side[i] = new AngLine(side[i-1].getEnd(), length, 
                -(Math.PI/180)+(Math.PI/180)*(360/sideNum),canvas);

      if(i %5 == 2)
        side[i] = new AngLine(side[i-1].getEnd(), length, 
                (Math.PI/180),canvas);

      if(i %5 == 3)
        side[i] = new AngLine(side[i-1].getEnd(), length, 
                (Math.PI/180)-(Math.PI/180)*(360/sideNum),canvas);

      if(i %5 == 4)
        side[i] = new AngLine(side[i-1].getEnd(), length, 
                (Math.PI/180)*(360/sideNum),canvas);

     }
