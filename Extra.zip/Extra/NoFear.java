import objectdraw.*;
import java.awt.*;

public class NoFear extends WindowController{

 public static void main(String[] args) {
    new NoFear().startController(800,800);
  }
private Text fear
            ,fal
            ,evi
            ,appe
            ,real
            ,scra
            ,scrb
            ,scrc
            ,scrd
            ,scre
            ,name
            ,date;
private FilledOval nopr;
//                  ,nopb;

private FilledArc lef
                 ,rig;
private FilledRect bacg1
                  ,bacg2
                  ,crss
                  ,crsl;

private int cnt = 0;
private Location recr
                ,botl;

//Put "Fear" in the center of the canvas and place a solid black rectangle behind it
public void begin(){
  bacg1 = new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
  bacg1.setColor(Color.BLACK);
  fear = new Text("FEAR", canvas.getWidth()/2,canvas.getHeight()/2,canvas);
  fear.setColor(new Color(255,0,0));
  fear.setFontSize (150);
  fear.move(-fear.getWidth()/2,-fear.getHeight()/2);
  }

//Replace fear with acronymn
public void onMouseClick(Location point){
  cnt++;
  fear.hide();  
    if(cnt==1){
       fal = new Text ("False",canvas.getWidth()/4,canvas.getHeight()/4,canvas);
       evi = new Text("Evidence",fal.getX(),fal.getY()+80,canvas);
       appe = new Text("Appearing",evi.getX(),evi.getY()+80,canvas);
       real = new Text("Real",appe.getX(),appe.getY()+80,canvas);
       fal.setColor(Color.RED); fal.setFontSize (75);
       evi.setColor(Color.RED); evi.setFontSize (75);
       appe.setColor(Color.RED); appe.setFontSize (75);
       real.setColor(Color.RED); real.setFontSize (75);
              }
    
//Put no sign over fear
    else if (cnt==2){
       nopr = new FilledOval(fal.getX()-75,fal.getY()-50,
                             appe.getWidth()+100, appe.getWidth()+100,canvas);
       nopr.setColor(Color.RED);
//       nopb = new FilledOval(fal.getX(), fal.getY(), appe.getWidth()-50, appe.getWidth()-50, canvas);
//       nopb.setColor(Color.BLACK);
//       nopb.sendToBack();
//       nopr.sendToBack();
//       bacg.sendToBack();
//       recr = new Location (nopb.getX(),nopb.getY());
//       botl = new Location (nopb.getX() + nopb.getWidth(), nopb.getY() + nopb.getWidth());

       recr = new Location (fal.getX(), fal.getY());
       botl = new Location (fal.getX()+ appe.getWidth()-50, fal.getY()+appe.getWidth()-50);


//Add the diagonal
//       rig = new FilledArc (recr,botl,-45,180,canvas);
//       lef = new FilledArc (recr,botl,-45,-180,canvas);  
       rig = new FilledArc (nopr.getX(),nopr.getY(),6*nopr.getWidth()/8,6*nopr.getWidth()/8,-45,180,canvas);
       lef = new FilledArc (nopr.getX(),nopr.getY(),6*nopr.getWidth()/8,6*nopr.getWidth()/8,-45,-180,canvas);  
       lef.move((nopr.getWidth() - lef.getWidth())/2,(nopr.getWidth() - lef.getWidth())/2);
       rig.move((nopr.getWidth() - lef.getWidth())/2,(nopr.getWidth() - rig.getWidth())/2);
       lef.move(-15,15);
       rig.move(15,-15);
       lef.sendToBack();
       rig.sendToBack();
       nopr.sendToBack();
       bacg1.sendToBack();
                      }

//Erase Everything and replace with Phil 3:14
     else if (cnt==3){
       canvas.clear();
       bacg2 = new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
       bacg2.setColor(new Color(0,255,255,100));
       scra = new Text("I can do all",canvas.getWidth()/2,canvas.getHeight()/8,canvas);
       scrb = new Text("things through",canvas.getWidth()/2,scra.getY()+100,canvas);
       scrc = new Text("Christ",canvas.getWidth()/2,scrb.getY()+100,canvas);      
       scrd = new Text("who strengthens me",canvas.getWidth()/2,scrc.getY()+100,canvas);
       scre = new Text("Phil 4:13",canvas.getWidth()/2,scrd.getY()+100,canvas);
       scra.setFontSize(75);
       scrb.setFontSize(75);
       scrc.setFontSize(75);
       scrd.setFontSize(75);
       scre.setFontSize(75);
       scrc.setColor(new Color (138,9,185));
       scra.move(-scra.getWidth()/2,0);
       scrb.move(-scrb.getWidth()/2,0);
       scrc.move(-scrc.getWidth()/2,0);
       scrd.move(-scrd.getWidth()/2,0);
       scre.move(-scre.getWidth()/2,0);
       crss = new FilledRect(3*canvas.getWidth()/4, scre.getY()+ scre.getHeight()+20,140,25,canvas);
       crsl = new FilledRect(3*canvas.getWidth()/4 + crss.getWidth()/2, crss.getY(),25.0,180,canvas);
       crsl.move(-crsl.getWidth()/2,-crsl.getHeight()/4);
                     }
     else {
       canvas.clear();
       new Text("Brought to you by:",canvas.getWidth()/16, canvas.getHeight()/8,canvas).setFontSize(75);
       name = new Text("LaToya McIntyre",canvas.getWidth()/2,
                                                           canvas.getHeight()/2,canvas);
       name.setColor(new Color (178,54,227));
       name.setFontSize(75);
       name.move(-name.getWidth()/2,-name.getHeight()/8);
       date = new Text("Sept 14, 2017 00:00", canvas.getWidth()/2,3*canvas.getHeight()/4,canvas);
       date.setFontSize(75);
       date.move(-date.getWidth()/2,0);
     }
  }

}

// Update / fixed / completed October 11, 2017 10:17 PM
