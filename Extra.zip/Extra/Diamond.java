import objectdraw.*;
import java.awt.*;


public class Diamond extends ActiveObject{
   
  protected RandomIntGenerator bob = new RandomIntGenerator(0,255);
  protected Line top, left, right, slaL, slaR;
  protected double width;
  protected double height;
  protected Line [] part = new Line [5]; 

  public Diamond(double x, double y, double w, double h, DrawingCanvas canvas){
    width = w;
    height = h;
  
    top   = new 
Line(x + w/8 ,y, x + 7*w/8 , y, canvas);

    left  = new Line(top.getStart(), new Location(  x  , y + h/8), canvas);
    right = new Line(top.getEnd()  ,new Location( x + w, y + h/8), canvas);
    
    slaL  = new Line(left.getEnd() ,new Location( x + w/2,y + h), canvas);
    slaR  = new Line(right.getEnd(),slaL.getEnd(), canvas);

 // Makes them sideways is pretty     nested.move(-nested.getWidth(),-nested.getHeight());

    part[0] = top;
    part[1] = left;
    part[2] = right;
    part[3] = slaL;
    part[4] = slaR; 

    start();   
  }

  public Diamond(Location p, double w, double h, DrawingCanvas canvas){
    this(p.getX(),p.getY(),w,h,canvas);
  }

 public double getWidth(){
     return width;
  }
  
  public double getHeight(){
    return height;
  }

  public DrawingCanvas getCanvas(){
     return top.getCanvas();
  }
  
  public void move(double dx, double dy){
    for(int i = 0; i < part.length; i++)
      part[i].move(dx,dy);
  }

  public Location getLocation(){
    return new Location(left.getEnd().getX(), top.getEnd().getY());
  }

  public void setColor(Color c){
    for(Line p: part)
      p.setColor(c);
  }

  public void run(){ }

   public void grow(double scale){
    new Diamond(left.getEnd().getX(),
           top.getEnd().getY(),
           width*scale, 
           height*scale ,top.getCanvas());
  }

}

