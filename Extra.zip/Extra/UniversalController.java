import objectdraw.*;
import java.awt.*;

public class UniversalController extends WindowController{ 

  private static RisingMoonC a,b,c;

  public static void main(String[] args) {

    a = new RisingMoonC();
    b = new RisingMoonC();
    c = new RisingMoonC();
   
    new UniversalController().startController(200,200); 
  }

private FilledRect clr, rst, mv;

s
  public void begin(){
    a.startController();
    b.startController();
    c.startController();

    new FilledRect (0,0,canvas.getWidth(),canvas.getHeight(),canvas);

    mv  = new FilledRect(50,20,30,30,canvas);
    rst = new FilledRect(50,60,30,30,canvas);
    clr = new FilledRect(50,100,30,30,canvas);

    new Text( "Move",90,30,canvas).setColor(new Color(154,44,193));
    new Text( "Reset",90,70,canvas).setColor(new Color(154,44,193));
    new Text( "Clear",90,110,canvas).setColor(new Color(154,44,193));
   
    clr.setColor(Color.WHITE);
    rst.setColor(Color.BLUE);
    mv.setColor(Color.RED);
  }
  public void onMousePress(Location p){
    if(mv.contains(p)){
      a.onMouseClick(p);
      b.onMouseClick(p);
      c.onMouseClick(p);
    }else if(clr.contains(p)){
      a.clear();
      b.clear();
      c.clear();
    }else if(rst.contains(p)){
      a.begin();
      b.begin();
      c.begin();
    }
  }

}
