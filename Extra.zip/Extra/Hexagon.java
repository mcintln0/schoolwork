import objectdraw.*;
import java.awt.*;

public class Hexagon extends ActiveObject{
   
  private RandomIntGenerator bob = new RandomIntGenerator(0,255);
  private AngLine topL, topR, slaTL, slaBL;
  private Line slaTR, slaBR;
  private DrawableInterface [] part = new DrawableInterface [6]; 
  private Hexagon nested;
  private double width;
  private double height;
  private int count = 0;

  public Hexagon(double x, double y, double w, double h, DrawingCanvas canvas){
    width = w;
    height = h;
  
    topL  = new AngLine(x       ,y + h/4   , h/2, -Math.PI/2, canvas);
   
    topR  = new AngLine(x + w   ,y + h/4   , h/2, -Math.PI/2, canvas);
    

  // Using tan to find the angle needed to center the lines of the S
  // Using pythagorem theorem to find the length of the AngLine
    slaTL = new AngLine(topL.getStart(),
                        Math.sqrt(Math.pow(w/2,2) + Math.pow(h/4,2)), 
                        Math.atan((h/4)/(w/2)), canvas);
    slaBL = new AngLine(topL.getEnd(),
                        Math.sqrt(Math.pow(w/2,2) + Math.pow(h/4,2)),
                        - Math.atan((h/4)/(w/2)), canvas);
    
    slaTR = new Line(slaTL.getEnd(), topR.getStart(), canvas);
    slaBR = new Line(slaBL.getEnd(), topR.getEnd(), canvas);
   
   if(w>50 && h>50){
      nested = new Hexagon(x + w/8,y + h/8, w*.75 , h*.75 ,canvas);
      nested.setColor(
           new Color( bob.nextValue(),bob.nextValue(),bob.nextValue() ));
    }

    int i=0;
    part[i++] = topL;
    part[i++] = topR;
    part[i++] = slaTL;
    part[i++] = slaBL;
    part[i++] = slaTR;
    part[i++] = slaBR;

    start();
  }

  public void setColor(Color c){
    for(DrawableInterface p: part)
      p.setColor(c);

    if(nested != null)
      nested.setColor(new Color( c.getRed(),bob.nextValue(), c.getBlue() ));
  }


  public Hexagon(DrawingCanvas canvas){
    this(Math.random()*400+200,Math.random()*400+200,200,200,canvas);
  }

  public double getWidth(){
     return width;
  }
  
  public double getHeight(){
    return height;
  }

  public void move(double dx, double dy){
    for(int i = 0; i < part.length; i++)
      part[i].move(dx,dy);

    if(nested != null)
      nested.move(dx,dy);
  }

  public void run(){
    while(topL != null ){
      if(count%2 == 0)
        setColor(new Color(bob.nextValue(),bob.nextValue(),bob.nextValue()));
    }

    if(nested != null) 
      nested.run();
   
  }

}
