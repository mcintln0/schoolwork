import objectdraw.*;
import java.awt.*;

public class NestedDiam extends Diamond{
   
  private NestedDiam nested;

  public NestedDiam(double x, double y, double w, double h, DrawingCanvas canvas){
    super(x,y,w,h,canvas);
    
    if(w>5 && h>5){
      nested = new NestedDiam(x,y, w*.75 , h*.75 ,canvas);
      nested.move(w/2-nested.getWidth()/2,h/4-nested.getHeight()/4);
      nested.setColor(
           new Color( bob.nextValue(),bob.nextValue(),bob.nextValue() ));
    }

  }

  public NestedDiam(Location p, double w, double h, DrawingCanvas canvas){
    this(p.getX(),p.getY(),w,h,canvas);
  }

  public NestedDiam(DrawingCanvas canvas){
    this(Math.random()*400+200,Math.random()*400+200,100,100,canvas);
  }

  public void move(double dx, double dy){
    super.move(dx,dy);

    if(nested != null)
      nested.move(dx,dy);
  }

  public void setColor(Color c){
    super.setColor(c);

    if(nested != null)
      nested.setColor(new Color( c.getRed(),bob.nextValue(), c.getBlue() ));
  }

  public void run(){
    while(top != null ){
        setColor(new Color(bob.nextValue(),bob.nextValue(),bob.nextValue()));
    }

    if(nested != null) 
      nested.run();
   
  }

}
