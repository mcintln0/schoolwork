import objectdraw.*;
import java.awt.*;

public class InheritanceClient extends WindowController{
 
  private RandomIntGenerator bobbi = new RandomIntGenerator(0,255);
  private Ornament bulb;

  public static void main (String[] args) {
        new InheritanceClient().startController(800,800); 
  }

  public void begin(){
    bulb = new Ornament(canvas.getWidth()/2,canvas.getHeight()/2,400,400, canvas);
    // bob.move(- bob.getWidth()/2,-bob.getHeight()/2);
  }

}
