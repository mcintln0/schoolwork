import objectdraw.*;
import java.awt.*;

public class NoFear2.0 extends WindowController{

 public static void main(String[] args) {
    new NoFear2.0().startController(800,800);
  }

  public void begin(){
    new Fear(50,50,50,canvas);
  }

}
