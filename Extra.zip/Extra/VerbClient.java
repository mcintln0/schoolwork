  // LaToya McIntyre
  // October 19, 2017
  // French Verb Review

import objectdraw.*;
import java.awt.*;

public class VerbClient extends WindowController{

  public static void main (String[] args) {
   new VerbClient().startController(800,800); 
  }
/*
  private Text verb = new Text ("dormir",-50,-50,canvas);
  private Text eng = new Text ("to sleep",-50,-50,canvas);
  private Text je = new Text ("dors",-50,-50,canvas);
  private Text tu = new Text ("dors",-50,-50,canvas);
  private Text il = new Text ("dort",-50,-50,canvas);
  private Text nous = new Text ("dormons",-50,-50,canvas);
  private Text vous = new Text ("dormez",-50,-50,canvas);
  private Text elles = new Text ("dorment",-50,-50,canvas);

  public void onMouseClick(Location p){ 
    new FrenchVerb(p,verb,eng,je,tu,il,nous,vous,elles, canvas);
  }

*/

  public void onMouseClick(Location p){ 
    new FrenchVerb(p, "dormir", "to sleep", "dors", "dors", "dort", "dormons","dormez","dorment",canvas);
  }

}

