  // LaToya McIntyre
  // CS 157 -- Lab12
  // November 16, 2017
  // Test a recursive drawing

import objectdraw.*;
import java.awt.*;

public class SuperC extends WindowController{
 
  private RandomIntGenerator bobbi = new RandomIntGenerator(0,255);
  private SuperS bob;
  private Location lastP;
  private boolean pressed;
  private Diamond beth;

  public static void main (String[] args) {
        new SuperC().startController(800,800); 
  }

  public void begin(){
    new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
    bob = new SuperS(canvas.getWidth()/2,canvas.getHeight()/2,200,200, canvas);
    bob.move(- bob.getWidth()/2,-bob.getHeight()/2);
    beth = new Diamond(canvas.getWidth()/2,canvas.getHeight()/2,
               bob.getWidth()*3,bob.getHeight()*3,canvas);
    beth.move(-beth.getWidth()/2,-beth.getHeight()/2);
  }

  public void onMousePress(Location p){
    lastP = p;
    pressed = bob.contains(p);
  }

  public void onMouseDrag(Location p){
    if (pressed){
      bob.move( p.getX()-lastP.getX() , p.getY()-lastP.getY() );
      lastP = p;
    }
  }
  
  public void onMouseClick(Location p){
    if (pressed)
      bob.change();
  }    

}
