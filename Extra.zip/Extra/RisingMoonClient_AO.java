    // LaToya McIntyre
    // Septmeber 14,2017
    // Homework 2
    // 3.11.4
 
    // A program that produces an animation of the moon rising.

import objectdraw.*;
import java.awt.*;

  public class RisingMoonClient_AO extends WindowController{

  public static void main(String[] args) {
    new RisingMoonClient_AO().startController(800,800);
    }
      
    private Text instructions;

    // Place the moon and some brief instructions on the screen
    public void begin() {
      new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
      new RisingMoon(0,canvas.getHeight()/8,200,200,canvas,Color.BLACK);

//      instructions = new Text( "click the mouse" , 20, 20, canvas);
//      instructions.setColor(Color.WHITE);
    }

    // Remove instructs
//    public void onMouseClick(Location point) {
//       new RisingMoon(0,canvas.getHeight()/8,200,200,canvas,Color.BLACK);
//       instructions.hide();
//   }       
    
}
