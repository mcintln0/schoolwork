import objectdraw.*;
import java.awt.*;

public class BetterBat{

  private Line lL,rL,Lw,Rw,Bw;
  private FilledOval body;
  private FilledRoundedRect head;

  public BetterBat(Location p, double w, double h, DrawingCanvas dc){

    double x = p.getX(), y=p.getY();
    body= new FilledOval(p,w/2,h/2,dc);
    head= new FilledRoundedRect(p,w/4,h/4,10,10,dc);
    head.move(w/2-head.getWidth()/2,0);
    body.move(body.getWidth()/2,head.getHeight());
  
    // Legs

    lL = new Line (body.getX() + body.getWidth()/2, body.getY() + body.getHeight()/2,
                   p.getX(), p.getY() + h,dc);

    rL = new Line (body.getX() + body.getWidth()/2, body.getY() + body.getHeight()/2,
                   p.getX() + w, p.getY() + h,dc);


    // Wings
    Rw = new Line(body.getX()+body.getWidth()/2,body.getY()+3*body.getHeight()/4,
                  p.getX()+w, p.getY()+h/3,dc);

    Lw = new Line(body.getX()+body.getWidth()/2,body.getY()+3*body.getHeight()/4,
                  p.getX(), p.getY()+h/3,dc);

    Bw = new Line(Lw.getEnd(),Rw.getEnd(),dc); 
  }


  public boolean contains (Location p){
    return body.contains(p) || head.contains(p);
  }

  public void move(double dx, double dy){
    lL.move(dx,dy);
    rL.move(dx,dy);
    Lw.move(dx,dy);
    Rw.move(dx,dy);
    Bw.move(dx,dy);
    body.move(dx,dy);
    head.move(dx,dy);
  }
}
