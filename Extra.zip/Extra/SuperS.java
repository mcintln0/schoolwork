  // LaToya McIntyre
  // CS 157 -- Lab12
  // November 16, 2017
  // Create a recursive drawing

import objectdraw.*;
import java.awt.*;

public class SuperS extends BasicS{
   
  private int count = 0;
  private SuperS nested;

  public SuperS(double x, double y, double w, double h, DrawingCanvas canvas){
  // new FramedRect(x,y,w,h,canvas);
    super(x,y,w,h,canvas);
   
   if(w>50 && h>50){
      nested = new SuperS(x + w/8,y + h/8, w*.75 , h*.75 ,canvas);
      nested.setColor(
           new Color( bob.nextValue(),bob.nextValue(),bob.nextValue() ));
    }
  }

  public SuperS(Location p, double w, double h, DrawingCanvas canvas){
    this(p.getX(),p.getY(),w,h,canvas);
  }

  public SuperS(DrawingCanvas canvas){
    this(Math.random()*400+200,Math.random()*400+200,100,100,canvas);
  }

  public void move(double dx, double dy){
    super.move(dx,dy);

    if(nested != null)
      nested.move(dx,dy);
  }

  public void setColor(Color c){
    super.setColor(c);

    if(nested != null)
      nested.setColor(new Color( c.getRed(),bob.nextValue(), c.getBlue() ));
  }

  public boolean contains(Location p){
    return super.contains(p);
  }

  public double getWidth(){
    return width;
  }
  
  public double getHeight(){
    return height;
  }

 // figure out a way to make the 
  public void change(){
    count++;
    if(nested != null)
      nested.change();
  }

  // didn't work
  private void chill(){ }

  public void run(){
    while(topL != null ){
      if(count%2 == 0){
        setColor(new Color(bob.nextValue(),bob.nextValue(),bob.nextValue()));
      }else{ chill();
         }
    }

    if(nested != null) 
      nested.run();
   
  }

  public Location getLocation(){
    return new Location(topL.getStart().getX(), topL.getStart().getY()-height/4);
  }

}
