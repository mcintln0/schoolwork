import objectdraw.*;
import java.awt.*;

public class FunMultiShape extends MultiShape{

  public FunMultiShape(Location p, int sideNum, double length,
                    DrawingCanvas canvas){
    super(p,sideNum,length,canvas);
  }

  public FunMultiShape( double x, double y, int sideNum, double length,
                    DrawingCanvas canvas){
    this(new Location(x,y),sideNum,length,canvas);
  }

  public void run(){
    while(side[0] != null )
      setColor(new Color(bob.nextValue(),bob.nextValue(),bob.nextValue(),
               (int)(Math.random()*100+100)));
       pause(30);
  }

}
