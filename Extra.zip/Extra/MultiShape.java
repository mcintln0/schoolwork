import objectdraw.*;
import java.awt.*;

public class MultiShape extends ActiveObject{
   
  protected Line [] side;
  protected AngLine [] loc;
  private double width;
  private double height;
  private int count = 0;
  protected RandomIntGenerator bob = new RandomIntGenerator(0,255);

  public MultiShape(Location p, int sideNum, double length,
                    DrawingCanvas canvas){

// p is the center

    side = new Line[sideNum];
    loc = new AngLine[sideNum];

    for(int i = 0;i<loc.length; i++)
      loc[i] = new AngLine(p,length, (double)( (2*Math.PI/sideNum)*i ) ,canvas);
     
   
    for(int i = 1; i<side.length;i++)
      side[i] = new Line(loc[i-1].getEnd(),loc[i].getEnd(),canvas);
    
    side[0] = new Line(loc[0].getEnd(), loc[loc.length-1].getEnd(),canvas);

 //   for(int i = 0;i<loc.length; i++)
   //   loc[i].hide();

    start();

  }  

  public void move(double dx,double dy){     
    for(Line s:side)
      s.move(dx,dy);
  
    for(AngLine l: loc)
      l.move(dx,dy);
  }

  public MultiShape( double x, double y, int sideNum, double length,
                    DrawingCanvas canvas){
    this(new Location(x,y),sideNum,length,canvas);
  }

  public void setColor(Color c){

    for(Line s:side)
      s.setColor(c);
  
    for(AngLine l: loc)
      l.setColor(c);

  }

  public void run(){}

}
