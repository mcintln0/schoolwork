// It's lit, making a fear class makes the client so much easier
//  November 1, 2017

import objectdraw.*;
import java.awt.*;

public class Fear{

  private Text fr, fls, evd, appr, rl; 

  public Fear(double x, double y, int fontSize, Color c, DrawingCanvas dc){
     fr = new Text("FEAR",x,y,dc);
     fr.setFontSize(fontSize);
     fr.setColor(c);

     fls  = new Text("False",x,y,dc);
     fls.setFontSize(2*fontSize/3);

     evd  = new Text("Evidence",fls.getLocation(),dc);
     evd.move(fls.getWidth()/5,fls.getHeight() + fontSize/10);
     evd.setFontSize(2*fontSize/3);

     appr = new Text("Appearing",evd.getLocation(),dc);
     appr.move(evd.getWidth()/8,evd.getHeight() + fontSize/10);
     appr.setFontSize(2*fontSize/3);

     rl   = new Text("Real",appr.getLocation(),dc);
     rl.move(appr.getWidth()/10,appr.getHeight() + fontSize/10);
     rl.setFontSize(2*fontSize/3);

     fls.setColor(c);
     evd.setColor(c);
     appr.setColor(c);
     rl.setColor(c);
 
     fls.hide();
     evd.hide();
     appr.hide();
     rl.hide();
  }

  public Fear( Location p, int fontSize, Color c, DrawingCanvas dc){
    this(p.getX(),p.getY(), fontSize, c, dc);
  }

  public Fear( Location p, int fontSize, DrawingCanvas dc){
    this(p.getX(),p.getY(), fontSize, Color.BLACK, dc);
  }

  public Fear( double x, double y, int fontSize, DrawingCanvas dc){
    this(x,y, fontSize, Color.BLACK, dc);
  }

  public Fear( Location p, DrawingCanvas dc){
    this(p.getX(),p.getY(), 100, Color.BLACK, dc);
  }

  public Fear( double x, double y, Color c, DrawingCanvas dc){
    this(x,y, 100, c, dc);
  }

  public void next(){
     fr.hide();
     fls.show();
     evd.show();
     appr.show();
     rl.show();
  }

  public void hide(){
     fr.hide();
     fls.hide();
     evd.hide();
     appr.hide();
     rl.hide();  
  }

  public void setFontSize(int fontSize){
     fr.setFontSize(fontSize);
     fls.setFontSize(fontSize);
     evd.setFontSize(fontSize);
     appr.setFontSize(fontSize);
     rl.setFontSize(fontSize);  
  }

  public void move(double dx, double dy){
     fr.move(dx,dy);
     fls.move(dx,dy);
     evd.move(dx,dy);
     appr.move(dx,dy);
     rl.move(dx,dy); 
  }

  public void moveTo(double x, double y){
     move(x-fr.getX(),y-fr.getY());
  }

  public double getHeight (){
    if (fls.isHidden()){
      return fr.getHeight();
    }else{
      return ((rl.getY() + rl.getHeight())-fls.getY());
    }
  }

  public double getWidth(){
    if (fls.isHidden()){
      return fr.getWidth();
    }else{
      return ((appr.getX() + appr.getWidth())-fls.getX());
    }
  }

} 


