// Nov 1, 2017

import objectdraw.*;
import java.awt.*;

public class NoFear2 extends WindowController{

 public static void main(String[] args) {
    new NoFear2().startController(800,800);
  }

  private Fear none;
  private int cnt = 0;

  public void begin(){
    new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
    none =  new Fear(canvas.getWidth()/2,canvas.getHeight()/2,150,Color.RED,canvas);
    none.move(-none.getWidth()/2,-none.getHeight()/2);
  }

  public void onMousePress(Location p){
    cnt++;
    switch (cnt){
      case 1:
        none.next();
        none.moveTo(canvas.getWidth()/2,canvas.getHeight()/2);
        none.move(-none.getWidth()/2,-none.getHeight()/2);
      break;
      case 2:
        none.hide();
        love.moveTo(canvas.getWidth()/2,canvas.getHeight()/2);
        love.move(-none.getWidth()/2,-none.getHeight()/2);
      break;

}
