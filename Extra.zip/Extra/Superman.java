import objectdraw.*;
import java.awt.*;

public class Superman extends Diamond{

private SuperS bob;
   
  public Superman(double x, double y, double w, double h, DrawingCanvas canvas){

    super(x,y,w,h,canvas);
    bob = new SuperS(x,y,w*.50,h*.50,canvas);
   bob.move(w/2-bob.getWidth()/2,h/2-bob.getHeight()/2);
  
  }

  public void grow( double scale){
    super.grow(scale);
    bob.grow(scale);
  }

}
