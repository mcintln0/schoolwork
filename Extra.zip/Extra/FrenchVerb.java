  // LaToya McIntyre
  // October 19, 2017 12.05AM
  // A french review

import objectdraw.*;
import java.awt.*;

public class FrenchVerb{
  private FramedRect box;
  private Text display,verb,eng,je,tu,il,nous,vous,elles;
  private int cnt = 0;

  public FrenchVerb(double x, double y,Text word, Text define, Text i, Text you,
                    Text he, Text we, Text youF, Text they, DrawingCanvas dc){
    display = new Text(word,x,y,dc);
    box  = new FramedRect(x,y,verb.getWidth()+5,verb.getHeight()+5,dc);
    verb.move(box.getWidth()/2-verb.getWidth()/2,box.getHeight()/2-verb.getHeight()/2);
    verb = word;
    eng = define;
    je = i;
    tu = you;
    il = he;
    nous = we;
    vous = youF;
    elles = they;
  }
  
  public FrenchVerb(Location p,Text word, Text define, Text i, Text you,
                    Text he, Text we, Text youF, Text they, DrawingCanvas dc){
    this(p.getX(), p.getY(),word,define,i,you,he,we,youF,they,dc);
  
  public onMouseClick(Location p){
     cnt++
     switch (cnt){
       case 0:
       display.setText(verb);
       break;
       case 1:
       display.setText(je);
       break;
       case 2:
       display.setText(tu);
       break;
       case 3:
       display.setText(il);
       break;
        case 4:
       display.setText(nous);
       break;
        case 5:
       display.setText(vous);
       break;
        case 6:
       display.setText(elles);
       cnt = -1;
       break;
    }
  }

}
 
/* public class FrenchVerb{
  private FramedRect box;
  private String display,verb,eng,je,tu,il,nous,vous,elles;
  private int cnt = 0;

  public FrenchVerb(double x, double y,String word, String define, String i, String you,
                    String he, String we, String youF, String they, DrawingCanvas dc){
    display = String(word,x,y,dc);
    box  = new FramedRect(x,y,display.getWidth()+5,display.getHeight()+5,dc);
    display.move(box.getWidth()/2-display.getWidth()/2,box.getHeight()/2-display.getHeight()/2);
    verb = word;
    eng = define;
    je = i;
    tu = you;
    il = he;
    nous = we;
    vous = youF;
    elles = they;
  }
  
  public FrenchVerb(Location p,String word, String define, String i, String you,
                    String he, String we, String youF, String they, DrawingCanvas dc){
    this(p.getX(), p.getY(),word,define,i,you,he,we,youF,they,dc);
  }
  
  public void onMouseClick(Location p){
     cnt++;
     switch (cnt){
       case 0:
       display.setString(verb);
       break;
       case 1:
       display.setString(je);
       break;
       case 2:
       display.setString(tu);
       break;
       case 3:
       display.setString(il);
       break;
        case 4:
       display.setString(nous);
       break;
        case 5:
       display.setString(vous);
       break;
        case 6:
       display.setString(elles);
       cnt = -1;
       break;
    }
  }
*/  
        

