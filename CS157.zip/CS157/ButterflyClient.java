  // LaToya McIntyre
  // CS 157 -- Lab 7
  // October 12, 2017
  // Create a program to test your flying object

import objectdraw.*;
import java.awt.*;

public class ButterflyClient extends WindowController {

  public static void main(String[] args) {
    new ButterflyClient().startController(800,800);
  }
  
  private RandomIntGenerator dim = new RandomIntGenerator (50,400);
  private RandomIntGenerator rgb = new RandomIntGenerator (0,255);

  public void onMousePress(Location p){
    int dimn = dim.nextValue();
    Butterfly bunny = new Butterfly(p,dimn,dimn,canvas);
    bunny.setColor(new Color(rgb.nextValue(),rgb.nextValue(),rgb.nextValue()));
  }

}

