  // LaToya McIntyre
  // October 16, 2017
  // CS 157
  // HW 5 - 2e
  // Creates a border of dice around the canvas

import objectdraw.*;
import java.awt.*;

public class BorderClient extends WindowController{

  public static void main (String[] args) {
   new BorderClient().startController(800,820); 
  }


  public void begin(){ 
    int diceX = 0;
    while(diceX<=canvas.getWidth() - 50){
      new Dice(diceX,0,50,50,canvas).roll();
      new Dice(diceX,750,50,50,canvas).roll();
      diceX = diceX + 50;
    }
    int diceY = 50;
   while(diceY<canvas.getHeight()-50){
      new Dice(0,diceY,50,50,canvas).roll();
      new Dice(750,diceY,50,50,canvas).roll();
      diceY = diceY + 50;
    }
  }
}

