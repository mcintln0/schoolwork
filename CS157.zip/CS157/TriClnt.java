import objectdraw.*;
import java.awt.*;

public class TriClnt extends WindowController{
  
  public static void main(String[] args){
    new TriClnt().startController(800,800);
  }


  private FilledTri t;

  public void begin(){
    t = new FilledTri(50,50,100,100,canvas);
  }

  public void onMousePress(Location p){
    t.setColor(new Color( (int) (Math.random()*255),
                          (int) (Math.random()*255),
                          (int) (Math.random()*255) ));

  }
}
