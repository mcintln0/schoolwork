  // LaToya McIntyre
  // CS 157 -- Lab12
  // November 16, 2017
  // Create a recursive drawing of an S

import objectdraw.*;
import java.awt.*;

public class SuperS extends ActiveObject{
   
  private RandomIntGenerator bob = new RandomIntGenerator(0,255);
  private AngLine topL, topM, topR, botL, botM, botR, slaTL, slaBL;
  private Line midL, midR, slaTR, slaBR;
  private DrawableInterface [] part = new DrawableInterface [12]; 
  private SuperS nested;
  private double width;
  private double height;
  private int count = 0;

  public SuperS(double x, double y, double w, double h, DrawingCanvas canvas){
    width = w;
    height = h;
  
    topL  = new AngLine(x       ,y + h/4   , h/6, -Math.PI/2, canvas);
    topM  = new AngLine(x + w/2 ,y + h/4   , h/6, -Math.PI/2, canvas);
    topR  = new AngLine(x + w   ,y + h/4   , h/6, -Math.PI/2, canvas);
    
    botL  = new AngLine(x       ,y + 7*h/12, h/6, -Math.PI/2, canvas);
    botM  = new AngLine(x + w/2 ,y + 7*h/12, h/6, -Math.PI/2, canvas);
    botR  = new AngLine(x + w   ,y + 7*h/12, h/6, -Math.PI/2, canvas);

  // Using tan to find the angle needed to center the lines of the S
  // Using pythagorem theorem to find the length of the AngLine
    slaTL = new AngLine(topL.getStart(),
                        Math.sqrt(Math.pow(w/2,2) + Math.pow(h/4,2)), 
                        Math.atan((h/4)/(w/2)), canvas);
    slaBL = new AngLine(botL.getEnd(),
                        Math.sqrt(Math.pow(w/2,2) + Math.pow(h/4,2)),
                        - Math.atan((h/4)/(w/2)), canvas);
    
    midL  = new Line(topL.getEnd(), botM.getStart(), canvas);
    midR  = new Line(topM.getEnd(), botR.getStart(), canvas);
    slaTR = new Line(slaTL.getEnd(), topR.getStart(), canvas);
    slaBR = new Line(slaBL.getEnd(), botR.getEnd(), canvas);
   
   if(w>50 && h>50){
      nested = new SuperS(x + w/8,y + h/8, w*.75 , h*.75 ,canvas);
      nested.setColor(
           new Color( bob.nextValue(),bob.nextValue(),bob.nextValue() ));
    }
  // Must set all parts into array separately or the array loop will not work
    int i=0;
    part[i++] = topL;
    part[i++] = topM;
    part[i++] = topR;
    part[i++] = botL;
    part[i++] = botM;
    part[i++] = botR;
    part[i++] = slaTL;
    part[i++] = slaBL;
    part[i++] = midL;
    part[i++] = midR;
    part[i++] = slaTR;
    part[i++] = slaBR;

    start();
  }

  public void move(double dx, double dy){
    for(int i = 0; i < part.length; i++)
      part[i].move(dx,dy);

    if(nested != null)
      nested.move(dx,dy);
  }

  public void setColor(Color c){
    for(DrawableInterface p: part)
      p.setColor(c);
    // if I want the nested ot be a different color then I must do it this way 
    if(nested != null)
      nested.setColor(new Color( c.getRed(),bob.nextValue(), c.getBlue() ));
  }

  public boolean contains(Location p){
  // if the mouse is within the "box" of S then it will return true
    if(p.getX() > topL.getStart().getX() &&
       p.getX() < botR.getEnd().getX()   &&
       p.getY() > slaTL.getEnd().getY()  &&
       p.getY() < slaBL.getEnd().getY()){
      return true;
    }else{
      return false;
    }
  }

  public double getWidth(){
     return width;
  }
  
  public double getHeight(){
    return height;
  }

 // figure out a way to make the run method restart
  public void change(){
    count++;
    if(nested != null)
      nested.change();
  }

  public void run(){
    while(topL != null ){
      if(count%2 == 0)
        setColor(new Color(bob.nextValue(),bob.nextValue(),bob.nextValue()));
    }

    if(nested != null) 
      nested.run();
   
  }
  
  public Location getLocation(){
    return new Location(topL.getStart().getX(),
               topL.getStart().getY()-height/4);
  }

}
