  // LaToya McIntyre
  // October 16, 2017
  // CS 157
  // HW 5 - 2c
  // Creates three dice, and displays the results and informs the user if they
  // rolled pairs, or triples of the same number


import objectdraw.*;
import java.awt.*;

public class DiceyClient extends WindowController{

  public static void main(String[] args) {
    new DiceyClient().startController(800,800);
  }

  private Dice di1,
               di2,
               di3;
  private Text dice1,
               dice2,
               dice3,
               display = new Text("Roll the Dice",0,0,canvas);

  public void begin(){

    di1 = new Dice(canvas.getWidth()/4,canvas.getHeight()/4,50,50,canvas);
    di2 = new Dice(canvas.getWidth()/2,canvas.getHeight()/4,50,50,canvas);
    di3 = new Dice(3*canvas.getWidth()/4,canvas.getHeight()/4,50,50,canvas);

    dice1 = new Text("The first dice rolled: ",100,300,canvas);
    dice2 = new Text("The second dice rolled: ",100,350,canvas);
    dice3 = new Text("The third dice rolled: ",100,400,canvas); 
   
    dice1.setFontSize(25);
    dice2.setFontSize(25);
    dice3.setFontSize(25);

    display.setFontSize(25);
    display.move(canvas.getWidth()/2 - display.getWidth(),50);
  }

  public void onMouseClick(Location p){   
    di1.roll();
    di2.roll();
    di3.roll();
   
    dice1.setText("The first dice rolled: " + di1.getValue());
    dice2.setText("The second dice rolled: " + di2.getValue());
    dice3.setText("The third dice rolled: " + di3.getValue());

  // Set the special text
  if (di1.getValue()==di2.getValue() && di2.getValue()==di3.getValue()){
    display.setText("You rolled three " + di1.getValue() + "'s !");
    display.setColor(new Color(124,19,170));
    }

  else if((di1.getValue()==di2.getValue())||(di1.getValue()==di3.getValue())
          ||(di2.getValue()==di3.getValue())){
    display.setColor(new Color(71,237,187));
      if((di1.getValue()==di2.getValue())||(di1.getValue()==di3.getValue())){
        display.setText("You rolled a pair of " + di1.getValue() +"'s !");
      }else{
        display.setText("You rolled a pair of " + di2.getValue() +"'s !");
      }
   }
  
  else{
     display.setText("That was nothing special, try again");
     display.setColor(Color.BLACK);
     }
  }
}
