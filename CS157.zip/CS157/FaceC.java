import objectdraw.*;
import java.awt.*;

public class FaceC extends WindowController{

  public static void main(String[] args) {
    new FaceC().startController(800,800);
  }

  public void onMouseClick(Location p){
    new FunnyFace(p.getX(),p.getY(),canvas);
  }
}
