  // LaToya McIntyre
  // CS 157 - HW 4
  // 6.C.M
  // October 5, 2017
  // Class that creates a mouse

import objectdraw.*;
import java.awt.*;

public class CrazyMouse {

  private final Color MOUSE_GRAY = new Color (204, 204, 204);

  private FilledOval body;
  private FramedArc tail;

  public CrazyMouse(Location p, DrawingCanvas dc){

    body = new FilledOval(p, 50,30, dc );
    body.setColor(MOUSE_GRAY);

    tail = new FramedArc(p, body.getWidth(),body.getHeight(), 90,180, dc );
    tail.move(-body.getWidth()/2,-body.getHeight()/2);
    tail.setColor(new Color (212,128,55));
  }

  public CrazyMouse(double x, double y, DrawingCanvas dc){
    this ( new Location (x,y), dc );
  }

  public boolean contains(Location p){
    return body.contains(p); 
  }

  public void move(double dx, double dy){
    body.move(dx, dy);
    tail.move(dx, dy);
  }
}

