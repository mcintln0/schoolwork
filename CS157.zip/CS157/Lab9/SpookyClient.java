  // LaToya McIntyre
  // CS 157 -- Lab 9
  // October 26, 2017
  // Create a Halloween themed scenario

import objectdraw.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SpookyClient extends WindowController implements ActionListener{

  public static void main(String [] args){
	new SpookyClient().startController(800,800);
  }

  private JTextField input;
  private JButton spooky;
  private JComboBox<String> color;
  private Bat batty;
  private Color valueChosen;

  private RandomDoubleGenerator dim = new RandomDoubleGenerator (50,400);
  private RandomDoubleGenerator spook = new RandomDoubleGenerator (0,100);
  private RandomIntGenerator res = new RandomIntGenerator (100,800);

  public void begin(){
    new FilledRect(0,0,canvas.getHeight(), canvas.getWidth(),canvas);
  
    input = new JTextField("Enter text:");
    spooky = new JButton ("SURPRISE");
    color = new JComboBox<String>();
      color.addItem("Purple");
      color.addItem("White");
      color.addItem("Orange");

      color.setSelectedItem("White");

      valueChosen = new Color(195,182,212);

    Container contentPane=getContentPane();
    contentPane.add(input, BorderLayout.NORTH);
    contentPane.add(spooky, BorderLayout.WEST);
    contentPane.add(color, BorderLayout.SOUTH);
    contentPane.validate(); 

    color.addActionListener(this);
    spooky.addActionListener(this);
 
    batty = new Bat(dim.nextValue(),dim.nextValue(),
                    dim.nextValue(),dim.nextValue(),canvas);
    batty.setColor(new Color(195,182,212));
  }

  public void onMousePress(Location p){
    String str = input.getText();
    new Text (str,p,canvas).setColor(Color.RED);   
  }

  public void actionPerformed(ActionEvent evt){
    if (evt.getSource() == spooky){
      batty.move(spook.nextValue(),spook.nextValue());
      this.resize(res.nextValue(),res.nextValue());

    }else if(evt.getSource() == color){
    Object newValue = color.getSelectedItem(); 
      if ( newValue.equals("Purple") ) {
         valueChosen = new Color(130,7,175);
      }else if(newValue.equals("White") ) {
         valueChosen = new Color(195,182,212);
      }else{
         valueChosen = new Color(214,97,24);
      }
    batty.setColor(valueChosen);
    }
  }
}
