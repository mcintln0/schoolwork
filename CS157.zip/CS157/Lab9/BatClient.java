  // LaToya McIntyre
  // CS 157 -- Lab 9
  // October 26, 2017
  // Create a Halloween themed object

import objectdraw.*;
import java.awt.*;

public class BatClient extends WindowController{

  public static void main(String [] args){
	new BatClient().startController(800,800);
  }

 private RandomDoubleGenerator dim = new RandomDoubleGenerator (100,400);

  public void onMousePress(Location p){
    new Bat(p,dim.nextValue(),dim.nextValue(),canvas);
  }

}
