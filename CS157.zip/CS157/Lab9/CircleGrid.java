  // LaToya McIntyre
  // CS 157 -- HW 6
  // October 27, 2017
  // Create a circle grid class

import objectdraw.*;
import java.awt.*;
  
  public class CircleGrid{
    private FramedOval circle;

  public CircleGrid(double rows, double columns, Location p,
                    DrawingCanvas canvas, Color c){
    int row = 0;
    while (row < rows){
      int col = 0;
      double start = p.getX();
      while(col<columns){
        circle = new FramedOval(start,p.getY(), 30,30, canvas);
        start = start + 25;
        col++;
        circle.setColor(c);
      }
      p.translate(0,25);
      row++;
    }
  }

   public CircleGrid(double rows, double columns, Location p,
                    DrawingCanvas canvas){ 
     this(rows, columns, p, canvas, Color.BLACK);
  }

}

