  // LaToya McIntyre
  // CS 157 -- Lab 9
  // October 26, 2017
  // Create a Halloween themed object

import objectdraw.*;
import java.awt.*;

public class Bat implements Drawable157{

  private FilledOval body, lEye, rEye;
  private FilledArc lWing, rWing, lEar, rEar;
  private Line rLeg, lLeg;
  private double height;
  private double width;
  private Location origin;

  public Bat(double x, double y, double w, double h,
             DrawingCanvas canvas){
  height = h;
  width = w;
  origin = new Location(x,y);

  // Wings
  rWing = new FilledArc(x,y,2*w/3,7*h/12, 60, 180, canvas);
  lWing = new FilledArc(x,y,2*w/3,7*h/12,-60, 180, canvas);  
  rWing.setColor(new Color(82,82,82));
  lWing.setColor(new Color(82,82,82));

  lWing.move(lWing.getWidth()/2-w/2,h/2-lWing.getHeight()/2);
  rWing.move(w/2,h/2-rWing.getHeight()/2);

  // Ears
  rEar = new FilledArc(x,y,w/5,h/2, 60, 180, canvas);
  lEar = new FilledArc(x,y,w/5,h/2,-60, 180, canvas);  
  rEar.move(5*w/8,0);
  lEar.move(w/4,0);


  // Body
  body  = new FilledOval(x,y,2*w/3,2*h/3, canvas);
  body.move(w/2-body.getWidth()/2,h/2-body.getHeight()/2);

  // Legs
  rLeg = new Line(x,y+h,
                  body.getX()+body.getWidth()/2,
                  body.getY()+body.getHeight()/2,canvas);
  lLeg = new Line(x+w,y+h,
                  body.getX()+body.getWidth()/2,
                  body.getY()+body.getHeight()/2,canvas);
  
  // Eyes
  lEye  = new FilledOval(body.getLocation(),w/8,h/8, canvas);
  rEye  = new FilledOval(body.getLocation(),w/8,h/8, canvas);
  lEye.move(body.getWidth()/4,body.getHeight()/4);
  rEye.move(5*body.getWidth()/8,body.getHeight()/4);
  lEye.setColor(Color.RED);
  rEye.setColor(Color.RED); 

  }

  public Bat(Location p, double w, double h,
             DrawingCanvas canvas){
  this (p.getX(),p.getY(),w,h,canvas);
  }

  public void setColor(Color c){
    body.setColor(c);
    lEar.setColor(c);
    rEar.setColor(c);
    rLeg.setColor(c);
    lLeg.setColor(c);

    lWing.setColor(new Color(c.getBlue(),c.getGreen(),c.getRed()));
    rWing.setColor(new Color(c.getBlue(),c.getGreen(),c.getRed()));

    rEye.setColor(new Color(c.getRed(),c.getBlue(),c.getGreen()));
    lEye.setColor(new Color(c.getRed(),c.getBlue(),c.getGreen()));
  }

  public boolean contains(Location p){
    return 
      (body.contains(p) || lWing.contains(p) || rWing.contains(p) || 
      lEar.contains(p) || rEar.contains(p));   
  }

  // Accessor Methods for the Bat
  public double getHeight(){
    return  height;
  } 

  public double getWidth(){
    return  width;
  } 
 
  public Location getLocation(){
    return origin;
  }

  public double getY(){
    return  origin.getY(); 
  }

  public double getX(){
    return  origin.getX(); 
  }

  public void move(double dx, double dy){
   body.move(dx,dy);
   lEye.move(dx,dy);
   rEye.move(dx,dy);
   lWing.move(dx,dy);
   rWing.move(dx,dy);
   lEar.move(dx,dy);
   rEar.move(dx,dy);
   lLeg.move(dx,dy);
   rLeg.move(dx,dy);
  }

  public void moveTo(double x, double y){
    move(x-origin.getX(),y-origin.getY());
  }

  public void moveTo(Location p){
    move(p.getX()- origin.getX(), p.getY()-origin.getY());
  }

  public void removeFromCanvas(){
    body.removeFromCanvas();
    lEye.removeFromCanvas();
    rEye.removeFromCanvas();
    lWing.removeFromCanvas();
    rWing.removeFromCanvas();
    lEar.removeFromCanvas();
    rEar.removeFromCanvas();
    lLeg.removeFromCanvas();
    rLeg.removeFromCanvas();
  }

  public void hide(){
    body.hide();
    lEye.hide();
    rEye.hide();
    lWing.hide();
    rWing.hide();
    lEar.hide();
    rEar.hide();
    lLeg.hide();
    rLeg.hide();
  }

  public void show(){
    body.show();
    lEye.show();
    rEye.show();
    lWing.show();
    rWing.show();
    lEar.show();
    rEar.show();
    lLeg.show();
    rLeg.show();
  }
} 
