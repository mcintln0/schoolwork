   // LaToya McIntyre
   // Septmeber 14,2017
   // A program that produces an animation of the moon rising.
   // The animation is driven by clicking the mouse button.
   // The faster the mouse is clicked, the faster the moon will rise.


import objectdraw.*;
import java.awt.*;

  public class RisingMoon extends ActiveObject{

    private FilledOval moond,
                       moon;  

    public  RisingMoon(double x, double y, double width, double height, DrawingCanvas canvas, Color background) {
      moon = new FilledOval(x,y,width,height, canvas);
      moond = new FilledOval(x,y,width,height,canvas);
      moon.setColor(new Color(172,213,227));
      moond.move(moon.getWidth()/4,-moon.getWidth()/4);
      moond.setColor(background);
   
      start();
    }

    public  RisingMoon(Location p, double width, double height,
                       DrawingCanvas canvas, Color background){
      this(p.getX(),p.getY(), width, height, canvas, background);
    }

    public  RisingMoon(Location p, double width, double height,
                       DrawingCanvas canvas){
      this(p.getX(),p.getY(), width, height, canvas, Color.WHITE);
    }

    public  RisingMoon(double x, double y, double width, double height,
                       DrawingCanvas canvas){
      this(x,y, width, height, canvas, Color.WHITE);

    }

    // Move the moon up a bit each time the mouse is clicked
    public void move(double dx, double dy) {
       moon.move(dx,dy);
       moond.move(dx,dy);
    } 

    public void removeFromCanvas(){
       moon.removeFromCanvas();
       moond.removeFromCanvas();
    }
  
    public void run(){

    while(moon.getX() < moon.getCanvas().getWidth()/2 - moon.getWidth()/2){
      move(10,-2);
      pause(75);
      }
    while ((moon.getX() >= moon.getCanvas().getWidth()/2 - moon.getWidth()/2) &&
            moon.getX() < moon.getCanvas().getWidth()){
      move(10,2);
      pause(75);
    }
    removeFromCanvas();
    }     
}
