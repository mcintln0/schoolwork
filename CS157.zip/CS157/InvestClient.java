import java.util.Scanner;
import java.awt.*;

public class InvestClient
  
  static Scanner question;
  static int start,
             length;
  static double amount,
                rate;  

  public static void main(String[] args) {

  System.out.printf("Do you want to enter your own digits? (1 = no 2 = yes) ");
    question = new Scanner(System.in);
   
    if (question.nextDouble() == 1) 
      new Investing(2018,25,1000,10);

    if (question.nextDouble() == 2){

     System.out.printf("Starting Year: ");
     Scanner year = new Scanner(System.in);
     start = year.nextInt();

     System.out.printf("Length of time: ");
     Scanner time = new Scanner(System.in);
     length = year.nextInt();

     System.out.printf("Amount of Money: ");
     Scanner money = new Scanner(System.in);
     amount = money.nextDouble();

     System.out.printf("Interest Rate: ");
     Scanner interest = new Scanner(System.in);
     rate = interest.nextDouble();

     new Investing(start,length,amount,rate);
    
  }
  }
}
