  // LaToya McIntyre
  // October 16, 2017
  // CS 157
  // HW 5 - 2c
  // A dice class, that can roll itself and return the value

import objectdraw.*;
import java.awt.*;

public class Dice{

  private RandomIntGenerator diceV = new RandomIntGenerator(1,6);
  private FramedRect frame;
  private FilledRect fill;
  private FilledOval spot1, 
                     spot2,
                     spot3,
                     spot4,
                     spot5,
                     spot6,
                     spot7;
    
  private int di1;
              
  public Dice(double x, double y, double w, double h, DrawingCanvas canvas){
    fill  = new FilledRect(x,y,w,h,canvas);
    fill.setColor(Color.WHITE);
    frame = new FramedRect(x,y,w,h,canvas);
    spot1 = new FilledOval(x,y,w/6,h/6,canvas); 
    spot2 = new FilledOval(x,y,w/6,h/6,canvas);
    spot3 = new FilledOval(x,y,w/6,h/6,canvas);
    spot4 = new FilledOval(x,y,w/6,h/6,canvas);
    spot5 = new FilledOval(x,y,w/6,h/6,canvas);
    spot6 = new FilledOval(x,y,w/6,h/6,canvas);
    spot7 = new FilledOval(x,y,w/6,h/6,canvas);

    spot1.move(w/6,h/6);
    spot2.move(w/6,h/2-spot2.getHeight()/2);
    spot3.move(w/6,4*h/6);

    spot4.move(2*w/3,h/6);
    spot5.move(2*w/3,h/2-spot5.getHeight()/2);
    spot6.move(2*w/3,4*h/6);

    spot7.move(w/2-spot7.getWidth()/2,h/2-spot7.getHeight()/2);
    spot7.hide();

  }
  
  public Dice(Location p, double w, double h, DrawingCanvas canvas){
     this( p.getX(), p.getY(), w, h, canvas );
  }


  public void roll(){   
    di1 = diceV.nextValue();
   
   switch (di1){
     case 1:
       spot1.hide(); 
       spot2.hide(); 
       spot3.hide(); 
       spot4.hide(); 
       spot5.hide(); 
       spot6.hide(); 
       spot7.show();
       break;
     case 2:
       spot1.hide(); 
       spot2.show(); 
       spot3.hide(); 
       spot4.hide(); 
       spot5.show(); 
       spot6.hide(); 
       spot7.hide();
       break;
     case 3:
       spot1.show(); 
       spot2.hide(); 
       spot3.hide(); 
       spot4.hide(); 
       spot5.hide(); 
       spot6.show(); 
       spot7.show();
       break;
     case 4:
       spot1.show(); 
       spot2.hide(); 
       spot3.show(); 
       spot4.show(); 
       spot5.hide(); 
       spot6.show(); 
       spot7.hide();
       break;
     case 5:
       spot1.show(); 
       spot2.hide(); 
       spot3.show(); 
       spot4.show(); 
       spot5.hide(); 
       spot6.show(); 
       spot7.show();
       break;
     case 6:
       spot1.show(); 
       spot2.show(); 
       spot3.show(); 
       spot4.show(); 
       spot5.show(); 
       spot6.show(); 
       spot7.hide();
       break;
    }
  }

  public int getValue(){
    return di1;
  }
  
  public void setColor( Color c){
    fill.setColor(c);
  }

  public Color getColor(){
    return  fill.getColor();
  }
}

     
     
