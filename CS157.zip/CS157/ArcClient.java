
import objectdraw.*;
import java.awt.*;

public class ArcClient extends WindowController{

  public static void main(String[] args) {
    new ArcClient().startController(800,800);
  }

//Starts at 'angle' at 0 degress of a constructed Rectangle
//    new FilledArc(x-coord of rect,y-coord of rect,width of arc,height of arc, starting angle,angle of the arc, canvas); 
 public void onMouseClick(Location point){
    new FilledArc(100,100,300,300, 0,180, canvas);
    new FramedRect(100,100,300,300, canvas);
    new FramedArc(100,100,300,300, -30,-180, canvas).setColor(Color.RED);
  }

  public void onMouseExit(Location point){
  }


}
