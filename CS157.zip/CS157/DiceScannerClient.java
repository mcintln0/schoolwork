  // LaToya McIntyre
  // October 16, 2017
  // CS 157
  // HW 5 - 2d
  // Creates a diagonal of dice. number of dice is determined by the user

import objectdraw.*;
import java.awt.*;
import java.util.Scanner;

public class DiceScannerClient extends WindowController{

  // declares as instance variable, needs static to use in "static void main"
    static Scanner dic;
    static int userI;

  public static void main (String[] args) {

   dic = new Scanner(System.in);

   System.out.printf
     ("\n\tPlease enter an integer bewtween 3 & 10 then hit return: ");
   userI = dic.nextInt(); 
   while (userI < 3 || userI > 10){
     System.out.printf
       ("\n\tPlease enter an integer bewtween 3 & 10 then hit return: ");
     userI = dic.nextInt(); 
     }

   new DiceScannerClient().startController(800,800); 

  }

  private RandomDoubleGenerator loc = new RandomDoubleGenerator (0,250); 

  public void begin(){ 
    Location diceL = new Location (loc.nextValue(),loc.nextValue());
    int cnt = 0;
    while(cnt<userI){
      new Dice(diceL,50,50,canvas).roll();
      diceL.translate(50,50);
      cnt++;
    }
  }
}

