  // LaToya McIntyre
  // CS 157 -- HW 9
  // Basis of the interactive Finale Client

import objectdraw.*;
import java.awt.*;

public class TV extends FilledRect{
  
  protected Text words;
  protected FilledRect screen; 

  public TV(double x, double y, double width, double height, DrawingCanvas canvas){
    super(x,y,width,height,canvas);
    screen = new FilledRect(x + width/16 , y + height/16 ,
                            7*width/8, 7*height/8,canvas);
    screen.setColor(Color.GRAY);
    super.setColor(Color.BLACK);
  }

  public TV(Location p, double width, double height, DrawingCanvas canvas){
    this(p.getX(), p.getY(), width,height, canvas );
  }
   
  // Mutator methods
  public void move( double dx, double dy){
    super.move(dx,dy);
    screen.move(dx,dy);
  }

  public void moveTo( double x, double y){
    move(x-super.getX(),y-super.getY());

  }

  public void moveTo(Location p){
    move(p.getX()-super.getX(),p.getY()-super.getY());
  }

  public void setColor( Color c){
    screen.setColor(c);
  }

  public boolean contains(Location p){
    return super.contains(p);   
  }

  public void hide(){
    super.hide();
    screen.hide();
  }

  public void show(){
    super.show();
    screen.show();
  }

  // Accessor Methods for the TV
  public double getHeight(){
    return  super.getHeight();
  } 

  public double getWidth(){
    return  super.getWidth();
  } 

  public double getX(){
    return  super.getX();
  }

  public double getY(){
    return  super.getY();
  }

  public double screenGetX(){
    return  screen.getX();
  }

  public double screenGetY(){
    return  screen.getY();
  }

  public Location screenGetLocation(){
    return  screen.getLocation();
  }

  public double screenGetHeight(){
    return  screen.getHeight();
  } 

  public double screenGetWidth(){
    return  screen.getWidth();
  } 

  public Color getColor(){
    return  screen.getColor();
  }

  public Location getLocation(){
    return  super.getLocation();
  }

}
