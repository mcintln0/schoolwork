  // LaToya McIntyre
  // CS 157 -- HW 9
  // Displays different balls, within the same set


import objectdraw.*;
import java.awt.*;

public class BallClient extends WindowController{
  
  public static void main(String[] args){
    new BallClient().startController(350,350);
  }


  public void begin(){
    new FilledOval(50,50,100,100,canvas);
    new RubberBall(200,50,100,canvas); 
    new TennisBall(50,200,100,canvas);   
    new BasketBall(200,200,100,canvas);  
    

  }


}
