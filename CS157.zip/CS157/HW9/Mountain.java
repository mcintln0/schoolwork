  // LaToya McIntyre
  // CS 157 -- HW 9
  // Apart of the background for the nature scene

import objectdraw.*;
import java.awt.*;

public class Mountain{
  
  private AngLine [] peak;

  public Mountain(double x, double y, double width, double height,
               DrawingCanvas canvas){
    peak = new AngLine[(int)(2*width)];

    // The width is changing not the height!
    // Using the height as a constant requires less computing
    // and makes the code easier to change later on 
    for(int i = 0; i<peak.length; i++){
      peak[i] = new AngLine(x,y,
                height/Math.sin( Math.atan(height/((width-i)/2))),
               -Math.atan(height/((width-i)/2)),
                canvas);
      peak[i].move(width/2,0);
    }
  }

  public Mountain(Location p, double width, double height,
               DrawingCanvas canvas){
    this(p.getX(),p.getY(),width,height,canvas);
  }

  // Mutator methods
  public void setColor(Color c){
    for(AngLine m: peak)
     m.setColor(c);
  }

  public void move( double dx, double dy){
    for(AngLine m: peak)
      m.move(dx,dy);
  }

  public void moveTo( double x, double y){
    move(x-peak[0].getStart().getX(),y-peak[0].getStart().getY());

  }

  public void moveTo(Location p){
    move(p.getX()-peak[0].getStart().getX(),
         p.getY()-peak[0].getStart().getY());
  }


  public void hide(){
    for(AngLine m: peak)
      m.hide();
  }

  public void show(){
    for(AngLine m: peak)
     m.show();
  }


}
