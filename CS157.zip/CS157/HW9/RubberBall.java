  // LaToya McIntyre
  // CS 157 -- HW 9
  // RubberBall

import objectdraw.*;
import java.awt.*;

public class RubberBall extends FilledOval{

  protected FramedOval border;

  public RubberBall(double x, double y, double size,
                    DrawingCanvas canvas){
    super(x,y,size,size,canvas);
    setColor(Color.RED);
    border = new FramedOval(x,y,size,size,canvas);

  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    border.move(dx,dy);
  }

  public void moveTo(double x, double y){
    move(x-getX(),y-getY());
  }

}
