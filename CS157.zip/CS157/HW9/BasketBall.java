  // LaToya McIntyre
  // CS 157 -- HW 9
  // BasketBall

import objectdraw.*;
import java.awt.*;

public class BasketBall extends TennisBall{

  private Line horizontal, vertical;

  public BasketBall(double x, double y, double size,
                    DrawingCanvas canvas){
    super(x,y,size,canvas);
    setColor(Color.ORANGE);

    horizontal = new Line(x,y+size/2, x+size,y+size/2,canvas);
    vertical   = new Line(x+size/2,y, x+size/2,y+size,canvas);
  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    horizontal.move(dx,dy);
    vertical.move(dx,dy);
  }

  public void moveTo(double x, double y){
    move(x-getX(),y-getY());
  }

}
