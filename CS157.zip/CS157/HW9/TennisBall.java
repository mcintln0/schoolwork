  // LaToya McIntyre
  // CS 157 -- HW 9
  // TennisBall

import objectdraw.*;
import java.awt.*;

public class TennisBall extends RubberBall{

  private FramedArc top, bot;

  public TennisBall(double x, double y, double size,
                    DrawingCanvas canvas){
    super(x,y,size,canvas);
    setColor(Color.YELLOW);

    bot = new FramedArc(x,y+size*2/3,size,size,45,90,canvas);
    top = new FramedArc(x,y-size*2/3,size,size,-45,-90,canvas);
  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    top.move(dx,dy);
    bot.move(dx,dy);
  }

  public void moveTo(double x, double y){
    move(x-getX(),y-getY());
  }

}
