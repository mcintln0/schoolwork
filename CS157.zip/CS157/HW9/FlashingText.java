  // LaToya McIntyre
  // CS 157 -- HW 9
  // Creates an active object that swicthes bewteen colors to make a flashing
  // effect

import objectdraw.*;
import java.awt.*;

public class FlashingText extends ActiveObject{
  
  protected Text words;
  protected Location origin;  

  public FlashingText(String text, double x, double y, DrawingCanvas canvas){
    origin = new Location (x,y);
    words = new Text(text,x,y,canvas);
    start();
  }


  public FlashingText(String text, Location p, DrawingCanvas dc){
    this(text, p.getX(), p.getY(), dc );
  }
   
  // Mutator methods
  public void move( double dx, double dy){
    words.move(dx,dy);
  }

  public void moveTo( double x, double y){
    move(x-words.getX(),y-words.getY());
  }

  public void moveTo(Location p){
    move(p.getX()-words.getX(),p.getY()-words.getY());
  }

  public void setColor( Color c){
    words.setColor(c);
  }

  public void setFontSize(int size){
    words.setFontSize(size);
  }

  public void setText(String newText){
    words.setText(newText);
  }

  public boolean contains(Location p){
    return words.contains(p);   
  }

  // Accessor Methods
  public double getHeight(){
    return  words.getHeight();
  } 

  public double getWidth(){
    return  words.getWidth();
  } 

  public double getX(){
    return  words.getX();
  }

  public double getY(){
    return  words.getY();
  }

  public Color getColor(){
    return  words.getColor();
  }

  public boolean isHidden(){
    return  words.isHidden();
  }

  public Location getLocation(){
    return  words.getLocation();
  }

  public void hide(){
    words.hide();
  }

  public void show(){
    words.show();
  }

  public void sendToFront(){
    words.sendToFront();
  }

  public void run(){
    while(words.isHidden() != true){
      setColor(Color.RED);
      pause(20);
      setColor(Color.BLACK);
      pause(20);
    }
  }

}
