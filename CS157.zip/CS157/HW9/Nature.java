  // LaToya McIntyre
  // CS 157 -- HW 9
  // Shows passage through the day

import objectdraw.*;
import java.awt.*;

public class Nature extends Sky{

  protected Mountain [] peak =  new Mountain [3];

  public Nature(double x, double y, double width, double height,
             DrawingCanvas canvas){
    super(x,y,width,height,canvas);  
    
    for(int i = 0; i < peak.length; i++)
      peak[i] = new Mountain(x + i*width/3, y + 2*height/3, 
                             width/3, height/3,canvas);
  }

   public Nature(Location p, double width, double height,
             DrawingCanvas canvas){
     this(p.getX(),p.getY(),width,height,canvas);
  }

  // Mutator methods
  public void move( double dx, double dy){
    super.move(dx,dy);
    for(Mountain l: peak)
      l.move(dx,dy);
  }

  public void moveTo( double x, double y){
    move(x-super.getX(),y-super.getY());

  }

  public void moveTo(Location p){
    move(p.getX()-super.getX(),p.getY()-super.getY());
  }

  public void setColor( Color c){
    super.setColor(c);
  }

  public boolean contains(Location p){
    return super.contains(p);   
  }

  public void hide(){
    super.hide();

    for(Mountain l: peak)
      l.hide();
  }

  public void show(){
    super.show();

    for(Mountain l: peak)
     l.show();
  }

  public void sceneSetColor(Color c){

    for(Mountain l: peak)
     l.setColor(c);
   }

  // Accessor Methods for the scenery
  public double getHeight(){
    return  super.getHeight();
  } 

  public double getWidth(){
    return  super.getWidth();
  } 

  public double getX(){
    return  super.getX();
  }

  public double getY(){
    return  super.getY();
  }

  public Color getColor(){
    return  super.getColor();
  }

  public Location getLocation(){
    return  super.getLocation();
  }

} 


