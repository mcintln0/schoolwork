  // LaToya McIntyre
  // CS 157 -- HW 9
  // Comet headed for Earth

import objectdraw.*;
import java.awt.*;

public class Death extends ActiveObject{

  protected FilledOval comet;

  public Death(double x, double y, double width, double height,
               DrawingCanvas canvas){
    comet = new FilledOval(x,y,width,height,canvas);
    comet.setColor(Color.RED);
    start();
  }

  public Death(Location p, double width, double height,
               DrawingCanvas canvas){
    this(p.getX(),p.getY(),width,height,canvas);
  }

  public void hide(){
    comet.hide();
  }

  public void move(double dx,double dy){
    comet.move(dx,dy);
  }

  public void moveTo(double dx,double dy){
    comet.moveTo(dx,dy);
  }

  public void setSize(double width,double height){
    comet.setSize(width,height);  
  }

  public double getX(){
    return  comet.getX();
  }

  public double getY(){
    return  comet.getY();
  }

  public double getWidth(){
    return  comet.getWidth();
  }

  public double getHeight(){
    return  comet.getHeight();
  }

  public void setColor( Color c){
    comet.setColor(c);
  }

  public void grow(){
    comet.setSize(comet.getWidth()*1.2,comet.getHeight()*1.2);
  }

  public void run(){
    comet.sendToFront();

    while(getX() > 0 || getY() > 800) {
      move(-50,10);
      grow();
      pause(100);
    }

    while(comet.getX() <= 0){
      moveTo(-400,-400);
      comet.setSize(comet.getCanvas().getWidth()*2,
                    comet.getCanvas().getHeight()*2);
    }
  }


}
 
