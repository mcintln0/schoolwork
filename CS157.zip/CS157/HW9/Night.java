  // LaToya McIntyre
  // CS 157 -- HW 9
  // Subset of the Sky class and superset of the Destruction class

import objectdraw.*;
import java.awt.*;

public class Night extends Nature{
  
  private RandomDoubleGenerator dim = new RandomDoubleGenerator(2,5);

  protected FilledRect star [] = new FilledRect[101];

  public Night(double x, double y, double width, double height,
               DrawingCanvas canvas){
    super(x,y,width,height,canvas);
    super.setColor(Color.BLACK);
    super.sceneSetColor(new Color(20,20,20));
    
    int cnt = 0;
    double xV = Math.random()*800;
    double yV = Math.random()*400;

    for(int i = 0; i<star.length;i++){
      star[i] = new FilledRect(xV,yV,dim.nextValue(),dim.nextValue(),canvas);
      star[i].setColor(Color.WHITE);

      xV = 50+Math.random()*(cloud[0][0].getCanvas().getWidth()-100); 
      yV = Math.random()*(3* cloud[0][0].getCanvas().getHeight()/4);
    }


    for(int i = 0; i<cloud.length;i++)
      for(int h = 0; h<cloud[i].length;h++){
        cloud[i][h].setColor(new Color(20,20,20));
        cloud[i][h].sendToFront();
      }

  }

  public Night(Location p, double width, double height, DrawingCanvas canvas){
    this(p.getX(), p.getY(), width,height, canvas );
  }

  public void hide(){
    super.hide();
    for(FilledRect s: star)
      s.hide();
  }

}
