  // LaToya McIntyre
  // CS 157 -- HW 9
  // Controls an end of the world news broadcast, cycles through the final day
  // on earth, was going for a movie scence type of vibe

import objectdraw.*;
import java.awt.*;
import java.util.*;
import java.io.*;

public class FinaleClient extends WindowController{
  
  // Must throw or catch when requesting filenames from user
  public static void main(String[] args) throws FileNotFoundException{

    Scanner sc = new Scanner(System.in);
    System.out.printf("\nEnter a text file, that contains encouraging words:");
    String filename = sc.next();

    Scanner file = new Scanner(new File(filename));

    while(file.hasNext())
      input = input +" "+ file.next() ;

    new FinaleClient().startController(800,800);

   
  }

  private static String input = "";
  private ActiveText news,news1,fin;
  private FlashingText choice;
  private Text instr;
  private TV tele;
  private Nature day;
  private Destroy finale;
  private FilledRect cont;
  private FramedRect frame;
  private int cnt = 0;
  private Butterfly [] flyers = new Butterfly [5];

  public void begin(){
    tele = new TV(0,0,canvas.getWidth(),canvas.getHeight(),canvas);   
    tele.setColor(Color.RED);

    news = new ActiveText("Breaking News!!! The World Ends Soon",
                         800, tele.screenGetY() + 25,canvas);
    news1 = new ActiveText("Comet Headed For Earth",
                         800, tele.screenGetHeight(),canvas);
    news.setFontSize(40);
    news1.setFontSize(40);

    //Construction of the continue button
    cont = new FilledRect(tele.screenGetWidth()/2,tele.screenGetHeight()/2,
                          100,100,canvas);
    cont.move(-cont.getWidth()/2, -cont.getHeight()/2);
    choice = new FlashingText("Continue?" , cont.getLocation(), canvas);
    choice.setFontSize(40);
    choice.move(0,choice.getHeight()/2);
    cont.setSize(choice.getWidth(),2*choice.getHeight());
    frame = new FramedRect(cont.getLocation(),cont.getWidth(),
                           cont.getHeight(),canvas);
    instr = new Text("Pressing makes things happen!", 500,750,canvas);
    instr.setColor(Color.WHITE);

    // Prevents multiple constructions of the final message
    fin = new ActiveText(input, tele.screenGetWidth()/2,
                         tele.screenGetHeight()/2,canvas);
    fin.setFontSize(40);
    fin.setColor(Color.BLUE);
    fin.hide();
  }

  public void onMousePress(Location p){
   cnt++;
    if(cnt == 1){
      instr.hide();
      news.setText("Enjoy your last look of the skys");
      news1.hide();
      day = new Nature(tele.screenGetLocation(),tele.screenGetWidth(),
              tele.screenGetHeight(),canvas);
     
      for(int i = 0; i<flyers.length; i++){
        flyers[i] = new Butterfly(50+100*i,600-20*i, 50,50,canvas);

      news.sendToFront();
      }

    }else if( cnt == 2){
      for(Butterfly b: flyers)
        b.hide();
      day.hide();
      news.hide();
      finale = new Destroy(tele.screenGetLocation(),tele.screenGetWidth(),
               tele.screenGetHeight(),canvas);
    }else{
      finale.hide();
      cont.hide();
      choice.hide();
      frame.hide();
      tele.hide();
      fin.show();

    }

  }


}
