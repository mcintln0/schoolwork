  // LaToya McIntyre
  // CS 157 -- HW 9
  // Part of the Destruction Scene

import objectdraw.*;
import java.awt.*;

public class Destroy extends Night{

  protected Death death;

  public Destroy(double x, double y, double width, double height,
               DrawingCanvas canvas){
    super(x,y,width,height,canvas);
    death = new Death(x+width, y+height/4,width/32,height/32,canvas);
    death.move(-death.getWidth()/2,-death.getHeight()/2);
    
  }

  public Destroy(Location p,double width, double height, DrawingCanvas canvas){
    this(p.getX(), p.getY(), width,height, canvas );
  }

  public double deathGetX(){
    return  death.getX();
  }

  public void hide(){
    super.hide();
    death.hide();
  }

}
