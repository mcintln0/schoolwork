  // LaToya McIntyre
  // CS 157 -- HW 9
  // Subset of the FlashingText Class, allows the text to move across screen

import objectdraw.*;
import java.awt.*;

public class ActiveText extends FlashingText{

  private Color mainC;

  public ActiveText(String text, double x, double y, Color c, 
                    DrawingCanvas canvas){
    super(text,x,y,canvas);
    mainC = c;
  }

  public ActiveText(String text, Location p, DrawingCanvas dc){
    this(text, p.getX(), p.getY(), Color.BLACK, dc );
  }

  public ActiveText(String text, double x, double y, DrawingCanvas dc){
    this(text, x, y, Color.BLACK, dc );
  }

  // Mutator methods
  public void move( double dx, double dy){
    super.move(dx,dy);
  }

  public void moveTo( double x, double y){
    move(x-super.getX(),y-super.getY());
  }

  public void moveTo(Location p){
    move(p.getX()-super.getX(),p.getY()-super.getY());
  }

  public void setColor( Color c){
    words.setColor(c);
    mainC = c;
  }

  public void setFontSize(int size){
    super.setFontSize(size);
  }

  public void setText(String newText){
    super.setText(newText);
  }

  public boolean contains(Location p){
    return super.contains(p);   
  }

  public void sendToFront(){
    super.sendToFront();
  }

  // Accessor Methods
  public double getHeight(){
    return  super.getHeight();
  } 

  public double getWidth(){
    return  super.getWidth();
  } 

  public double getX(){
    return  super.getX();
  }

  public double getY(){
    return  super.getY();
  }

  public Color getColor(){
    return  super.getColor();
  }

  public void run(){
    // Can't use super run because it is an infinite loop and won't continue to
    // the move part of this active object
    while(5>2){
      super.setColor(Color.RED);
      pause(20);
      super.setColor(mainC);
      pause(20);
      super.move(-10,0);
      pause(50);

    if(super.getX() < -super.getWidth())
      super.moveTo(origin);
    }
  }

}
