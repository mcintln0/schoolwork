  // LaToya McIntyre
  // CS 157 -- HW 9
  // Basis of the sky scenes. A typical cloudy day

import objectdraw.*;
import java.awt.*;

public class Sky extends FilledRect{

  protected FilledOval [][] cloud = new FilledOval[3][3];

  public Sky(double x, double y, double width, double height,
             DrawingCanvas canvas){
    super(x,y,width,height,canvas);  
    super.setColor(new Color(171,234,255));
     
    //First Cloud
    cloud[0][0] = new FilledOval(x+width/16,y+height/8, 
                                 3*width/16,height/8,canvas);
    cloud[0][1] = new FilledOval(x+width/8,y+height/16, 
                                 3*width/16,height/8,canvas);
    cloud[0][2] = new FilledOval(x+3*width/16,y+height/8,
                                 3*width/16,height/8,canvas);

    // Second Cloud
    cloud[1][0] = new FilledOval(x+5*width/8,y+height/8, 
                                 3*width/16,height/8,canvas);
    cloud[1][1] = new FilledOval(x+11*width/16,y+height/16,
                                 3*width/16,height/8,canvas);
    cloud[1][2] = new FilledOval(x+3*width/4,y+height/8,
                                 3*width/16,height/8,canvas);  

    // Third Cloud
    cloud[2][0] = new FilledOval(x+5*width/16,y+5*height/16,
                                 3*width/16,height/8,canvas);
    cloud[2][1] = new FilledOval(x+6*width/16,y+height/4, 
                                 3*width/16,height/8,canvas);
    cloud[2][2] = new FilledOval(x+7*width/16,y+5*height/16, 
                                 3*width/16,height/8,canvas);

    for(int i = 0; i<cloud.length;i++)
      for(int h = 0; h<cloud[i].length;h++)
        cloud[i][h].setColor(Color.WHITE);
  }

  public Sky(Location p, double width, double height, DrawingCanvas canvas){
    this(p.getX(), p.getY(), width,height, canvas );
  }
   
  // Mutator methods
  public void move( double dx, double dy){
    super.move(dx,dy);

    for(int i = 0; i<cloud.length;i++)
      for(int h = 0; h<cloud[i].length;h++)
        cloud[i][h].move(dx,dy);
  }

  public void moveTo( double x, double y){
    move(x-super.getX(),y-super.getY());

  }

  public void moveTo(Location p){
    move(p.getX()-super.getX(),p.getY()-super.getY());
  }

  public void setColor( Color c){
    super.setColor(c);
  }

  public boolean contains(Location p){
    return super.contains(p);   
  }

  public void hide(){
    super.hide();

    for(int i = 0; i<cloud.length;i++)
      for(int h = 0; h<cloud[i].length;h++)
        cloud[i][h].hide();

  }

  public void show(){
    super.show();

    for(int i = 0; i<cloud.length;i++)
      for(int h = 0; h<cloud[i].length;h++)
        cloud[i][h].show();
  }

  public void cloudSetColor(Color c){

    for(int i = 0; i<cloud.length;i++)
      for(int h = 0; h<cloud[i].length;h++)
        cloud[i][h].setColor(c);

  }

  // Accessor Methods for the TV
  public double getHeight(){
    return  super.getHeight();
  } 

  public double getWidth(){
    return  super.getWidth();
  } 

  public double getX(){
    return  super.getX();
  }

  public double getY(){
    return  super.getY();
  }

  public Color getColor(){
    return  super.getColor();
  }

  public Location getLocation(){
    return  super.getLocation();
  }

}
