import objectdraw.*;
import java.awt.*;

public class tias extends WindowController{
   
  public static void main(String[] args) {
    new tias().startController(800,800);
  }
  

  public void onMouseClick(Location p){
     double w = (100+Math.random()*200);
     double h = (100+Math.random()*200);
    new Death(p,w,h,canvas);
  }

}


