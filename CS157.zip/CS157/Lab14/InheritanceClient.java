  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Using inheritance create multiple shapes

import objectdraw.*;
import java.awt.*;

public class InheritanceClient extends WindowController{
 
  private FilledRect move, show, hide;
  private Text m,s,h;

  private FilledOval origin,surprise;
  private Ornament bulb;
  private RayOrnament bob;
  private ImageOrnament bae;
  private BandedBall bub;

  private int cnt = 0;

  private FilledOval [] bulbs = new FilledOval[5];

  public static void main (String[] args) {
        new InheritanceClient().startController(800,800); 
  }

  public void begin(){
    new Text("Clicking makes new shapes, leaving canvas resets the window",
             10,10,canvas);

    move = new FilledRect(600, 50,100,50,canvas);
    show = new FilledRect(600,150,100,50,canvas);
    hide = new FilledRect(600,250,100,50,canvas);

    m = new Text("Move", move.getLocation(), canvas);
    m.setFontSize(20);
    m.setColor(Color.WHITE);
    m.move(move.getWidth()/2 - m.getWidth()/2, 
           move.getHeight()/2 - m.getHeight()/2);

    s = new Text("Show", show.getLocation(), canvas);
    s.setFontSize(20);
    s.setColor(Color.WHITE);
    s.move(show.getWidth()/2 - s.getWidth()/2, 
           show.getHeight()/2 - s.getHeight()/2);

    h = new Text("Hide", hide.getLocation(), canvas);
    h.setFontSize(20);
    h.setColor(Color.WHITE);
    h.move(hide.getWidth()/2 - h.getWidth()/2,
           hide.getHeight()/2 - h.getHeight()/2);

    origin = new FilledOval(200,50,100,100, canvas);
    bulb   = new Ornament(100,150,100,100, canvas);
    bob    = new RayOrnament(100,300,100,100, canvas); 
    // Image must be requested in Client because class doesn't have getImage()
    bae    = new ImageOrnament(100,450,100,100,getImage("Galaxy.jpg"), canvas);
    bub    = new BandedBall(300,150,100,100, canvas);

    bulbs[0] = origin;
    bulbs[1] = bulb;
    bulbs[2] = bob;
    bulbs[3] = bae;
    bulbs[4] = bub;
  }

  public void onMouseClick(Location p){
    if (move.contains(p)){
      for( FilledOval b: bulbs)
        b.move(50,50);
    }else if(show.contains(p)){
      for( FilledOval b: bulbs)
        b.show();
    }else if(hide.contains(p)){
      for( FilledOval b: bulbs)
        b.hide();
    }else{

      // Varies the shapes produced between two types of filled ovals
      if(cnt%2==0){
        surprise = new ImageOrnament(p.getX(),p.getY(), 100,100,
                        getImage("Seal.jpg"),canvas);
      }else{
        surprise = new Change(p, 100,100,canvas);
      }
    }
    cnt++;
  }

  public void onMouseExit(Location p){
    canvas.clear();
    begin();
  }


}
