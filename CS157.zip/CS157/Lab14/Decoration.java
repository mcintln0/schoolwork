  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Recursive shaped being used as a decoration on a banded ball

import objectdraw.*;
import java.awt.*;

public class Decoration extends ActiveObject{
   
  private RandomIntGenerator bob = new RandomIntGenerator(0,255);
  private Line top, left, right, slaL, slaR;
  private Decoration nested;
  private double width;
  private double height;
  private int count = 0;
  private Line [] part = new Line [5]; 

  public Decoration(double x, double y, double w, double h,
                    DrawingCanvas canvas){
    width = w;
    height = h;
  
    top   = new Line(x + w/8 ,y, x + 7*w/8 , y, canvas);

    left  = new Line(top.getStart(), new Location(  x  , y + h/8), canvas);
    right = new Line(top.getEnd()  ,new Location( x + w, y + h/8), canvas);
    
    slaL  = new Line(left.getEnd() ,new Location( x + w/2,y + h), canvas);
    slaR  = new Line(right.getEnd(),slaL.getEnd(), canvas);

    if(w>50 && h>50){
      nested = new Decoration (x+w/2,
                            y+h/2,
                            w*.75 , h*.75 ,canvas);
      nested.move(-nested.getWidth(),-nested.getHeight());
      nested.setColor(
           new Color( bob.nextValue(),bob.nextValue(),bob.nextValue() ));
    }

    part[0] = top;
    part[1] = left;
    part[2] = right;
    part[3] = slaL;
    part[4] = slaR; 

    start();   
  }

  public Decoration(Location p, double w, double h, DrawingCanvas canvas){
    this(p.getX(),p.getY(),w,h,canvas);
  }

 public double getWidth(){
     return width;
  }
  
  public double getHeight(){
    return height;
  }
 
  public void move(double dx, double dy){
    for(int i = 0; i < part.length; i++)
      part[i].move(dx,dy);

    if(nested != null)
      nested.move(dx,dy);
  }

  public Location getLocation(){
    return new Location(left.getEnd().getX(), top.getEnd().getY());
  }

  public void setColor(Color c){
    for(Line p: part)
      p.setColor(c);
    // if I want the nested ot be a different color then I must do it this way 
    if(nested != null)
      nested.setColor(new Color( c.getRed(),bob.nextValue(), c.getBlue() ));
  }

   public void run(){
    while(top != null ){
      if(count%2 == 0)
        setColor(new Color(bob.nextValue(),bob.nextValue(),bob.nextValue()));
    }

    if(nested != null) 
      nested.run();
  }

}
