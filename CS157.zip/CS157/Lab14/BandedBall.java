  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Using inheritance create multiple shapes

import objectdraw.*;
import java.awt.*;

public class BandedBall extends FilledOval{

  protected FilledRoundedRect band; 

  public BandedBall(double x, double y, double width, double height, DrawingCanvas canvas){
    super(x,y,width,height,canvas);
    
    band = new FilledRoundedRect( x,y,width, height/4, width/10,height/10, canvas);   
    band.move(0,height/2-band.getHeight()/2);
    band.setColor(new Color(199,167,72));

  }

  public void setColor(Color c){
    super.setColor(c);
  }

  public void bandSetColor(Color c){
    band.setColor(c);
  }

  public boolean contains(Location p){
    return super.contains(p) || band.contains(p); 
  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    band.move(dx,dy);
  }

  public void hide(){
    super.hide();
    band.hide();
  }

  public void show(){
    super.show();
    band.show();
  }

}
