  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Creates a basic ornament inherited from FilledOval

import objectdraw.*;
import java.awt.*;

public class Ornament extends FilledOval{

  protected FramedArc handle; 
  protected FilledRect cap;
  protected FramedOval rim;

  
  public Ornament(double x, double y, double width, double height, DrawingCanvas canvas){
    // In order for super to work it must be the first line of the method
    super(x,y + height/8 ,width,7*height/8,canvas);
    rim = new FramedOval(x,y + height/8,width,7*height/8,canvas);

    cap = new FilledRect( x,y+height/16, 3*width/16, height/8, canvas);
    cap.move(width/2 - cap.getWidth()/2 ,0);
    cap.setColor(Color.BLACK);

    handle = new FramedArc(x,y, 3*width/16, height/8, 0,180, canvas);
    handle.move(width/2 - cap.getWidth()/2 ,0);
    handle.setColor(Color.BLACK);
   
    super.sendToFront();
    super.setColor(new Color(199,167,72));
    rim.sendToFront();
  }

  public void setColor(Color c){
    super.setColor(c);
  }

  public boolean contains(Location p){
    return super.contains(p) || cap.contains(p) || handle.contains(p); 
  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    cap.move(dx,dy);
    handle.move(dx,dy);
    rim.move(dx,dy);
  }

  public void hide(){
    super.hide();
    cap.hide();
    handle.hide();
    rim.hide();
  }

  public void show(){
    super.show();
    cap.show();
    handle.show();
    rim.show();
  }

}

