  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Using inheritance create multiple shapes

import objectdraw.*;
import java.awt.*;

public class ImageOrnament extends RayOrnament{

  protected VisibleImage photo;
  
  // Image has to be passed as a parameter because the image cannot be 
  // gotten from within the class
  public ImageOrnament(double x, double y, double width, double height,
                       Image pic, DrawingCanvas canvas){
    super(x,y,width,height,canvas);
    super.setColor(new Color(99,13,168));

    photo = new VisibleImage(pic,x,y,width/2,height/2,canvas);
    photo.move(width/2-photo.getWidth()/2,height/2-photo.getHeight()/2);
  }

  public boolean contains(Location p){
    return super.contains(p); 
  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    photo.move(dx,dy);
  }

  public void hide(){
    super.hide();
    photo.hide();
  }

  public void show(){
    super.show();
    photo.show();
  }

  public void setColor(Color c){
      super.setColor(c);    
  }

}
