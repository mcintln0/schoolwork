  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Using inheritance create multiple shapes

import objectdraw.*;
import java.awt.*;

public class RayOrnament extends Ornament{

  protected FilledArc [] spiral = new FilledArc[6]; 

  public RayOrnament(double x, double y, double width, double height, 
                     DrawingCanvas canvas){
    super(x,y,width,height,canvas);
    super.setColor(Color.BLACK);

    for(int i = 0; i<spiral.length; i++){
    spiral[i] = new FilledArc(rim.getX(),rim.getY(),
                              rim.getWidth(),rim.getHeight(),
                              i*60+30,30,canvas);
    spiral[i].setColor(new Color(72,167,199));
    }
  }

  // Base color of the ornament cannot be changed, only the spirals
  public void setColor(Color c){
    for(FilledArc s: spiral)
      s.setColor(c);    
  }

  public boolean contains(Location p){
    return super.contains(p); 
  }

  public void move(double dx, double dy){
    super.move(dx,dy);
    for(FilledArc s: spiral)
      s.move(dx,dy);
  }

  public void hide(){
    super.hide();
    for(FilledArc s: spiral)
      s.hide();
  }

  public void show(){
    super.show();
    for(FilledArc s: spiral)
      s.show();
  }


}
