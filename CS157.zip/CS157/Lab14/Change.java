  // LaToya McIntyre
  // CS 157 -- Lab14
  // December 7, 2017
  // Using inheritance create multiple shapes

import objectdraw.*;
import java.awt.*;

public class Change extends BandedBall{

  private Decoration decor;

  public Change(Location p, double width, double height,DrawingCanvas canvas){
      super(p.getX(),p.getY(),width,height,canvas);
      super.setColor(new Color(99,13,168));
      super.bandSetColor(Color.BLACK);
  
      decor = new Decoration(p, width/4,height/4,canvas);
      decor.move(super.getWidth()/2 - decor.getWidth()/2,
                 super.getHeight()/2 -decor.getHeight()/2);
      
  }

}
