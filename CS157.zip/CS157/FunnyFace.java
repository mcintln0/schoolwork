  // LaToya McIntyre
  // CS 157 - HW 4
  // 6.8.3
  // October 5, 2017
  // Class that creates a funny face


import objectdraw.*;
import java.awt.*;

  // When creating a class for java to use the easiest structure is constant
  // definitions, variable declarations, construction, then the methods

  // Name of class
public class FunnyFace{

  // Componenets of the class
  public static final int Face_Height = 60,
                          Face_Width = 60,

                          Eye_Offset = 20,
                          Eye_Radius = 8,

                          Mouth_Height = 10,
                          Mouth_Width = Face_Width/2;

  private FramedOval head, leftEye, rightEye, mouth;

  // Create pieces of funny face
  public FunnyFace( double left, double top, DrawingCanvas canvas){
    head = new FramedOval(left, top,Face_Width, Face_Height, canvas);
    mouth = new FramedOval(left+(Face_Width-Mouth_Width)/2,top+2*Face_Height/3,
                           Mouth_Width, Mouth_Height,canvas);
    leftEye = new FramedOval(left + Eye_Offset - Eye_Radius/2,top+Eye_Offset,
                            Eye_Radius, Eye_Radius,canvas); 
    rightEye = new FramedOval (left + Face_Width-Eye_Offset - Eye_Radius/2, 
                              top+Eye_Offset,Eye_Radius,Eye_Radius,canvas);

  }

  // Move funny face by (dx,dy)
  public void move(double dx, double dy){
    head.move(dx,dy);
    leftEye.move(dx,dy);
    rightEye.move(dx,dy);
    mouth.move(dx,dy);
  }

  // Determine where pt is inside funny face
  public boolean contains( Location pt){
    return head.contains(pt);
  }

  // Hide funny face
  public void hide(){
    head.hide();
    leftEye.hide();
    rightEye.hide();
    mouth.hide();
  }

  public double getX(){
    return  head.getX();
  }

  public double getY(){
    return  head.getY();
  }

  public void setEyeColor(Color c){
    leftEye.setColor(c);
    rightEye.setColor(c);
  } 

  public void removeFromCanvas(){
    head.removeFromCanvas();
    leftEye.removeFromCanvas();
    rightEye.removeFromCanvas();
    mouth.removeFromCanvas();
  }
}  

