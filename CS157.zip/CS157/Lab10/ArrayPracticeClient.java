    // LaToya McIntyre
    // CS 157 -- Lab 10
    // November 2, 2017
    // Practice with arrays

import java.util.Scanner;

public class ArrayPracticeClient {

  static Scanner scan;

  public static void main (String[] args) {


    // declare a scanner to read from standard input
   
    scan = new Scanner(System.in);
    int cnt = 0;


    // ask user for value of cnt until we get something between 1 and 25
    // SOPf the value of cnt (Be informative! A number alone is not enough.)
  do{
    System.out.printf
     ("\n\tPlease enter an integer bewtween 1 & 25 then hit return: ");
     cnt = scan.nextInt(); 
   }while (cnt < 1 || cnt > 25);

     System.out.printf("\n The index of count is %d \n", cnt);

    // declare and construct an array of integers 
    // that can store exactly that many values, ie cnt

    int count [] = new int [cnt];

    // Loop #1:
    // read (request) all the values, exactly cnt many of them, from the command line
    // and place them in the elements of your array

    for(int i = 0; i<cnt; i++){
    System.out.printf
      ("\n\tPlease enter an integer then hit return: ");       
       count[i] = scan.nextInt();
    }


    // SOPf the FIRST element of your array (Be informative)

    System.out.printf("\n The first value of the array is %d", count[0]);

    // SOPf the LAST element of your array (Be informative)

    System.out.printf("\n The last value of the array is %d", count[cnt-1]);

    // Loop #2:
    // In a completely separate loop, SOPf all the elements of your array, 
    // five per line

    System.out.printf("\nOriginal Array:\n");
    for(int i = 0; i< count.length; i++){ 
      if(i !=0 && i %5 == 0)
        System.out.printf("\n");
      System.out.printf("%d \t", count[i]);
    }

    // Loop #3:
    // In a completely separate loop, 
    // find & SOPf the value of the minimum element in your array

    int min = 999;
    int minI = 0;
    for(int i = 1; i< count.length; i++){ 
      if (count[i] < min){
        min = count[i];
        minI = i;
      }   
    }
   
    // Loop #4:
    // In a completely separate loop, 
    // find  & SOPf the value of the maximum element in your array

    int max = 0;
    int maxI = 0;
    for(int i = 0; i < count.length; i++){ 
      if (count[i] > max){
        max = count[i];
        maxI = i;
      }   
    }
   
    // swap the contents of the first and last elements of your array

   int swap = count[0];
    count [0] = count[(count.length-1)];
    count[(count.length-1)] = swap;

    if (max == count[count.length-1]){
      maxI = count.length-1;
    }else if(max == count[0]){
      maxI = 0;
    }

    if (min == count[count.length-1]){
      minI = count.length-1;
    }else if(min == count[0]){
      minI = 0;
    }

    // In a completely separate loop, SOPf all the elements of your array, 
    // five per line.  (yes, again)

    System.out.print("\nArray with first and last elements swapped:\n");

    for(int i = 0; i<count.length; i++){ 
      if(i !=0 && i %5 == 0)
        System.out.printf("\n");
      System.out.printf("%d \t", count[i]);
    }

    // Sorting Loop(s):
    // sort the contents of the array your array 
    // after you're done, the values in the array should be in order from
    // smallest to largest.

    /* int otherV = count[0];
    count [0] = min;
    count [minI] = otherV;

    int othrV = count[count.length-1];
    count [count.length-1] = max;
    count [maxI] = othrV; 
    */
        
     for(int i = 0; i<count.length; i++){ 
    // int temp = count[i];
    // if(minI > i){
    //   count[i] = count[minI];
    //   count[minI] = temp;
    // }

    // start the secondary loop at zero, because you want to compare all of the
    // index values to each other, and this loop will run through for each
    // value of i, until all values of the index have been compared
    
       for(int j = 0; j< count.length; j++){ 
         int tmp = count[i];
         if(count [j] >= count [i]){
            count[i] = count[j];
            count[j] = tmp;
         }
       }
     }


    // In a completely separate loop, SOPf all the elements of your array, 
    // five per line.  (yes, again)

    System.out.print("\nSorted Array:\n");

    for(int i = 0; i<count.length; i++){ 
      if(i !=0 && i %5 == 0)
        System.out.printf("\n");
      System.out.printf("%d \t", count[i]);
    }

    System.out.print("\n\n");
  }
}
