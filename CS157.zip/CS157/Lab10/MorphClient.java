import objectdraw.*;
import java.awt.*;

public class MorphClient extends WindowController {

  public static void main(String[] args) {
    new MorphClient().startController(800,800);
  }

 
  private MorphLine_LM morph;
  private Location p1,p3;
  private int cnt = 0;

public void onMousePress(Location p){

    switch(cnt){
      case 0: p1 = new Location(p);

                   break;
      case 1: morph = new MorphLine_LM(p1, p, canvas);

                   break;
      case 2: p3 = new Location(p);

                   break;
      case 3: MorphLine_LM.setGoals(p3,p);
              cnt=-1;
    }
    cnt++;  

  }
}
