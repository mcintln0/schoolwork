import objectdraw.*;
import java.awt.*;

public class LineMorphClient extends WindowController {
  public static void main(String []args){
    new LineMorphClient().startController(800,800);
  }

  public void begin(){
    Text instr = new Text("Click in four different places.",10,10,canvas);    
    instr.setFontSize(24);
    instr.setColor( new Color (200,40,150) );
  }


  private MorphLine morph;
  private int cnt=0;
  private Location p1,p3;
  private Color theColor;
  private RandomIntGenerator rgb = new RandomIntGenerator(0,255);

  public void onMousePress(Location p){

    switch(cnt){
      case 0: p1 = new Location(p);
              theColor = getRandomColor();
              dropLabeledPt( p1, "p1", theColor);
                   break;
      case 1: morph = new MorphLine(p1, p, canvas);
              morph.setColor(theColor);
              dropLabeledPt( p, "p2", theColor);
                   break;
      case 2: p3 = new Location(p);
              dropLabeledPt( p3, "p1(new)", theColor);
                   break;
      case 3: morph.setGoals(p3,p);
              dropLabeledPt( p, "p2(new)", theColor);
              morph.start();
              cnt=-1;
    }
    cnt++;  

  }

  public void dropLabeledPt(Location p, String label, Color c){
    int d=3;  // diameter
    FilledOval dot = new FilledOval(p,d,d,canvas);
    dot.move(-d/2.,-d/2.);
    dot.setColor(c);

    new Text(label, p.getX()+d, p.getY()+d, canvas).setColor(c);
  }

  public Color getRandomColor(){
    return new Color( rgb.nextValue(), rgb.nextValue(),  rgb.nextValue()  );
  }

}
