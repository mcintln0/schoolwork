  // LaToya McIntyre
  // CS 157 -- Lab 1
  // November 2, 2017
  // Reverse Engineer MorphLine

import objectdraw.*;
import java.awt.*;

public class MorphLine_LM{
 
  private Line morph;

  public MorphLine_LM(Location p1, Location p2, DrawingCanvas canvas){
    morph = new Line (p1,p2,canvas);

  }

  public void setGoals( Location p3, Location p4){
    morph.setStart(p3);
    morph.setEnd(p4);
  }

}      
