import objectdraw.*;
import java.awt.*;

public class AjTm extends WindowController{

public static void main(String [] args){
	new AjTm().startController(800,800);
}

public void begin() {
	new Text("USER INSTRUCTIONS", 185, 400, canvas);
	new Text("----------------------------------------------------", 185, 415, canvas);
	new Text("Enter mouse in window to see a labeled box with stand.", 185, 435, canvas);
	new Text("Exit mouse from window to see a 'fancy' labeled box.", 185, 455, canvas);
	new Text("Press mouse to see a filled oval.", 185,475, canvas);
	new Text("Release mouse to see box around oval.", 185, 495, canvas);
	new Text("(Ch2) Move mouse to see a trail of dots (pixels).",185,535, canvas);
	new Text("(Ch2) Drag mouse to see a trail of D's.",185,555, canvas);
	new Text("(Ch4) Click rest 'button' to start over.",185,595, canvas);
	new Text("Click to Reset",450,400, canvas);
	new FramedRect(405,390,160,30, canvas);
}

public void onMouseEnter( Location point){
	new FramedRect(150,10,70,70, canvas);
	new Text("ENTER!",165,40,canvas);
	new Line(185,80,185,120,canvas);
	new Line(180,120,190,120, canvas);
}

public void onMouseExit(Location point){
	new FilledRect(7,147,6,6,canvas);
	new FilledRect(7,257,6,6,canvas);
	new FilledRect(37,147,6,6,canvas);
	new FilledRect(37,257,6,6,canvas);
	new FramedRect(10,150,30,110,canvas);
	new Text ("E",20,170,canvas);
	new Text ("x",20,190,canvas);
	new Text("i",22,210, canvas);
	new Text("t",20,230, canvas);

}
 public void onMousePress (Location point) {
	new FilledOval(0,0,100,100, canvas);
} 
 public void onMouseRelease (Location point) {
	new FramedRect(0,0,100,100, canvas);



}
}
