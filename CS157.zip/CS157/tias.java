import objectdraw.*;
import java.awt.*;
import java.io.*;
import java.util.*;

public class tias extends WindowController{

  public static void main (String[] args) throws FileNotFoundException{

    FilledOval [] circles = new FilledOval[5];

    Scanner sc1 = new Scanner(System.in);

    System.out.printf("\nEnter coordinates filename: ");
    String coordinatesFile = sc1.nextString();

    System.out.printf("\nEnter dimensions filename: ");
    String dimensionsFile = sc1.nextString();

    System.out.printf("\nEnter color filename: ");
    String colorFile = sc1.nextString();
    
    sc1.close();

    new tias().startController(800,800); 
    }

    public void begin(){

    Scanner locF = new Scanner(new File(coordinatesFile));

      for (int i=0;i<circles.length;i++){
        circles[i] = new FilledOval(locF.nextDouble(), locF.nextDouble(), 50,50,canvas);
      }

      // close file
      locF.close();
 
    Scanner dimF = new Scanner(new File(dimensionsFile));
      for (int i=0;i < circles.length;i++){
        circles[i].setSize(dimF.nextDouble(), dimF.nextDouble() );
      }

      // close file
      dimF.close();


    Scanner rgbF = new Scanner(new File(colorFile));
      for (int i=0;i<circles.length;i++){
        circles[i].setColor(new Color(rgbF.nextInt(), rgbF.nextInt(),rgbF.nextInt() ));
      }

      // close file
      rgbF.close();

  }


}
