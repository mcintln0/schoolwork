//LaToya M and Jake C
//Lab 4
//September 21,2017 

import objectdraw.*;
import java.awt.*;

public class PeaceClient extends WindowController{

  public static void main(String[] args) {
    new PeaceClient().startController(800,800);
  }

  private FramedOval peace;

  private Line middle;
  private Line right;
  private Line left;

  private RandomIntGenerator color = new RandomIntGenerator(0,255);
  private RandomIntGenerator radius = new RandomIntGenerator(0,100);
  
  public void onMousePress(Location p){
   int d = radius.nextValue();
    peace = new FramedOval(p, d*2, d*2, canvas);
    peace.move(-peace.getWidth()/2, -peace.getHeight()/2);



    middle = new Line(peace.getX(),peace.getY(),peace.getX(),peace.getY() + peace.getHeight(), canvas);
    middle.move(peace.getWidth()/2,0);
    
    Color peac = new Color(color.nextValue(), color.nextValue(), color.nextValue());

    Location pt45 = new Location( p.getX()-d*Math.cos(Math.PI/4), p.getY() + d*Math.sin(Math.PI/4) );
    Location ptR = new Location( p.getX()+d*Math.cos(Math.PI/4), p.getY() + d*Math.sin(Math.PI/4) );
    right = new Line(p, ptR, canvas);
    left = new Line(p, pt45, canvas);
   
    right.setColor(peac);
    left.setColor(peac);
    middle.setColor(peac);
    peace.setColor(peac);
  }
}
    

