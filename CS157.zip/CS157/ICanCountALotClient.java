    // LaToya McIntyre
    // Septmeber 14,2017
    // HW 2
    // 3.12.1

import objectdraw.*;
import java.awt.*;

    // A program to count how many clicks, presses, and window exits.
    public class ICanCountALotClient extends WindowController {

    public static void main(String[] args) {
    new ICanCountALotClient().startController(800,800);
    }

    private int clicC = 0,
                exitC = 0,
                presC = 0;

    private Text clicD,
                 exitD,
                 presD;  

    // Create the Text to display the current counts
    public void begin() {
      clicD = new Text("The number of clicks is: " + clicC,100,100,canvas );
      exitD = new Text("The number of clicks is: " + exitC,100,150,canvas );
      presD = new Text("The number of clicks is: " + presC,100,200,canvas );
    }

    // Increase click count
    public void onMouseClick(Location point) {
      clicC++;
      clicD.setText("The number of clicks is: " + clicC );
    }

    // Increase exit count
    public void onMouseExit(Location point) {
      exitC++;
      exitD.setText("The number of exits is: " + exitC );
    }

    // Increase press count
    public void onMousePress(Location point) {
      presC++;
      presD.setText("The number of presses is: " + presC );
    }
}
