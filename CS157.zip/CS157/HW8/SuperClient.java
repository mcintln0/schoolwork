  // LaToya McIntyre
  // CS 157 -- HW 8
  // December 8, 2017
  // Test a recursive drawing

import objectdraw.*;
import java.awt.*;

public class SuperClient extends WindowController{
 
  private RandomIntGenerator bobbi = new RandomIntGenerator(0,255);
  private SuperS bob;
  private Location lastP;
  private boolean pressed;

  public static void main (String[] args) {
    new SuperClient().startController(800,800); 
  }

  public void begin(){
    new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
    bob = new SuperS(canvas.getWidth()/2,canvas.getHeight()/2,400,400, canvas);
    bob.move(- bob.getWidth()/2,-bob.getHeight()/2);
  }

  public void onMousePress(Location p){
    lastP = p;
    pressed = bob.contains(p);
  }

  public void onMouseDrag(Location p){
    if (pressed){
      bob.move( p.getX()-lastP.getX() , p.getY()-lastP.getY() );
      lastP = p;
    }
  }  

}
