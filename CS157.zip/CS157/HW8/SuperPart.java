  // LaToya McIntyre
  // CS 157 -- Lab12
  // December 8, 2017
  // Create interface

import objectdraw.*;
import java.awt.*;

// interface must have all the methods of the base class
public interface SuperPart {

  public void move(double dx, double dy);
  public void setColor(Color c);
  public void run();
  public boolean contains(Location p);
  public double getWidth();
  public double getHeight();
  public Location getLocation();

}
