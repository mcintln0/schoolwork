  // LaToya McIntyre
  // CS 157 -- Lab12
  // December 8, 2017
  // Create an empty class with all the methods of the recursive class

import objectdraw.*;
import java.awt.*;

public class BaseClass implements SuperPart{

  public BaseClass(){ }

  public void move(double dx, double dy){ }

  public void setColor(Color c){ }

  public boolean contains(Location p){ 
    return false;
  }

  public double getWidth(){ 
    return 0;
  }
  
  public double getHeight(){ 
    return 0;
  }

  public void run(){ }

  public Location getLocation(){
    return new Location(0,0);
  }

}
