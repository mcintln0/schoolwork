import objectdraw.*;
import java.awt.*;

public class PointClicke extends WindowController{

  public static void main(String[] args) {
    new PointClicke().startController(800,800);
  }
private Location clickPoint;
	
	public void begin(){
	clickPoint = new Location (50,50);
}

  public void onMouseClick(Location point){
    point = clickPoint;
	new Text ( "Hi", clickPoint, canvas);
  }

}
