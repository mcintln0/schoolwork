  // LaToya McIntyre
  // CS 157 -- Lab13
  // November 30, 2017
  // Create a program to simulate artificial life



import objectdraw.*;
import java.awt.*;

public class ALife extends WindowController{

  public static void main (String[] args) {
   new ALife().startController(800,800); 
  }

  private FilledRect [][] newGen;
  private FilledRect [][] oldGen;
  private FilledRect [][] temp;
  private final double CELLSIZE = 20;

  public void begin() {
  // Assigned here b/c the ordering of the prgm can cause a NullPointerException
    newGen = new FilledRect 
                   [(int)((canvas.getWidth()-2*CELLSIZE)/CELLSIZE)]
                   [(int)((canvas.getHeight() -2*CELLSIZE)/CELLSIZE)];
    oldGen = new FilledRect 
                   [newGen.length][newGen[0].length];

    double xV = CELLSIZE;
    for (int c = 0 ; c < newGen.length; c++){
      double yV = CELLSIZE;  

      for(int r = 0 ; r < newGen[c].length; r++){
        newGen[c][r] = new FilledRect(xV,yV,CELLSIZE,CELLSIZE,canvas);
        newGen[c][r].setColor(Color.WHITE);
        newGen[c][r].hide();
        oldGen[c][r] = new FilledRect(xV,yV,CELLSIZE,CELLSIZE,canvas);
        oldGen[c][r].setColor(Color.WHITE);
        new FramedRect(newGen[c][r].getLocation(),CELLSIZE,CELLSIZE,canvas);
        yV = yV + CELLSIZE;
      }

    xV = xV + CELLSIZE;
    }
  }

  public void onMousePress(Location p){

    for (int c = 0 ; c < oldGen.length; c++)
      for(int r = 0 ; r < oldGen[c].length; r++)
        if( oldGen[c][r].contains(p) )
          oldGen[c][r].setColor(Color.BLUE);  
  }

  public void onMouseExit(Location p){

    for (int c = 0 ; c < oldGen.length; c++)
      for(int r = 0 ; r < oldGen[c].length; r++){

        if( c > 1 && r > 1 && oldGen.length - c > 1 && oldGen[c].length -r >1){
        
  // Coming Alive

  // Check the amount of neighbors an alive cell has
        if(oldGen[c][r].getColor() != Color.BLUE){

  // if a cell is touching 3 blue cells then the newGen is blue
          int nbors = 0;
          for (int nC = -1 ; nC <= 1; nC++){
            for(int nR = -1 ; nR <=1; nR++){
              if(oldGen[c+nC][r+nR].getColor() == Color.BLUE)
                nbors++;
            }
          }

          if(nbors >= 3){
            newGen[c][r].setColor(Color.BLUE);
          }else{
            newGen[c][r].setColor(oldGen[c][r].getColor());
          }
         
  //Dying Cells    

        }else if(oldGen[c][r].getColor() == Color.BLUE){

  // Dies if a cell has 3+ nbors or if cell has less than two nbors
          int nbors = 0;
          for (int nC = -1 ; nC <= 1; nC++){
            for(int nR = -1 ; nR <=1; nR++){
              if(oldGen[c+nC][r+nR].getColor() == Color.BLUE)
                nbors++;
            }
          }

          if(nbors < 2 || nbors > 3){
            newGen[c][r].setColor(Color.WHITE);
          }else{
            newGen[c][r].setColor(oldGen[c][r].getColor());
          }
  
        for (int g = 0 ; g < oldGen.length; g++)
          for(int h = 0 ; h < oldGen[h].length; h++){
            newGen[g][h].show();
            oldGen[g][h].hide();
          }
        }
      }
    }

  //switch the array references
    temp = oldGen;
    oldGen = newGen;
    newGen = temp;
   
    for (int g = 0 ; g < oldGen.length; g++)
      for(int h = 0 ; h < oldGen[h].length; h++){
        newGen[g][h].setColor(Color.WHITE);
        }
  }


}
