  // LaToya McIntyre
  // October 16, 2017
  // CS 157
  // HW 5 - 2b
  // Creates a column of five fish

import objectdraw.*;
import java.awt.*;

public class FishColumnsClient extends WindowController {

  public static void main(String[] args) {
    new FishColumnsClient().startController(800,800);
  }
  
  private RandomDoubleGenerator loc = new RandomDoubleGenerator (0,500);

  public void begin(){
    double fishX = loc.nextValue();
    double fishY = loc.nextValue();    
    Location fishXY = new Location (fishX,fishY); 
    int cnt = 0;
    while(cnt<5){
      Fish_BJ johnny = new Fish_BJ(fishXY,50,50,canvas);
      fishXY.translate(0,johnny.getHeight()); 
      cnt++;
    }
  }
}  
