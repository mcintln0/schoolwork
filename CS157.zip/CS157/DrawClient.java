//LaToya M and Jake C
//Lab 4
//September 21,2017 

import objectdraw.*;
import java.awt.*;

public class DrawClient extends WindowController{

  public static void main(String[] args) {
    new DrawClient().startController(800,800);
  }

  private FramedRect rec;
  private FramedOval ova;

  private RandomIntGenerator loc = new RandomIntGenerator(0,400);
  private int red,total;

  private double third;
  
  private Text text1,text2,text3;

  public void onMouseMove(Location p){
  
    FilledOval spot = new FilledOval(loc.nextValue(),loc.nextValue(),4,4,canvas);  
    boolean cont = ova.contains(spot.getLocation());

    if (cont){
      spot.setColor(Color.RED);
      red++;
    }else {
      spot.setColor(Color.BLUE);
    }

    total++;

    text1.setText("Red: " + red);
    text2.setText("Total: " + total);
    
    third = 4.0*red / total;
    text3.setText("Four * Circle / Square =" + third);
   
}

  public void begin(){
 
    rec =  new FramedRect(0,0,400,400,canvas);
    rec.setColor(Color.BLUE);
    ova =  new FramedOval(0,0,400,400,canvas);
    ova.setColor(Color.RED);
    new Text("Move mouse on canvas to generate spots, exit to clear canvas",
              0, 450, canvas);

    text1 = new Text("Red: ",0,475,canvas);
    text2 = new Text("Total: ",0,520, canvas);
    text3 = new Text("Four * Circle / Square =",canvas.getWidth()/6,565,canvas);


    text1.setFontSize(30);
    text2.setFontSize(30);
    text3.setFontSize(35);

    text1.setColor(Color.RED);
    text3.setColor(Color.GREEN);

    red = 0;
    total = 0;
    third = 0;
 
  }

  public void onMouseExit(Location p){
    canvas.clear();    
    begin();
   }
}


