import objectdraw.*;
import java.awt.*;

public class DrawRect extends WindowController{

  public static void main(String[] args) {
    new DrawRect().startController(800,800);
  }

//shouled establish erase as a rectangle
private FramedRect erase;

// connecting the nickname with an offscreen object
public void begin (){
erase = new FramedRect (900,900,100,100,canvas);
}
 
// The filled square will show up at the press point
 public void onMousePress(Location point){
    erase.moveTo(point);
	erase.show();
  }
// Show the rectangle being dragged
public void onMouseDrag(Location point){
erase.moveTo(point);
}

// When the mouse is released the filled square disappers
  public void onMouseRelease(Location point){
	 erase.hide();
// The Filled Rectangle is left behind
	new FilledRect(point,100,100,canvas);

}
}
