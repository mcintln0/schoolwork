import objectdraw.*;
import java.awt.*;

// A program that produces an animation of the moon rising.
// The animation is driven by clicking the mouse button.
// The faster the mouse is clicked, the faster the moon will rise.
public class RisingMoon extends WindowController{
public static void main(String[] args) {
    new RisingMoon().startController(800,800);
  }
    private FilledOval moond,
                       moon;     
    private Text instructions;  // Display of instructions

    // Place the moon and some brief instructions on the screen
    public void begin() {
        new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas);
        moon = new FilledOval( 400, 400, canvas.getWidth()/2, canvas.getHeight()/2, canvas);
        moond = new FilledOval( 300, 300, canvas.getWidth()/2, canvas.getHeight()/2, canvas);
        moon.setcolor(new Color(172,213,227));
        moon.move(-moon.getWidth()/2,-moon.getHeight()/2);
        instructions = new Text( "Please click the mouse repeatedly", 20, 20, canvas);
    }

    // Move the moon up a bit each time the mouse is clicked
    public void onMouseClick(Location point) {
        moon.move(0, -5);
        moond.move(0,-5);
        instructions.hide();
    }
    
    // Move the moon back to its starting position and redisplay
    // the instructions
    public void onMouseExit(Location point){
        moon.moveTo(canvas.getWidth()/2-moon.getWidth(),
                    canvas.getHeight()/2-moon.getHeight()/2);
        instructions.show();
    }
}
