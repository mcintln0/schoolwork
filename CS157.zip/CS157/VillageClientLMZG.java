// LaToya McIntyre and Zosimo Garcia
//CSI 157 Lab 2
/*  Pressing will create a red house, release will create a slightly smaller blue house. Both should have black doors which are sized to be half as tall as the house and one quarter as wide. They should be placed so that doors of the red houses are located slightly to the left of the center of the house while the doors for the blue houses are located slightly to the right of center. It's high noon in the village but time is passing... 
*/

import objectdraw.*;
import java.awt.*;

  public class VillageClientLMZG extends WindowController{

  private FilledOval sun;


  public static void main(String[] args) {
    new VillageClientLMZG().startController(800,800);
  }
 
  public void begin(){
    sun = new FilledOval(0,10,200,200, canvas);
    sun.setColor(Color.YELLOW);
    
  }
  
  public void onMouseEnter(Location point){
    sun.move(10,0);
  }

  public void onMouseExit(Location point){
    sun.move(10,0);
  }
  
  public void onMousePress(Location p){
    FilledRect redH = new FilledRect(p, 60,30,canvas);
    redH.setColor(Color.RED);
    FilledRect door = new FilledRect(
                          p.getX() + redH.getWidth()/4, p.getY() + redH.getHeight()/2,
                          redH.getWidth()/4, redH.getHeight()/2,canvas);
    new FramedRect(p,60,30,canvas);

  }

  public void onMouseRelease(Location p){
    FilledRect blueH = new FilledRect(p, 30,30,canvas);
    blueH.setColor(Color.BLUE);
    FilledRect door = new FilledRect(
                          p.getX() + blueH.getWidth()/2, p.getY() + blueH.getHeight()/2,
                          blueH.getWidth()/4, blueH.getHeight()/2,canvas);
    new FramedRect(p,30,30,canvas);

  }
}
