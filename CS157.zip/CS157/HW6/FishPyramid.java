 // LaToya McIntyre
  // CS 157 -- HW 6
  // October 27, 2017
  // Create a pyramid of fish

import objectdraw.*;
import java.awt.*;

public class FishPyramid extends WindowController{

  public static void main(String [] args){
	new FishPyramid().startController(800,800);
  }

  public void onMousePress(Location p){
    int row = 0;
    while (row < 8){
      int pyr = 0;

      double start = p.getX() - (30*row);
      while(pyr<=row){
        Fish_T fishy = new Fish_T(start,p.getY(),50,50,canvas);
        start = start + 60;
        pyr++;
    
        switch(row){
          case 0:
            fishy.setColor(Color.RED);
          break;
          case 1:
            fishy.setColor(Color.YELLOW);
          break;
          case 2:
            fishy.setColor(Color.GREEN);
          break;
          case 3:
            fishy.setColor(Color.BLUE);
          break;
          case 4:
            fishy.setColor(Color.BLUE);
          break;
          case 5:
           fishy.setColor(Color.GREEN);
          break;
          case 6:
            fishy.setColor(Color.YELLOW);
          break;
          case 7:
            fishy.setColor(Color.RED);
          break;
      }
    }
      p.translate(0,60);
      row++;
   }
     
  }

}
