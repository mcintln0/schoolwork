  // LaToya McIntyre
  // CS 157 -- HW 6
  // October 27, 2017
  // Create a sky of stars

import java.util.Scanner;
import objectdraw.*;
import java.awt.*;

public class StarryNight extends WindowController{

  public static void main(String [] args){
	new StarryNight().startController(800,800);
  }

  private FilledRect star;
  private RandomDoubleGenerator dim = new RandomDoubleGenerator(2,5);
  private RandomIntGenerator rgb = new RandomIntGenerator(0,250);
  private RandomDoubleGenerator loc = new RandomDoubleGenerator(0,800);

  public void begin(){
    double xV = loc.nextValue(); 
    double yV = loc.nextValue();
    int cnt = 0;
  
    new FilledRect(0,0,800,800,canvas);

    while (cnt < 101){
      star = new FilledRect(xV,yV,dim.nextValue(),dim.nextValue(),canvas);
      star.setColor(new Color(rgb.nextValue(),rgb.nextValue(),
                    rgb.nextValue(),rgb.nextValue()));

      xV = loc.nextValue(); 
      yV = loc.nextValue();
      cnt++;
    }

     new RisingMoon(0,canvas.getHeight()/8,100,100,canvas,Color.BLACK);

  }

}       

