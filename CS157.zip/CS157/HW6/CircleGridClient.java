  // LaToya McIntyre
  // CS 157 -- HW 6
  // October 27, 2017
  // Create a grid of circles

import java.util.Scanner;
import objectdraw.*;
import java.awt.*;

public class CircleGridClient extends WindowController{

  // declares as instance variable, needs static to use in "static void main"
    static Scanner grid;
    private static int rows,
                       columns;
    private int cnt =0;

  public static void main (String[] args) {
    
    // attach scanner to terminal input
   grid = new Scanner(System.in);

   //intially starts with asking for user input of rows and columns
    System.out.printf("\n\t Enter intergers less than 20 ");

    System.out.printf("\n\t Number of rows: ");
     rows = grid.nextInt();

    System.out.printf("\n\t Number of columns: ");
     columns = grid.nextInt();

    new CircleGridClient().startController(800,800); 
  }

  public void onMousePress(Location p){
    if(cnt % 2 == 0){
      new CircleGrid(rows, columns, p, canvas);
    }else{
      new CircleGrid(rows, columns, p, canvas, Color.BLUE);
    }
    cnt++;
  }
}
