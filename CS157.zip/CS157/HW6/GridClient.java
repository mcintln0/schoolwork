  // LaToya McIntyre
  // CS 157 -- HW 6
  // October 27, 2017
  // Create a 5 X 5 grid of fish

import objectdraw.*;
import java.awt.*;

public class GridClient extends WindowController{

  public static void main(String [] args){
	new GridClient().startController(800,800);
  }

  public void onMousePress(Location p){
    int row = 0;
    while (row < 5){
      int col = 0;
      double start = p.getX();
      while(col<5){
        Fish_T fishy = new Fish_T(start,p.getY(),50,50,canvas);
        start = start + 50;
        col++;
 
        if((row+col) % 2 ==0) {
          fishy.setColor(Color.RED);
        }
      }
      p.translate(0,50);
      row++;
   }
     
  }

}
