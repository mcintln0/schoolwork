  // Test the fish-lm

import objectdraw.*;
import java.awt.*;

public class tiasFishClient extends WindowController{

  public static void main(String [] args){
	new tiasFishClient().startController(800,800);
  }

 private RandomDoubleGenerator dim = new RandomDoubleGenerator (100,400);

  public void onMousePress(Location p){
    new Fish_LM(p,dim.nextValue(),dim.nextValue(),canvas);
  }

}
