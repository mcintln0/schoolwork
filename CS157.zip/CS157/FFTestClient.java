// 27 Sep 2017
// lkd - test client for 6.8.3 methods added to FunnyFace
import objectdraw.*;
import java.awt.*;

public class FFTestClient extends WindowController {

  public static void main(String[] args) {
    new FFTestClient().startController(800,400);
  }

  private RandomIntGenerator rand = new RandomIntGenerator(-35,35);
  private Text theReport;
  private FramedRect removeB,getxB,eyesB;
  private FunnyFace  face;
  private int W=220;
  private int rgbEyes=0;

  public FramedRect makeButton(double x, double y, String label){   
    FramedRect frame = new FramedRect( x,y, W, 50, canvas );
    Text t=new Text(label,frame.getLocation(),canvas);
    t.setFontSize(20);
    t.move(frame.getWidth()/2, frame.getHeight()/2);
    t.move(-t.getWidth()/2, -t.getHeight()/2);
    return frame;
  }

  public void begin(){   

    int x=20;

    removeB = makeButton( x,          200, "Get gone!");
    getxB   = makeButton( x+   W+10,  200, "How far from left?");
    eyesB   = makeButton( x+2*(W+10), 200, "Blink!");

    // instructions to user
    new Text("Click anywhere not a button to move!",10,10,canvas).setFontSize(25);
    new Text("Exit to start over.",10,50,canvas).setFontSize(20);

    face = new FunnyFace( getxB.getX()+W/2-30, canvas.getHeight()/4, canvas);

    theReport = new Text("", getxB.getX()+W/2, eyesB.getY()+2*eyesB.getHeight(), canvas);
    theReport.setFontSize(25);
    theReport.setColor(Color.RED);
  }

  // reset
  public void onMouseExit( Location p ) {
    canvas.clear();
    begin();
  }

  // check buttons; other press locations randomly moves face around
  public void onMousePress( Location p ) {

    if( getxB.contains(p) ){
      theReport.setText("face located at x = " + face.getX());

    }else if(removeB.contains(p) ){
      theReport.setText("Ok, face is GONE.  Exit to Reset");
      face.removeFromCanvas();

    }else if(eyesB.contains(p) ){
      // eye colors cycle thru red,green,blue
      if (rgbEyes == 0)
        face.setEyeColor(Color.RED);
      else if (rgbEyes == 1)
        face.setEyeColor(Color.GREEN);
      else 
        face.setEyeColor(Color.BLUE);
      rgbEyes = (rgbEyes+1) % 3; 

    }else
      face.move( rand.nextValue(), rand.nextValue() );

  }

}

