import java.util.Scanner;
import objectdraw.*;
import java.awt.*;

public class ScannerClient extends WindowController{

  // declares as instance variable, needs static to use in "static void main"
    static Scanner rect;
     static double userD;

  public static void main (String[] args) {
    
    // attach scanner to terminal input
   rect = new Scanner(System.in);

   //intially starts with asking for user input and will be used one time
/*    System.out.printf("\n\tPlease enter an integer & hit return: ");
     userD = rect.nextDouble(); */
    new ScannerClient().startController(800,800); 
  }

  public void begin(){

  new Text("Look at terminal after every click",10,10,canvas);

}

  public void onMouseClick(Location p){

//This allows user input after every click, but before rectangle
  System.out.printf("\n\tPlease enter an integer & hit return: ");
     userD = rect.nextDouble();
      new FilledRect(p,userD,userD,canvas);

  }
}

