  // LaToya McIntyre
  // October 16, 2017
  // CS 157
  // HW 5 - 2a
  // Creates a row of five fish

import objectdraw.*;
import java.awt.*;

public class FishRowClient extends WindowController {

  public static void main(String[] args) {
    new FishRowClient().startController(800,800);
  }
  
  private RandomDoubleGenerator loc = new RandomDoubleGenerator (0,800);

  public void begin(){
    double fishX = loc.nextValue();
    double fishY = loc.nextValue();
    int cnt = 0;
    while(cnt<5){
      new Fish_MT(fishX,fishY,50,50,canvas);
      fishX= fishX + 50;
      cnt++;
    }
  }
}  
