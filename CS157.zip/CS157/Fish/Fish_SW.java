import objectdraw.*;
import java.awt.*;

public class Fish_SW{

  private static final Color BODY_COLOR = new Color(51,51,102);
  private static final Color BELLY_COLOR = new Color(153,153,255);

  private FilledOval body, eye;
  private FilledRect tail;
  private FilledArc tailFins, belly;
  private Line nose1, nose2;

  public Fish_SW(Location p, double w, double h, DrawingCanvas canvas){

    Location swordPoint = new Location(p.getX()-w/3,p.getY()+h/2-h/10);

    nose1 = new Line(swordPoint.getX(),swordPoint.getY()
                    ,p.getX()+w/6,p.getY()+h/2-h/10, canvas);
   nose2 = new Line(swordPoint.getX(),swordPoint.getY()
                   ,p.getX()+w/6,p.getY()+h/2, canvas);

    nose1.setColor(BODY_COLOR);
    nose2.setColor(BODY_COLOR);

    body = new FilledOval(p.getX()+w/6-w/10,p.getY()+h/6,w*2/3,h*2/3,canvas);
    body.setColor(BODY_COLOR);  

    belly = new FilledArc(p.getX()+w/6-w/10,p.getY()+h/6,
                          w*2/3,h*2/3,0,-180,canvas);  
    belly.setColor(BELLY_COLOR);

    tail = new FilledRect(p.getX()+2*w/3-w/10,p.getY()+2*h/5,w/3,h/5,canvas);
    tailFins = new FilledArc(p.getX()+7*w/9,p.getY(),w/9,h,90,-180,canvas);
    tail.setColor(BODY_COLOR);
    tailFins.setColor(BODY_COLOR);

    eye = new FilledOval(p.getX()+w/5,p.getY()+h/2-h/5,w/16,w/16,canvas);
    eye.setColor(Color.WHITE);

  }    

  public Fish_SW(double x,double y, double w, double h, DrawingCanvas canvas){
    this(new Location(x,y), w,h, canvas);
  }

  public double getWidth(){

    // widest width is tip of nose to tip of tail
    //     measure distance between x coord's of those two places
    
    // farthest left x coordinate is point of nose
    double xLeft = nose1.getStart().getX();
    // farthest right x coordinate is tail x plus tail width
    double xRight = tail.getX() + tail.getWidth();

    return xRight - xLeft;
  }

  public double getHeight(){
    // tallest part of fish is the vertical tailfins
    return tailFins.getHeight();
  }

  public Location getLocation(){

    // farthest left X coordinate is point of nose
    double x = nose1.getStart().getX();

    // highest up y coordinate is Y of vertical tailfins
    double y = tailFins.getY();

    // wrap (x,y) values up into a location which is "location" of whole fish
    Location p = new Location (x,y);
    return p;

  }

  public void move(double dx, double dy){
    nose1.move(dx,dy);
    nose2.move(dx,dy);
    body.move(dx,dy);
    belly.move(dx,dy);
    tail.move(dx,dy);
    tailFins.move(dx,dy);
    eye.move(dx,dy);

  }

  public void moveTo(double x, double y){
    move(x-nose1.getEnd().getX(),y-tailFins.getY());
  }

  public void moveTo(Location p){
    this.moveTo(p.getX(),p.getY());

  }

  public void setColor(Color newColor){
    body.setColor(newColor);
    tail.setColor(newColor);
    tailFins.setColor(newColor);
    nose1.setColor(newColor);
    nose2.setColor(newColor);
    belly.setColor(new Color(newColor.getBlue(),newColor.getGreen(),
                   newColor.getRed()));
  }

  public Color getColor(){
    return body.getColor();
  }

  public boolean contains(Location p){
    return body.contains(p) || tail.contains(p);
  }

}
