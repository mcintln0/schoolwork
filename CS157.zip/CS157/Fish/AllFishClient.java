// LaToya M. Mads Christensen
// Lab 6
// October 5, 2017
// Use the fish classes made last week to create a lake
// full of moving color changing fish

import objectdraw.*;
import java.awt.*;

public class AllFishClient extends WindowController{

  public static void main(String[] args) {
    new AllFishClient().startController(1000,1000);
  }

  private RandomIntGenerator rgb = new RandomIntGenerator (0,255);
  private FilledRoundedRect moveBox,
                            colorBox;
  
  private Fish_AD AD;
  private Fish_BJ BJ;
  private Fish_CS CS;
  private Fish_HM HM;
  private Fish_JS JS;
  private Fish_JW JW;
  private Fish_MR MR;
  private Fish_MT MT;
  private Fish_ZJ ZJ;
  private Fish_SW SW;
  private int fontSize = 20;

  private Location fishLS = new Location (250,150),
                   fishRS = new Location (600,250);
              

  public void begin(){
    new FilledRect(0,0,canvas.getWidth(),canvas.getHeight(),canvas)
    .setColor(new Color(223,241,247));
    moveBox = new FilledRoundedRect (10, 10, 75, 40, 10, 10, canvas);
    new FramedRoundedRect (10, 10, 75, 40, 10, 10, canvas);

    
    colorBox = new FilledRoundedRect (100, 10, 75, 40, 10, 10, canvas);
    new FramedRoundedRect (100, 10, 75, 40, 10, 10, canvas);

    colorBox.setColor(Color.YELLOW);
    moveBox.setColor(Color.YELLOW);

  // Fish on the Left
    AD = new Fish_AD(fishLS.getX(), fishLS.getY(), 75, 75, canvas);
    BJ = new Fish_BJ(fishLS, 75, 75, canvas);
    BJ.move(0,150);
    Location CSstart= new Location (250,450);
    CS = new Fish_CS(CSstart, 75, 75, canvas);
    HM = new Fish_HM(fishLS, 75, 75, canvas);
    HM.move(0,450);
    JW = new Fish_JW(fishLS, 75, 75, canvas);
    JW.move(0,600);

  // Fish on the Right
    JS = new Fish_JS(fishRS.getX(), fishRS.getY(), 75, 75, canvas);
    MR = new Fish_MR(fishRS, 75, 75, canvas);
    MR.move(0,150);
    MT = new Fish_MT(fishRS.getX(), fishRS.getY(), 75, 75, canvas);
    MT.move(0,300);
    ZJ = new Fish_ZJ(fishRS, 75, 75, canvas);
    ZJ.move(0,450);
    SW = new Fish_SW(fishRS, 175, 75, canvas);
    SW.move(0,600);

  // Names    
    new Text("Amanda & Drew", 50, 150, canvas).setFontSize(fontSize);
    new Text("Beau & Jeremy", 50, 300, canvas).setFontSize(fontSize);
    new Text("Calid Shorter", 50, 450, canvas).setFontSize(fontSize);
    new Text("Hailey & Matt", 50, 600, canvas).setFontSize(fontSize);
    new Text("Jake & Will", 50, 750, canvas).setFontSize(fontSize);
    new Text("Jennifer & Shomari", 400, 250, canvas).setFontSize(fontSize);
    new Text("Mads & Robin", 400, 400, canvas).setFontSize(fontSize);
    new Text("Mikayla & Toya", 400, 550, canvas).setFontSize(fontSize);
    new Text("Zosimo & Joe", 400, 700, canvas).setFontSize(fontSize);
    new Text("Swordfish", 400, 850, canvas).setFontSize(fontSize);

  // Control Text  
    new Text("(Exit to reset.)",moveBox.getX()+5,
    moveBox.getY()+moveBox.getHeight()+5,canvas).setFontSize(fontSize);
    Text instr1 = new Text("Move", moveBox.getX(), moveBox.getY(), canvas);//1
    instr1.setFontSize(fontSize);
    instr1.move(moveBox.getWidth()/2,moveBox.getHeight()/2);//2
    instr1.move(-instr1.getWidth()/2,-instr1.getHeight()/2);//3


    Text instr2 = new Text("Color", colorBox.getX(), colorBox.getY(), canvas);
    instr2.setFontSize(fontSize);
    instr2.move(colorBox.getWidth()/2,colorBox.getHeight()/2);
    instr2.move(-instr2.getWidth()/2,-instr2.getHeight()/2);
  }

  public void onMousePress( Location p ){
      if ( moveBox.contains(p) ){
        AD.move( 5,0 );
        BJ.move( 5,0 );
        JS.move( 5,0 );
        MT.move( 5,0 );
        SW.move( -5,0 );
        HM.move( 5,0 );
        MR.move( 5,0 );
        ZJ.move( 5,0 );
        JW.move( 5,0 );
      }
      if (colorBox.contains(p) ){
        Color fishy = (new Color(rgb.nextValue(),rgb.nextValue(),
                       rgb.nextValue()));
        AD.setColor(fishy);
        BJ.setColor(fishy);
        MT.setColor(fishy);
        SW.setColor(fishy);
        HM.setColor(fishy);
      }
      if (SW.contains(p)){    
        FramedRect shrinkSW = new FramedRect( SW.getLocation()   
                                            , SW.getWidth()
                                            , SW.getHeight()
                                            , canvas);
        shrinkSW.setColor(Color.RED);
      }
      if (MT.contains(p)){    
        FramedRect shrinkMT = new FramedRect( MT.getX(), MT.getY()-20   
                                            , MT.getWidth()
                                            , MT.getHeight()+20
                                            , canvas);
        shrinkMT.setColor(Color.RED);
      }
  }  
  
  public void onMouseExit(Location p ){
    canvas.clear();
    begin();
  }          
}
