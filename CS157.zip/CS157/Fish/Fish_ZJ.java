// This is the fish of Joe Threlkeld and Zosimo Garcia 





import objectdraw.*;
import java.awt.*;
  
public class Fish_ZJ {


                           
  private Fish_ZJ fish;                       
  private FilledOval body, eye;
  private Line s1,s2,s3;
  private RandomIntGenerator colorGen = new RandomIntGenerator (0,255);

  public Fish_ZJ (Location p, double w, double h, DrawingCanvas dc){
  
    double x= p.getX();
    double y= p.getY();
 
    int r= colorGen.nextValue();
    int g= colorGen.nextValue();
    int b= colorGen.nextValue();

    Location tTip= new Location (x + w/3 , y + h/2);
    Location leftT= new Location (x, y+h);
    Location rightT= new Location (x, y); 

    body= new FilledOval(x+w/3,y ,120,90 ,dc);

    s1= new Line(leftT, tTip, dc);
    s2= new Line(rightT, tTip, dc);
    s3= new Line(leftT, rightT, dc);

    eye= new FilledOval(p.getX()+(w*(7/8))+150,p.getY()+ h/4 ,15,15,dc);

    body.setColor(new Color(r,g,b ));

  } 


  public void move(double dx, double dy){
    body.move(dx,dy);
    s1.move(dx, dy);
    s2.move(dx, dy);
    s3.move(dx, dy);
    eye.move(dx, dy);

  }
  public void moveTo(Location p){
    move(p.getX(), p.getY());
  }
  
  public void moveTo(double x, double y){
    body.move( x - body.getX(), y - body.getY() );
 

  }
}
