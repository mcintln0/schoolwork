  // Mikayla C. and LaToya M
  // Lab 5
  // September 28,2017
  // CS 157

import objectdraw.*;
import java.awt.*;
  
  public class Fish_MT implements Drawable157{
    private Line tail, uFin, lFin;
    private FilledOval head,eye;
    private Location tailL;

  public Fish_MT(double x, double y, double w, double h, DrawingCanvas dc){
    head = new FilledOval(x, y, 2*w/3, h, dc);
    head.move(w/3, 0);
    tail = new Line(x, y, x, y + h, dc);
    uFin = new Line(x, y, x + 1*w/3, y + h/2, dc);
    lFin = new Line(x, y + h, x + w/3, y + h/2, dc);
    tailL = tail.getStart();
    eye = new FilledOval(head.getX(),head.getY(),
                         head.getWidth()/8,head.getHeight()/8,dc);
    eye.move(head.getWidth() - 2*eye.getWidth(),head.getHeight()/3);
    eye.setColor(new Color(150,144,144));
  }

  public Fish_MT(Location p, double w, double h, DrawingCanvas dc){
    this( p.getX(), p.getY(), w, h, dc );
  }

  public void move(double dx, double dy){
    head.move(dx, dy);
    tail.move(dx, dy);
    uFin.move(dx, dy);
    lFin.move(dx, dy);
    eye.move(dx, dy);
  }

  public void moveTo(double x, double y){
    move(x-tailL.getX(),y-tailL.getY());
  }
  
  public void setColor( Color c){
    head.setColor(c);
  }

  public boolean contains(Location p){
    return head.contains(p);   
  }

  // Accessor Methods for the fish
  public double getHeight(){
    return  head.getHeight();
  } 

  public double getWidth(){
    return  3*head.getWidth()/2;
  } 

  public double getX(){
    return  tailL.getX();
  }

  public double getY(){
    return  tailL.getY();
  }

  public Color getColor(){
    return  head.getColor();
  }

  public Location getLocation(){
    return  tail.getStart();
  }

}
