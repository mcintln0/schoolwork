// Beau Allen & Jeremy Baxter
// Lab #5
// September 28, 2017

import objectdraw.*;
import java.awt.*;

public class Fish_BJ {

  private Line finLeft, finRight, tailTop, tailBottom, tailEnd;
  private FilledOval body, eye;
  private FramedOval bodyFrame;
  private double width, height;
  private Location corner;

  public Fish_BJ( Location p, double w, double h, DrawingCanvas dc){
    width = w;
    height = h;
    corner = p;

    Location finTip = new Location( p.getX() + 5*w/8, p.getY() + h/8);
    Location tailTip = new Location( p.getX() + 3*w/8, p.getY() + 5*h/8);
    Location tailPointT = new Location ( p.getX(), p.getY() + 3*h/8);
    Location tailPointB = new Location ( p.getX(), p.getY() + h);
    Location finPointL = new Location ( p.getX() + w/2, p.getY() + h/2);
    Location finPointR = new Location (p.getX() + 3*w/4, p.getY() + h/2);

    finLeft = new Line(finPointL, finTip, dc);
    finRight = new Line(finPointR, finTip, dc);
    
    tailTop = new Line(tailPointT, tailTip, dc);
    tailBottom = new Line(tailPointB, tailTip, dc);
    tailEnd = new Line(tailPointT, tailPointB, dc);

    body = new FilledOval(p.getX() + w/4, p.getY() + 3*h/8, 3*w/4, h/2, dc);
    body.setColor(Color.YELLOW);
    
    bodyFrame = new FramedOval(p.getX()+w/4, p.getY() + 3*h/8, 3*w/4, h/2,dc);

    eye = new FilledOval( p.getX() + 3*w/4, p.getY() + h/2, w/16, w/16, dc);   
  }

  public void move(double x, double y){
    body.move(x,y);
    bodyFrame.move(x,y);
    tailTop.move(x,y);
    tailBottom.move(x,y);
    tailEnd.move(x,y);
    finLeft.move(x,y);
    finRight.move(x,y);
    eye.move(x,y);
    corner= new Location(corner.getX()+x, corner.getY()+y);
  }

  public void moveTo(Location p){
    move( p.getX()-body.getX() + width/4, p.getY()-body.getY()+3*height/8 );
  }

  public void setColor(Color c){
    body.setColor(c);
  }

  public double getX(){
    return corner.getX();
  }
  
  public double getY(){
    return corner.getY();
  }
  
  public Location getLocation(){
    return corner;
  }

  public Color getColor(){
    return body.getColor();
  }

  public boolean contains(Location p){
    return body.contains(p) || tailTop.contains(p) || tailBottom.contains(p) ||
           tailEnd.contains(p) || finLeft.contains(p) || finRight.contains(p);
  }

  public double getWidth(){
    return width;
  }

  public double getHeight(){
    return height;
  }
}
