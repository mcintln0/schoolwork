  // LaToya McIntyre
  // CS 157 -- HW 6
  // October 27, 2017
  // Creating a fish

import objectdraw.*;
import java.awt.*;

public class Fish_LM{
  private FilledArc head,
                    fFin,
                    sFin,
                    tFin,
                    fsFin,
                    tail;
  private FilledOval eye;

  public Fish_LM(double x, double y, double width, double height,
                 DrawingCanvas canvas){
    new FramedRect(x,y,width,height,canvas);

    // Fish body
    head = new FilledArc(x,y,  3*width/8,   4*height/15,90,180,canvas);
    head.setColor(new Color(36,0,112));
    head.move(0,5.5*height/15);

    fFin = new FilledArc(x,y,  4*width/8,   9*height/15,90,180,canvas);
    fFin.setColor(new Color(56,19,135));
    fFin.move(width/8,3*height/15);

    sFin = new FilledArc(x,y,  4.5*width/8, 11*height/15,90,180,canvas);
    sFin.setColor(new Color(96,54,180));
    sFin.move(3.5*width/8,2*height/15);

    fsFin = new FilledArc(x,y,  4*width/8,   13*height/15,90,180,canvas);
    fsFin.setColor(new Color(77,38,163));
    fsFin.move(2.25*width/8,height/15);

    tFin = new FilledArc(x,y,  4.5*width/8,    height,   90,180,canvas);
    tFin.setColor(new Color(94,37,212));
    tFin.move(5*width/8,0);
 
    tail = new FilledArc(x,y,  4*width/8, 10*height/15,90,180,canvas);
    tail.move(6*width/8,2.5*height/15);
    tail.setColor(new Color(34,20,64));

    eye = new FilledOval(x,y,width/8,height/15,canvas);
    eye.move(width/16,7*height/15);

  }

  public Fish_LM(Location p, double width, double height,DrawingCanvas canvas){
    this(p.getX(),p.getY(),width,height,canvas);
  }  

}
