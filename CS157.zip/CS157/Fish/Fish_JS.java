import objectdraw.*;
import java.awt.*;

public class Fish_JS{


  private FilledOval body,fin;
  private Line t1, t2 ,t3;
   
 
  public Fish_JS( Location p,DrawingCanvas dc){
    this(p, 100, 200,dc);
  }
  public Fish_JS( double x, double y, double W,double H,DrawingCanvas dc){
    this ( new Location(x,y) , W,H, dc);
  }
  public Fish_JS( Location p, double W,double H,DrawingCanvas dc){

    double x= p.getX();
    double y= p.getY();
   
    
    fin= new FilledOval (x+ 4*W/6, y , W/6 , H,dc);
    body = new FilledOval (x+ W/3,y+ 2*H/8, 2*W/3, 2*H/4,dc);
    body.setColor(Color.BLUE);
    fin.setColor(Color.GREEN);
    

    Location tailconnect= new Location ( x+2*W/6, y+4*H/8);
    Location below= new Location ( x, y+H);
    Location Toptail= new Location ( p); 
    
    t1= new Line ( tailconnect , Toptail,dc);
    t2=new Line (tailconnect, below,dc);
    t3=new Line (Toptail,below,dc);
    t1.setColor(Color.BLUE);
    t2.setColor(Color.BLUE);
    t3.setColor(Color.BLUE);

    
  }

  public void move(double dx, double dy){
    body.move(dx,dy);
    fin.move(dx,dy);
    t1.move(dx,dy);
    t2.move(dx,dy);
    t3.move(dx,dy);
  }  
  
  
      
  public boolean contains( Location p){
     return body.contains(p) || fin.contains(p);
   }


}
