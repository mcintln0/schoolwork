// Calid Shorter 
// September 28, 2017
// Lab #4: Fish of Calid


import objectdraw.*;
import java.awt.*;	

public  class Fish_CS {


  // Name fish parts
  private  FramedOval body;
  private  FilledOval eye;
  
  private Line topLine, bottomLine, vertLine;

  public Fish_CS( Location p, double w, double h, DrawingCanvas canvas ){
    double x = p.getX();
    double y = p.getY();
    
    // Construct fish parts
    Location finPoint = new Location( x + w/ 3, y + h/ 2 );
    Location finBot   = new Location( x, y + h);

    topLine    = new Line( p, finPoint, canvas );
      topLine.setColor( Color.BLUE );
    bottomLine = new Line( finBot, finPoint, canvas );
      bottomLine.setColor( Color.BLUE );
    vertLine   = new Line( p, finBot, canvas );
      vertLine.setColor( Color.BLUE );

    body = new FramedOval( x + w/3, y, w* 2/3, h, canvas ); 
      body.setColor( Color.BLUE );
    eye  = new FilledOval( x + w*5/6, y + h/3, w/14, h/14, canvas ); 

  
  }
}
    
   


