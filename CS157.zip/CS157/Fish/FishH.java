import objectdraw.*;
import java.awt.*;

public class FishH extends WindowController {

  public static void main(String[] args) {
    new FishH().startController(800,800);
  }

  public void onMouseClick(Location p){

   new Fish_MT(p,100,100,canvas);
   new FramedRect(p,100,125,canvas).move(0,-25);
  }

}

