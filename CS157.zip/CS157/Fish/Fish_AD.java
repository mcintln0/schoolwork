// Drew Szentesy, Amanda Jenkins
// CS 157 Lab 5 

import objectdraw.*;
import java.awt.*;
public class Fish_AD {
  
  Location tailTop, tailBottom, tailMiddle, finTop, finLeft, finRight;
  FramedOval body;
  FilledOval eye; 
  FramedArc smile;
  Line tail1, tail2, tail3, fin1, fin2;

public Fish_AD(double x, double y, double w, double h, DrawingCanvas canvas) {
  tailTop = new Location(x, y + h/8);
  tailBottom = new Location(x, y + h*7/8);
  tailMiddle = new Location(x + w/8, y + h*9/16);

  finTop = new Location(x + w*9/16, y);
  finLeft= new Location(x + w/2, y + h/8);
  finRight = new Location(x+ w*5/8, y + h/8);

  body = new FramedOval( x + w/8, y + h/8, 7*w/8, 7*h/8, canvas);
  eye = new FilledOval( x+ w*15/16, y + h*3/8, 5, 5, canvas);
  smile =  new FramedArc(x + w*6/8, y, 7*w/8, 7*h/8, 210, 25, canvas); 

  tail1 = new Line( tailTop, tailMiddle, canvas);
  tail2 = new Line( tailBottom, tailMiddle, canvas);
  tail3 = new Line ( tailTop, tailBottom, canvas);

  fin1 = new Line ( finTop, finLeft, canvas);
  fin2 = new Line( finTop, finRight, canvas); 
  
} 

  public void move (double dx, double dy) {
   
    body.move(dx,dy);
    eye.move(dx,dy);
    smile.move(dx,dy);
    tail1.move(dx,dy);
    tail2.move(dx,dy);
    tail3.move(dx,dy);
    fin1.move(dx,dy);
    fin2.move(dx,dy);
   
  }
  public void moveTo (double x, double y) {
   
    moveTo( new Location(x,y) ) ;
  } 
  public void moveTo(Location p){

     double dx, dy;

     dx = p.getX()-body.getX();
     dy = p.getY()-body.getY();

     move (dx,dy);
  }
  
  public void setColor( Color c) {

    body.setColor(c);
    eye.setColor(c);
  }
}




