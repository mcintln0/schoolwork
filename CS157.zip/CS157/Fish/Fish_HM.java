import objectdraw.*;
import java.awt.*;

// Hailey Ung, Matt D. 
// September 28, 2017
// Lab 5 - Fish Lab

public class Fish_HM {   
   
  private FramedOval body;
  private FilledOval eye;
  private Line TailL, TailT, TailB;
  
  public Fish_HM (Location p, double w, double h, DrawingCanvas dc) {
    body = new FramedOval(p, w, h, dc);
    eye = new FilledOval(body.getX() + 7*w/8, body.getY() + h/2, 10, 10, dc);
    Location topPart = new Location(body.getX() - 20, body.getY());
    Location bottomPart = new Location(body.getX() - 20, body.getY() + h);
    Location bodyPart = new Location(body.getX(), body.getY() +h/2);
    TailL = new Line( topPart, bottomPart, dc);  
    TailT = new Line(topPart, bodyPart, dc);
    TailB = new Line(bottomPart, bodyPart, dc);            

  }
  public void move(double x, double y) { 
      body.move(x, y);
      eye.move(x,y);
      TailL.move(x,y);
      TailT.move(x,y);
      TailB.move(x,y);  
  }
  public void moveTo(Location p){
    moveTo(p.getX(), p.getY()); 
  }
  
  public void moveTo(double x, double y){
    move(x - body.getX(), y - body.getY());
  }
  public void setColor(Color c) {
    body.setColor(c);
    TailT.setColor(c);
    TailL.setColor(c);
    TailB.setColor(c);
  }
  public double getX(){
    return body.getX();
  }
  public double getY(){
    return body.getY();
  }

  // We could not figure out how to print both x and y values. 
  public double getLocation(){
    return body.getX();
    // return body.getY();
  }

  public boolean contains(Location p){
    return body.contains(p);
  }

  public double getWidth(){
    return body.getWidth();  
  }
  public double getHeight(){
    return body.getHeight();  
  }
}
