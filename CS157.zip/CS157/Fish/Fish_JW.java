//Jake and Will
//Lab 4

import java.awt.*;
import objectdraw.*;

public class Fish_JW{


    private Line topFin, botFin, backFin, mouth;
    private FilledOval eye, body;
    private RandomIntGenerator b = new RandomIntGenerator (0,255);
   // private FramedRect frame;

    public Fish_JW(Location P,double w, double h, DrawingCanvas dc){
      double x = P.getX();
      double y = P.getY(); 
    
      Location tipP = new Location (P);
      Location botfinP = new Location(x, y + 5*h/4);
      Location baseP = new Location(x + w/4, y + h/4);
      Location mouthP = new Location(x + w - w/10, y + 2*h/3);
      Location eyeP = new Location(x + w - w/7, y + h/2);
      Location endMP = new Location(x + w, y + 2*h/3); 
      Location bodyP = new Location(x + w/3, y + h/4);
      Location endFish = new Location(x + w, y + h);
      Location endTail = new Location(x + w/2, y + 2*h/3);
 

    

      topFin =  new Line(P, endTail, dc);
      botFin =  new Line(botfinP, endTail, dc);
      backFin =  new Line(P, botfinP, dc);
      body = new FilledOval(baseP, endFish, dc);
      mouth = new Line (mouthP, endMP, dc);
      eye = new  FilledOval(eyeP, 10, 10, dc);
      body.setColor(new Color( b.nextValue(),b.nextValue(),b.nextValue()) );
      topFin.setColor(new Color( b.nextValue(),b.nextValue(),b.nextValue()) );
      botFin.setColor(new Color( b.nextValue(),b.nextValue(),b.nextValue()) );
      backFin.setColor(new Color( b.nextValue(),b.nextValue(),b.nextValue()) );
 
   }
      // frame =  new FramedRect(P, 200, 200, dc);

    public void move( double dx, double dy) {
      topFin.move(dx,dy);
      botFin.move(dx,dy);
      backFin.move(dx,dy);
      body.move(dx,dy);
      mouth.move(dx,dy);
      eye.move(dx,dy); 
    } 
    public void moveTo( double x, double y) {
      move( x - topFin.getStart().getX(),  y - topFin.getEnd().getY() );
    
    }
   
    


} //end



