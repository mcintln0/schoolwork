import objectdraw.*;
import java.awt.*;

public class Fish_MR {

    
  
  private FilledOval body, eye, mouth;
  private Line backFin, topFin, bottomFin, sideLeftFin, sideRightFin;
  private double fishLength;
private double fishHeight;

  public Fish_MR (Location p, double fishLength, double fishHeight
                  , DrawingCanvas dc){

    double x = p.getX();
    double y = p.getY();


    body =  new FilledOval 
      (x + fishLength/3, y, fishLength*2/3, fishHeight, dc);
    body.setColor(new Color(128, 191, 117));
    eye = new FilledOval (x + fishLength*8/10, y + fishHeight/5,
      fishLength*2/30, fishHeight/10, dc);
    backFin = new Line (x, y, x, y + fishHeight, dc);
    topFin = new Line (x, y, x + fishLength/3, y + fishHeight/3, dc);
    bottomFin = new Line (x, y + fishHeight, x + fishLength/3, y + 2*fishHeight/3, dc);
    sideLeftFin = new Line 
      (x + fishLength/2, y + fishHeight/2, 
      x + 4*fishLength/10, y + 9*fishHeight/10, dc);
    sideRightFin = new Line 
      (x + 6*fishLength/10, y + fishHeight/2, 
      x + 4*fishLength/10, y + 9*fishHeight/10, dc);
    mouth = new FilledOval 
      (x + fishLength*8/10, y + 3*fishHeight/5, fishLength*2/20, 2*fishHeight/10, dc );
    mouth.setColor(new Color (237, 161, 113));
  }

  public void move(double dx, double dy){
    body.move(dx,dy);
    eye.move(dx,dy);
    mouth.move(dx,dy);
    backFin.move(dx,dy);
    bottomFin.move(dx,dy);
    topFin.move(dx,dy);
    sideLeftFin.move(dx,dy);
    sideRightFin.move(dx,dy);
  }

  public void moveTo(Location point){
    double dx,dy;

   
}

}



