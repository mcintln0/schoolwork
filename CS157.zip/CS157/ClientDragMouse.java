  // LaToya McIntyre
  // CS 157 - HW 4
  // October 5, 2017
  // Class that plays with a mouse

import objectdraw.*;
import java.awt.*;

public class ClientDragMouse extends WindowController {

  public static void main(String[] args) {
    new ClientDragMouse().startController(800,400);
  }


  private CrazyMouse  bobby;
  private int counter = 0;
  private Location lastPoint;
  
  public void begin (){
    Text instr = new Text("Press to create a new mouse",
                          canvas.getWidth()/2,50,canvas);
    instr.move(-instr.getWidth()/2,0);
  }
  
//  public void onMouseClick(Location p){
//    bobby = new CrazyMouse(p,canvas);
//    counter++;
//  }

  public void onMouseClick(Location p){
    bobby = new CrazyMouse(p,canvas);
    counter++;
  }
    
  public void onMousePress(Location pressPt){
    lastPoint = pressPt;
  }

  public void onMouseDrag(Location p){
    if (counter>=1 && bobby.contains(p)){
       double dx = p.getX()-lastPoint.getX();
       double dy = p.getY()-lastPoint.getY();
       bobby.move(dx,dy);
       lastPoint = p;
    }
  }
}

  // I talked with Hailey, and she said the wording for the HW was wrong,
  // and that you told her the creation method was supposed to be a click 
  // method instead of a press method. I tried writing the program, as is
  // but I can never drag the mouse because a new mouse is created where
  // I press (even though it runs without any error messages). So even though
  // the mouse is technically moveable the user would never be able to move it.
  // So I changed it to a useable program where the mouse is made on the click,
  // the location is saved on the press, then t he mouse can be dragged.
  // Sorry if this is not per your instructions, but I couldn't get the code
  // to work as written.
