  // LaToya McIntyre
  // CS 157 - HW 4
  // 5.8.1
  // October 5, 2017
  // Program that meausre and displays the time between clicks
 
import objectdraw.*;
import java.awt.*;

public class ElaspedTimeClient extends WindowController{

  public static void main(String[] args) {
    new ElaspedTimeClient().startController(800,800);
  }

  private Text display;
  private double start,end;
  private int counter = 0;
  public void begin(){
    display = new Text("Press the mouse twice!",
                       canvas.getWidth()/2,canvas.getHeight()/2,canvas);
    display.move(-display.getWidth()/2,-display.getHeight()/2);
  }

  public void onMousePress(Location p){
    counter++;
    start = System.currentTimeMillis(); 
    if (counter >1){
      display.setText("You pressed "+(start - end)/1000 +" seconds apart");
    }
  }

  public void onMouseRelease(Location p){
    if (counter % 2 != 0){
    end = System.currentTimeMillis();
    }
  }
}    
