import objectdraw.*;
import java.awt.*;

public class Rect extends WindowController{

  public static void main(String[] args) {
    new Rect().startController(200,200);
  }
//shouled establish erase as a rectangle
private FilledRect erase;

// connecting the nickname with an offscreen object
public void begin (){
erase = new FilledRect (300,300,20,20,canvas);
}
 
// The filled square will show up at the press point
 public void onMousePress(Location point){
    erase.moveTo(point);
	erase.show();
  }

// When the mouse is released the filled square disappers
  public void onMouseRelease(Location point){
	 erase.hide();
}
// The Framed Rectangle is left behind
public void onMouseClick(Location point){
		new FramedRect(point,20,20, canvas);

}
}
