    // LaToya McIntyre
    // Septmeber 14,2017
    // HW 2
    // 3.12.1

import objectdraw.*;
import java.awt.*;

    // A program to count as high as you can click.
public class ICanCount extends WindowController {

        // location where count should be displayed
    private static final Location COUNT_POS = new Location( 100, 100);

    private int theCount = 1;   // how high we have counted
    private Text countDisplay;  // current screen display of count

        // Create the Text to display the current count
    public void begin() {
        countDisplay = new Text( theCount, COUNT_POS, canvas );
    }

        // Increase the count with each click
    public void onMouseClick(Location point) {
        theCount = theCount + 1;
        countDisplay.setText( theCount );
    }
}
