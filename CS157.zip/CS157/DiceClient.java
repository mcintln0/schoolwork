  // LaToya McIntyre
  // September 25, 2017
  // CS 157
  // HW 3
  // Creates three dice, and displays the results and informs the user if they
  // rolled pairs, or triples of the same number

import objectdraw.*;
import java.awt.*;

public class DiceClient extends WindowController{

  public static void main(String[] args) {
    new DiceClient().startController(800,800);
  }

  // Setup the generator for the dice numbers and colors
  private RandomIntGenerator dice = new RandomIntGenerator (1,6);
  private RandomIntGenerator dicc = new RandomIntGenerator (150,255);

  private Text dice1,
               dice2,
               dice3,
               display = new Text("Roll the Dice",0,0,canvas),
               d1,
               d2,
               d3;
    
  private FilledRect dic1,
                     dic2,
                     dic3;

  private int di1,
              di2,
              di3;

  public void begin(){

    dic1 = new FilledRect(canvas.getWidth()/4,canvas.getHeight()/4,50,50,canvas);
    dic2 = new FilledRect(canvas.getWidth()/2,canvas.getHeight()/4,50,50,canvas);
    dic3 = new FilledRect(3*canvas.getWidth()/4,canvas.getHeight()/4,50,50,canvas);

    dice1 = new Text("The first dice rolled: ",100,300,canvas);
    dice2 = new Text("The second dice rolled: ",100,350,canvas);
    dice3 = new Text("The third dice rolled: ",100,400,canvas); 
   
    d1 = new Text (di1,dic1.getX(),dic1.getY(),canvas);
    d2 = new Text (di2,dic2.getX(),dic2.getY(),canvas);
    d3 = new Text (di3,dic3.getX(),dic3.getY(),canvas);

    d1.setFontSize(50);
    d2.setFontSize(50);
    d3.setFontSize(50);

    display.setFontSize(25);
    display.move(canvas.getWidth()/2 - display.getWidth(),50);

  }

  // Setup the dice text displays and their corresponding numbers 
  public void onMouseClick(Location p){   
    di1 = dice.nextValue();
    di2 = dice.nextValue();
    di3 = dice.nextValue();

    d1.setText(di1);
    d2.setText(di2);
    d3.setText(di3);

    dic1.setColor(new Color(dicc.nextValue(),0,dicc.nextValue()));
    dic2.setColor(new Color(dicc.nextValue(),dicc.nextValue(),0));
    dic3.setColor(new Color(0,dicc.nextValue(),dicc.nextValue()));
   
    dice1.setText("The first dice rolled: " + di1);
    dice2.setText("The first dice rolled: " + di2);
    dice3.setText("The first dice rolled: " + di3);

  // Set the special text
  if (di1==di2 && di2==di3){
    display.setText("You rolled three " + di1 + "'s !");
    display.setColor(new Color(124,19,170));
    }

  else if((di1==di2)||(di1==di3)||(di2==di3)){
    display.setColor(new Color(71,237,187));
      if((di1==di2) || (di1==di3)){
        display.setText("You rolled a pair of " + di1 +"'s !");
      }else{
        display.setText("You rolled a pair of " + di2 +"'s !");
      }
   }
  
  else{
     display.setText("That was nothing special, try again");
     display.setColor(Color.BLACK);
     }
   
  }

  public void onMousePress(Location p){
    new Dice(p,50,50,canvas);
  }
}
