  // LaToya McIntyre
  // CS 157 
  // Investing Program
  // Create a program that displays the correct bank account values with the 
  // inputted (or default): interest rates, start year, and length of time,
  // and intial start amount

import java.awt.*;
import java.util.Scanner;

public class Investing {

  private int year,
              dYear = 0,
              end, 
              delay = 0;

  private double  interest,
                  money = 0,
                  dMoney;

  public Investing(int start, int length, double amount, double rate){
    System.out.printf(
         "At the end of year \t Begin Jan ' %d \t Wait Five Years \n", start);

     end = length + start;
     year = start;
     interest = rate/100;
   

    while (dYear < length){
      money = money *(1 + interest) +amount * (1 + interest);
      dYear++;
      delay++;    
      if(delay > 5){
          dMoney = dMoney * (1 + interest) + amount * (1 + interest);
      }

      System.out.printf("%4d \t %4d \t\t %14.2f \t %14.2f \n",
                        year, dYear, money, dMoney); 
      year++;
    } 
  }
              
  static Scanner question;
  static int start,
             length;

  static double amount,
                rate,  
                userD;
  public static void main(String[] args) {

  System.out.printf("Do you want to enter your own digits? (1 = no 2 = yes) ");
    question = new Scanner(System.in);
     userD = question.nextDouble();
   
    if (userD == 1) {
      new Investing(2018,25,1000,10);

    }else if (userD == 2){

     System.out.printf("Starting Year: ");
     start = question.nextInt();

     System.out.printf("Length of time: ");
     length = question.nextInt();

     System.out.printf("Amount of Money: ");
     amount = question.nextDouble();

     System.out.printf("Interest Rate (Percent X 100): ");
     rate = question.nextDouble();

     new Investing(start,length,amount,rate);   
    }
  }
}

