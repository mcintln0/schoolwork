  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 14.10.2
  // Create an interactive grid game

import objectdraw.*;
import java.awt.*;

public class CubeGame {

  private double width = 0;
  private double height = 0;
  private FilledRect stored;
  private FilledRect [] cube = new FilledRect [999];
  private FramedRect [] frame = new FramedRect [999];  

  public CubeGame(int rows, int columns, DrawingCanvas dc){
    width = rows;
    height = columns;

  // Needed the length of the array before I constructd it which is impossible
  // Instead created another array and made the reference switch from the
  // initial array index to the one I needed while keeping it available for use
  // throughout the program

    cube = new FilledRect [rows * columns];
    frame = new FramedRect [rows * columns];  
      
  // Create the grid and assign values to the arrays
    double y = 0;
    int j = 0;
    while (j < cube.length){ 
      int row = 0;
      while (row < rows){
        int col = 0;
        double x = 0;
        while(col < columns){
          int i = (int) (Math.random() * cube.length);
          if (cube[i] == null && i < cube.length){ 
            cube [i] = new FilledRect(x,y,50,50,dc);
            frame[i] = new FramedRect(x,y,50,50,dc);
            x = x + 50;
            col++;
            j++;
          }
        }
      y = y + 50;
      row++;
      }
    }

  // Makes sure there are exactly two colors assigned to the grid

    RandomIntGenerator rgb = new RandomIntGenerator (0,255);
    for (int h = 0; h < cube.length/2; h++){
      cube[h].setColor(
              new Color(rgb.nextValue(),rgb.nextValue(),rgb.nextValue()));
      cube[cube.length-1-h].setColor(cube[h].getColor());
    }
  }

  public FilledRect store(Location p){
    for (int i = 0; i < cube.length; i++)
      if(cube[i].contains(p)){
      stored = cube[i];
      frame[i].setColor(Color.RED);
      }
    return stored;
  } 

  // Even thought I can't use the indexes as requirements for a class
  // I can use variables assigned to filled rectangles that give the desired
  // result, and it makes sure stored and other are not the same rect
  // preventing errors that could occur during the game
  // Used hide vs remove from canvas so that I can check from the client
  public void matched (FilledRect stored, FilledRect other){
    if(stored != other){
      stored.hide();
      other.hide();
      for( FramedRect f: frame)
        f.setColor(Color.BLACK);
    }
  }  

  // Allows the user to set the grid to black even though they can't access
  // the frame array
  public void rst(){
    for (int i = 0; i < frame.length; i++)
      frame[i].setColor(Color.BLACK);
  }

  // Uses an outlined square to see if 'p' is within the grid
  public boolean contains(Location p){
    boolean result = false;
    for ( FilledRect q: cube)
      result = result || q.contains(p);
    return result;
  }

  // Made into a boolean so that the client can access the information
  // without potentially causing errors and changes grid black
  public boolean done(){
    int fin = 0;
    for ( FilledRect q: cube)
      if (q.isHidden())
        fin++;
    if (fin == width*height){
      return true;
    }else{
      return false; 
    }  
  }  

  public void hide(){
    for ( FilledRect q: cube)
      q.hide();
    for ( FramedRect h: frame)
      h.hide();
  }
  
  public double getWidth(){
    return (50 * width);
  }

  public double getHeight(){
    return (50 * height);
  }

}



