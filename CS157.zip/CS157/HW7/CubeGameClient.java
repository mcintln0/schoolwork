  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 14.10.2
  // Create an interactive grid game

import objectdraw.*;
import java.awt.*;

public class CubeGameClient extends WindowController{


  public static void main (String[] args) {
    
    new CubeGameClient().startController(600,600); 
  }

  private FilledRect scoreB;
  private Text score;
  private CubeGame game;
  private int clicker = 0;
  private FilledRect compare1;
  private FilledRect compare2;
  private VisibleImage surprise;
  private Text end;
  private FilledRect reset;
  private Text resetT;

  public void begin(){
    clicker = 0;
    game = new CubeGame(8, 8, canvas);
    surprise = new VisibleImage(getImage("Galaxy.jpg"),0,0,
                                game.getWidth(),game.getHeight(),canvas);
    surprise.sendToBack();
    scoreB = new FilledRect(game.getWidth() + 100, 100, 100,100, canvas);
    scoreB.setColor(Color.BLUE);
    score = new Text(clicker,scoreB.getLocation(), canvas); 
    score.setFontSize(20);
    score.setColor(Color.WHITE);
    score.move(scoreB.getWidth()/2-score.getWidth()/2,
               scoreB.getHeight()/2-score.getHeight()/2);
    reset = new FilledRect(scoreB.getX(),scoreB.getY()+100,100,100,canvas);
    reset.setColor(Color.BLACK);
    resetT = new Text("Reset", reset.getLocation(), canvas);
    resetT.setColor(Color.WHITE);
    resetT.move(reset.getWidth()/2-resetT.getWidth()/2,
               reset.getHeight()/2-resetT.getHeight()/2);
  }

  public void onMouseClick(Location p){

  // Clicks only count if within the border of the game and if the game isn't
  // finished (fixes a potential problem with the user clicking after the game
  // is finished and making the text mess)
    if(game.contains(p) && (game.done() == false) )
      clicker++;

  // Saves the references to the cubes clicked
    if(clicker%2 == 1){
      compare1 = game.store(p);
    }else if(clicker%2 == 0 && clicker != 0 && compare1 != null){ 
      compare2 = game.store(p);

  // If the colors match (but aren't the same cube) then the cubes are removed
      if(compare1.getColor() == compare2.getColor()){
        game.matched(compare1, compare2);
  // Automatically sets the grid lines back to black 
      }else if(compare1.getColor() != compare2.getColor()){
        game.rst();
      }
    }

    if(game.done()){
      surprise.setSize(canvas.getWidth(),canvas.getHeight());
      game.hide();
      score.hide();
      resetT.hide();
      reset.hide();
      scoreB.hide();
      end = new Text("You won with "+clicker+" clicks!!",
                     canvas.getWidth()/2,canvas.getWidth()/2,canvas);
      end.setFontSize(20);
      end.setColor(Color.WHITE);
      end.move(-end.getWidth()/2,-end.getHeight()/2);
    }

    if(reset.contains(p)){
      canvas.clear();
      begin();
    }

    score.setText(clicker);
  }
}
