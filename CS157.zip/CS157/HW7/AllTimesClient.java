  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 13.6.4
  // Write a for loop that prints out the times tables from 1 to 10


public class AllTimesClient {

  public static void main (String[] args) {

  // Separate for loop for the n line of code, otherwise will not format
  // properly
    
    System.out.printf( "n: \t");
    for (int h = 1; h <=10; h++){
      System.out.printf( "nx%d \t" ,h );
     }
 
    for( int i = 1; i <=10 ; i++){ 
      System.out.printf( "\n%d: \t", i);
      for(int j = 1; j <= 10; j++){  
        System.out.printf( " %d \t", i*j);
      }
    }
  }

}
