  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 13.6.3
  // Write a for loop that prints out the two times tables from 2 x 1 to 2 x 10


public class TimesTablesClient {

  public static void main (String[] args) {
    
    System.out.printf( "n: \t");
    for( int i = 1; i <=10 ; i++){ 
      System.out.printf( "nx%d \t" ,i );
      if(i==10){
      i = 1;
  // Creates the extra line I need in order for the formatting to be correct
  // without completely disrupting my for loop
      System.out.printf( "\n2: \t");
        while(i<=10){
        System.out.printf( " %d \t", 2*i);
        i++;
        }
      }
    }

  }

}

