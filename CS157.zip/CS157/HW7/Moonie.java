  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 14.10.2
  // Create the background of the interactive grid game

import objectdraw.*;
import java.awt.*;

public class Moonie{

  private FilledOval moond,
                     moon;  

  public  Moonie(double x, double y, double width, double height,
                   DrawingCanvas canvas, Color background) {
    moon = new FilledOval(x,y,width,height, canvas);
    moond = new FilledOval(x,y,width,height,canvas);
    moon.setColor(new Color(172,213,227));
    moond.move(moon.getWidth()/4,-moon.getWidth()/4);
    moond.setColor(background);
  
  }

  public  Moonie(Location p, double width, double height,
                 DrawingCanvas canvas, Color background){
    this(p.getX(),p.getY(), width, height, canvas, background);
  }

  public  Moonie(Location p, double width, double height,
                 DrawingCanvas canvas){
    this(p.getX(),p.getY(), width, height, canvas, Color.WHITE);
  }

  public  Moonie(double x, double y, double width, double height,
                 DrawingCanvas canvas){
    this(x,y, width, height, canvas, Color.WHITE);

  }

  public void sendToBack() {
     moond.sendToBack();
     moon.sendToBack();
  } 

  public void removeFromCanvas(){
     moon.removeFromCanvas();
     moond.removeFromCanvas();
  }
}
