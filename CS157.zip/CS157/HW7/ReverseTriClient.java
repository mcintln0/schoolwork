  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 13.6.5
  // Reverse triangular pattern of numbers

public class ReverseTriClient {

  public static void main (String[] args) {

  // stack loops so that the number is repeated the right amount of times
    for( int i = 7; i >0 ; i--){ 
      for(int j = 0; j < i; j++){  
        System.out.printf( " %d  ", i);
      }
      System.out.printf( "\n");
    }
  }

}
