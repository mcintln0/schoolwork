  // LaToya McIntyre
  // CS 157 -- HW7
  // November 17, 2017
  // 14.9.1
  // Land Area of Earth

//supposed to be handwritter #youPlayedYourself

import java.util.Scanner;

public class EarthAreaClient {

  private static Scanner scan;
  static double totalArea;

  public static void main (String[] args) {

  // attach scanner to terminal input
    scan = new Scanner(System.in);

    do{
      System.out.printf
      ("\n\tPlease enter a double then hit return: ");
      totalArea = scan.nextDouble(); 
    }while (totalArea <= 0);

    System.out.printf( "\nPercent of Total Land Area \tContinent");     
    System.out.printf( "\n %50.2f \t Africa", .203*(totalArea));
    System.out.printf( "\n %50.2f \t Antartica", .089*(totalArea));
    System.out.printf( "\n %50.2f \t Asia", .3*(totalArea));
    System.out.printf( "\n %50.2f \t Australia", .052*(totalArea));
    System.out.printf( "\n %50.2f \t Europe", .067*(totalArea));
    System.out.printf( "\n %50.2f \t North America", .163*(totalArea));
    System.out.printf( "\n %50.2f \t South America", .089*(totalArea));
   
  }

}
