  // LaToya McIntyre
  // CS 157 -- Lab 11
  // November 9, 2017
  // Practice with arrays and loops

import java.util.Scanner;
import objectdraw.*;
import java.awt.*;

public class NRhymeClient extends WindowController {

  static Scanner sc;

  public static void main(String[] args) {
    sc = new Scanner(System.in);
    new NRhymeClient().startController(600,600);
  }

  private Text [] rhyme = new Text [50];
  private Color c = new Color ((int)(Math.random()*255),(int)(Math.random()*255),
                    ((int)Math.random()*255));

  public void begin() {
    new Text(" Clicking makes things happen!", 10,10,canvas).setFontSize(20);
    new Text("(If you have..a mess, you forgot to redirect standard input...)",
             10,35,canvas);   

    int i = 0;
    double x = 75;
    double y = 100;

    while(sc.hasNext()){
      if(i!=0){
        x = x + rhyme[i-1].getWidth() + 5;
        if( i%5 == 0){
          y = y + rhyme[i-5].getHeight() + 5;
          x = 75;
        }
      }

      rhyme [i] = new Text (sc.next(), x, y, canvas);
      rhyme[i].setFontSize(25); 
  // Could have made an array of strings and then used to set text  
      /* str[i]= sc.next(); */
      i++;
    }

  // Allows the rest of the array to be filled and "resets" the words used
    int j = i;
    while ( j < rhyme.length){
      x = x + rhyme[j-1].getWidth() + 5;
      if( j%5 == 0){
        y = y + rhyme[j-5].getHeight() + 5;
        x = 75;
      }
      rhyme [j] = new Text (rhyme[j-i].getText(), x, y, canvas);
      rhyme[j].setFontSize(25);    
      j++;
    } 
    for( Text word: rhyme){
      word.setColor(c);
    }
  }

  public void onMouseClick(Location p){
    Color d = new Color ((int)(Math.random()*255),(int)(Math.random()*255),
                    ((int)Math.random()*255));
    for( Text word: rhyme){
      word.setColor(d);
    } 
  }

}
    
