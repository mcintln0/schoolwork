// BJ Fish edited by Toya

import objectdraw.*;
import java.awt.*;

public class BJFish implements Drawable157{

  private Line finLeft, finRight, tailTop, tailBottom, tailEnd;
  private FilledOval body, eye;
  private FramedOval bodyFrame;
  private double width, height;
  private Location corner;

  public BJFish(double x, double y, double w, double h, DrawingCanvas dc){
    width = w;
    height = h;
    corner = new Location (x,y);

    Location finTip = new Location( x+ 5*w/8, y + h/8);
    Location tailTip = new Location( x + 3*w/8, y + 5*h/8);
    Location tailPointT = new Location ( x, y+ 3*h/8);
    Location tailPointB = new Location ( x, y + h);
    Location finPointL = new Location ( x+ w/2, y + h/2);
    Location finPointR = new Location (x+ 3*w/4, y + h/2);

    finLeft = new Line(finPointL, finTip, dc);
    finRight = new Line(finPointR, finTip, dc);
    
    tailTop = new Line(tailPointT, tailTip, dc);
    tailBottom = new Line(tailPointB, tailTip, dc);
    tailEnd = new Line(tailPointT, tailPointB, dc);

    body = new FilledOval(x + w/4, y + 3*h/8, 3*w/4, h/2, dc);
    body.setColor(Color.RED);
    
    bodyFrame = new FramedOval(x+w/4, y + 3*h/8, 3*w/4, h/2,dc);

    eye = new FilledOval( x + 3*w/4, y + h/2, w/16, w/16, dc);   
  }

  public BJFish(Location p, double w, double h, DrawingCanvas dc){
    this( p.getX(), p.getY(), w, h, dc );
  }

  public BJFish(DrawingCanvas dc){
    this( Math.random()*600, Math.random()*600,
          Math.random()*100 + 50, Math.random()*100 + 50, dc);
  }

  public void move(double x, double y){
    body.move(x,y);
    bodyFrame.move(x,y);
    tailTop.move(x,y);
    tailBottom.move(x,y);
    tailEnd.move(x,y);
    finLeft.move(x,y);
    finRight.move(x,y);
    eye.move(x,y);
    corner= new Location(corner.getX()+x, corner.getY()+y);
  }

  public void moveTo(Location p){
    move( p.getX()-body.getX() + width/4, p.getY()-body.getY()+3*height/8 );
  }

  public void moveTo(double x, double y){
    move(x-body.getX() + width/4, y-body.getY()+3*height/8 );
  }

  public void setColor(Color c){
    body.setColor(c);
  }

  public double getX(){
    return corner.getX();
  }
  
  public double getY(){
    return corner.getY();
  }
  
  public Location getLocation(){
    return corner;
  }

  public Color getColor(){
    return body.getColor();
  }

  public boolean contains(Location p){
    return body.contains(p) || tailTop.contains(p) || tailBottom.contains(p) ||
           tailEnd.contains(p) || finLeft.contains(p) || finRight.contains(p);
  }

  public double getWidth(){
    return width;
  }

  public double getHeight(){
    return height;
  }

  public void hide(){
    body.hide();
    bodyFrame.hide();
    tailTop.hide();
    tailBottom.hide();
    tailEnd.hide();
    finLeft.hide();
    finRight.hide();
    eye.hide();
  }

  public void show(){
    body.show();
    bodyFrame.show();
    tailTop.show();
    tailBottom.show();
    tailEnd.show();
    finLeft.show();
    finRight.show();
    eye.show();
  }
}
