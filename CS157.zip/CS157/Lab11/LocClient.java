  // LaToya McIntyre
  // CS 157 -- Lab 11
  // November 9, 2017
  // Practice with constructing shapes using a location array

import objectdraw.*;
import java.awt.*;

public class LocClient extends WindowController {

  public static void main(String[] args) {
    new LocClient().startController(800,800);
  }

  private Location [] coords = new Location [10];

  public void begin() {
    for(int i=0; i < coords.length; i++){
      coords[i] = new Location(Math.random()*800,Math.random()*800);
      new FramedOval(coords[i],10,10,canvas).move(-5,-5);
    }

  // Find the max x-coord
    double maxX = 0;
    for(int i = 0; i < coords.length; i++){ 
      if (coords[i].getX() > maxX){
        maxX = coords[i].getX();
      }  
    }

  // Find the max y-coord
    double maxY = 0;
    for(int i = 0; i < coords.length; i++){ 
      if (coords[i].getY() > maxY){
        maxY = coords[i].getY();
      }  
    }

  // Find the min x-coord
    double minX = 999;
    for(int i = 0; i < coords.length; i++){ 
      if (coords[i].getX() < minX){
        minX = coords[i].getX();
      }  
    }

  // Find the min y-coord
    double minY = 999;
    for(int i = 0; i < coords.length; i++){ 
      if (coords[i].getY() < minY){
        minY = coords[i].getY();
      }  
    }

  Location upperLeft = new Location  (minX, minY);
  Location lowerRight = new Location (maxX, maxY);
  
  new FramedRect(upperLeft, lowerRight,canvas).setColor(Color.RED);

  }

}
