  // LaToya McIntyre
  // CS 157 -- Lab 11
  // November 9, 2017
  // Practice with constructing shapes using a location array

import objectdraw.*;
import java.awt.*;

public class RingSetClient extends WindowController {

  public static void main(String[] args) {
    new RingSetClient().startController(800,800);
  }
  private RandomIntGenerator c = new RandomIntGenerator (0,255);
  private Fish_T [] bobby = new Fish_T [8];
  private BJFish [] brit = new BJFish [7];
  private Drawable157 [] ringSet = new Drawable157 [15];

  public void begin(){
    for (int i = 0; i < bobby.length; i++){
      bobby[i] = new Fish_T(canvas);
      bobby[i].setColor(new Color( c.nextValue(),c.nextValue(),c.nextValue()));
      if( i < brit.length ){
        brit[i] = new BJFish(canvas);
        brit[i].setColor(new Color( c.nextValue(),c.nextValue(),c.nextValue()));
       }
    }

    int j = 0;
    int h = 0;
   
    for (int i = 0; i < ringSet.length; i++){
      if( i%2 == 0){
        ringSet[i] = bobby[j];
        j++;
      }else if(i%2 == 1){
        ringSet[i] = brit[h];
        h++; 
      }
    }
  }
  
  public void onMouseExit(Location p){
    canvas.clear();
    begin();
  }  
}
