  // LaToya McIntyre
  // CS 157 -- Lab 7
  // October 12, 2017
  // Create a flying object
  // My object can change colors, move, be animated, and be removed from canvas

import objectdraw.*;
import java.awt.*;

public class Butterfly extends ActiveObject{

  private FilledOval body, lTWing, lBWing, rTWing, rBWing, lAnt, rAnt;
  private FramedArc lTAnt, rTAnt;

  public Butterfly(Location p, double width, double height,
                   DrawingCanvas canvas){
 
    // wing and body   
    rBWing = new FilledOval(p,width/3,height/3, canvas);
    lBWing = new FilledOval(p,width/3,height/3, canvas);   
    rTWing = new FilledOval(p,2*width/3,height/3, canvas);
    lTWing = new FilledOval(p,2*width/3,height/3, canvas);
    body   = new FilledOval(p, width*.25, 7*height/8, canvas);
    
    // getting the correct positions  
    body.move(width/2-body.getWidth()/2,height/8);
    lTWing.move(0,height/4);
    rTWing.move(width-rTWing.getWidth(),height/4);
    lBWing.move(body.getWidth()/2,height/2);
    rBWing.move(rTWing.getWidth()-body.getWidth()/2, height/2);


    // setting the color
    lTWing.setColor(Color.RED);   
    rTWing.setColor(Color.RED);
    lBWing.setColor(Color.BLUE);
    rBWing.setColor(Color.BLUE);

    // anteneas
    lTAnt = new FramedArc(p, width/4,height/4, 0,135,canvas);
    lTAnt.move(width/4,0);

    lAnt = new FilledOval(p,width/16,height/16,canvas);
    lAnt.move(width/4,height/32);

    rTAnt = new FramedArc(p, width/4,height/4, 180,-135,canvas);
    rTAnt.move(width/2,0);

    rAnt = new FilledOval(p,width/16,height/16,canvas);    
    rAnt.move(3*width/4 -rAnt.getWidth(),height/32);

    start();
  }

  public Butterfly(double x, double y, double width, double height,
                   DrawingCanvas canvas){
    this((new Location(x,y)),width,height,canvas);
  }

  public void setColor(Color c){
    lTWing.setColor(c);
    rTWing.setColor(c);
    lBWing.setColor(new Color(c.getBlue(),c.getGreen(),c.getRed()));
    rBWing.setColor(new Color(c.getBlue(),c.getGreen(),c.getRed()));
    rAnt.setColor(new Color(c.getBlue(),c.getGreen(),c.getRed()));
    lAnt.setColor(new Color(c.getBlue(),c.getGreen(),c.getRed()));
  }

  public boolean contains(Location p){
    return 
      (body.contains(p) || lTWing.contains(p) || rTWing.contains(p) || 
      lBWing.contains(p) || rBWing.contains(p));   
  }

  // Accessor Methods for the Butterfly
  public double getHeight(){
    return  8*body.getHeight()/7;
  } 

  public double getWidth(){
    return  body.getWidth()*4;
  } 

  public void move(double dx, double dy){
   body.move(dx,dy);
   lTWing.move(dx,dy);
   lBWing.move(dx,dy);
   rTWing.move(dx,dy);
   rBWing.move(dx,dy);
   lAnt.move(dx,dy);
   rAnt.move(dx,dy);
   lTAnt.move(dx,dy);
   rTAnt.move(dx,dy);
  }

  public void removeFromCanvas(){
    body.removeFromCanvas();
    lTWing.removeFromCanvas();
    lBWing.removeFromCanvas();
    rTWing.removeFromCanvas();
    rBWing.removeFromCanvas();
    lAnt.removeFromCanvas();
    rAnt.removeFromCanvas();
    lTAnt.removeFromCanvas();
    rTAnt.removeFromCanvas();
  }

  public void hide(){
    body.hide();
    lTWing.hide();
    lBWing.hide();
    rTWing.hide();
    rBWing.hide();
    lAnt.hide();
    rAnt.hide();
    lTAnt.hide();
    rTAnt.hide();
  }

  public void run(){

    while((body.getX() < body.getCanvas().getWidth() ) || (body.getY() < body.getCanvas().getHeight() )){
      move(30,-5);
      pause(75);
      move(0,-2);
      pause(30);
      move(-25,-10);
      pause(75);
  }
    removeFromCanvas();
  }


  public double getX(){
    return  lTWing.getX(); 
  }

}
