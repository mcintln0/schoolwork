import objectdraw.*;
import java.awt.*;

public class Signature extends WindowController{

  public static void main(String[] args) {
    new Signature().startController(800,800);
  }

 //Making Ovals of two different colors
  private RandomIntGenerator redG = 
                           new RandomIntGenerator (0,255);
  private RandomIntGenerator blueG = 
                           new RandomIntGenerator (0,255);
  private RandomIntGenerator alphaG = 
                           new RandomIntGenerator (0,255);

  public void onMouseDrag(Location point){
    new FilledOval(point,8,8,canvas).setColor(
                              new Color ( redG.nextValue(),0,blueG.nextValue() ));
                      // If I wanted transparency involved      alphaG.nextValue())         
  }
  
}

