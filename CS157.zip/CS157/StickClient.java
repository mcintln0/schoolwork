  // LaToya McIntyre
  // CS 157
  // HW 3
  // September 25,2017 

import objectdraw.*;
import java.awt.*;

public class StickClient extends WindowController{

  public static void main(String[] args) {
    new StickClient().startController(800,800);
  }
  private int cnts = 1,
              cntt = 1;
  private FramedOval head;

  private Line body,
               larm,
               rarm,
               lleg,
               rleg;

  private FilledOval lelb,
                     relb,
                     lkne,
                     rkne,
                     oval;
 
  private FramedRect think,
                     speak;

  private Text thnk,
               spk,
               words;

  private FilledRect sqr;

  public void begin(){

  // Setting up boxes with commands
    think = new FramedRect(canvas.getWidth()/2,canvas.getHeight()/8,
                           100,30,canvas);
    think.setColor(Color.RED);
    think.move(think.getWidth(),0);

    speak = new FramedRect(canvas.getWidth()/2,canvas.getHeight()/8,
                           100,30,canvas);
    speak.move(-2*speak.getWidth(),0);
    speak.setColor(Color.BLUE);

    spk = new Text("Speak", speak.getX(),speak.getY(),canvas);
    spk.setColor(Color.BLUE);
    spk.setFontSize(20);
    spk.move(spk.getWidth()/4,0);

    thnk = new Text("Think", think.getX(),think.getY(), canvas);
    thnk.setColor(Color.RED);
    thnk.setFontSize(20);
    thnk.move(spk.getWidth()/4,0);

  // Setting up the head and body
    head=new FramedOval(canvas.getWidth()/2,canvas.getHeight()/2,50,50,canvas);
    head.move(-head.getWidth(), -head.getHeight());
    body = new Line(head.getX()+head.getWidth()/2,head.getY()+head.getWidth(),
                  head.getX()+head.getWidth()/2,head.getY()+2.5*head.getWidth(),
                  canvas);

    words = new Text(" ",head.getX()+head.getWidth(),head.getY()-50,canvas);
    words.setFontSize(15);
    words.move(30,0);

  // Setting up the arms and legs   
    Location arms = new Location(body.getStart());
    Location arms1 = new Location(body.getEnd());

    larm = new Line(arms.getX(),(arms1.getY()-arms.getY())/2+arms.getY(),
                    head.getX(),head.getY()+head.getWidth(),canvas);
    rarm = new Line(arms.getX(),(arms1.getY()-arms.getY())/2+arms.getY(),
                    head.getX()+head.getWidth(),head.getY()+head.getWidth(),
                    canvas);
 
    lleg = new Line(arms1.getX(),arms1.getY(),head.getX(),
                    arms1.getY()+head.getWidth(),canvas);
    rleg = new Line(arms1.getX(),arms1.getY(),
                    head.getX()+head.getWidth(),arms1.getY()+head.getWidth(),
                    canvas);

  // Setting up the elbow joints
    Location elb = new Location(larm.getStart());
    Location elb1 = new Location(larm.getEnd());   
    lelb = new FilledOval((elb1.getX()-elb.getX())/2+elb.getX(),
                          (elb1.getY()-elb.getY())/2+elb.getY(),5,5,canvas);
    lelb.move(-lelb.getWidth()/2,-lelb.getHeight()/2);

    Location elb2 = new Location(rarm.getStart());
    Location elb3 = new Location(rarm.getEnd());   
    relb = new FilledOval((elb3.getX()-elb2.getX())/2+elb2.getX(),
                          (elb3.getY()-elb2.getY())/2+elb2.getY(),5,5,canvas);
    relb.move(-relb.getWidth()/2,-relb.getHeight()/2);
  
  // Setting up the leg joints
    Location kne = new Location(lleg.getStart());
    Location kne1 = new Location(lleg.getEnd());   
    lkne = new FilledOval((kne1.getX()-kne.getX())/2+kne.getX(),
                          (kne1.getY()-kne.getY())/2+kne.getY(),5,5,canvas);
    lkne.move(-lkne.getWidth()/2,-lkne.getHeight()/2);

    Location kne2 = new Location(rleg.getStart());
    Location kne3 = new Location(rleg.getEnd());   
    rkne = new FilledOval((kne3.getX()-kne2.getX())/2+kne2.getX(),
                          (kne3.getY()-kne2.getY())/2+kne2.getY(),5,5,canvas);
    rkne.move(-rkne.getWidth()/2,-rkne.getHeight()/2);
   }

  public void onMouseClick(Location point){
    if (speak.contains(point) && cnts==1){
      new Line(words.getX(),words.getY()+words.getHeight()/2,
               head.getX()+head.getWidth(), head.getX()+head.getHeight()/2,
               canvas);
      words.setText(" Bonjour Professor Dale!");
      cnts++;
    }else if(speak.contains(point) && cnts==2){
      words.setText(" J'aime la classe du computer");
      cnts++;
    }else if(speak.contains(point) && cnts==3){
      words.setText(" Mais je dois aller à la bibliothèque");
      cnts++;
    }else if(speak.contains(point) && cnts==4){
      words.setText(" Au voir!");
      cnts++;
    }else if(speak.contains(point) && cnts==5){
      words.setText(" ");
      cnts=1;
      canvas.clear();
      begin();
    }else if(think.contains(point) && cntt==1){
      cntt++;
      FramedOval thot = new FramedOval(speak.getX(),canvas.getHeight()/4,
                                       200,100,canvas);
      new FramedOval(thot.getX()+thot.getWidth()/2,
                     thot.getY()+thot.getHeight()+5,50,50,canvas);
      sqr = new FilledRect(thot.getX()+thot.getWidth()/2-35,
                       thot.getY()+thot.getHeight()/2-35,70,70,canvas);
      sqr.setColor(Color.RED);

    }else if(think.contains(point) && cntt==2){
      cntt++;
      sqr.hide();
      oval = new FilledOval(sqr.getX(),sqr.getY(),70,70,canvas);
      oval.setColor(Color.BLUE);
    }else if(think.contains(point) && cntt==3){
      cntt++;
      oval.hide();
      FilledRoundedRect rect = new FilledRoundedRect(oval.getX(),oval.getY(),
                                   70,70,45,45,canvas);
      rect.setColor(Color.GREEN);
    }else if(think.contains(point) && cntt==4){
      cntt=1;
      canvas.clear();
      begin();      
    }
  }
}
